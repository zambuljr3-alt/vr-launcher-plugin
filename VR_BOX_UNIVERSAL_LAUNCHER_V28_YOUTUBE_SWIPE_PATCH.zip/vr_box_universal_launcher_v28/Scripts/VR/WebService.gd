extends Node
## Embedded web screen (autoload "Web"). Needs the NATIVE plugin built from Android/VRLauncherPlugin
## (WebView on a private VirtualDisplay, frames polled as JPEG). Untested on a device.
## Honest limit: this shows WEB pages (YouTube mobile site, Google...) inside the launcher; it is not the
## native YouTube app. Video playback inside the frames must be verified on the phone.

signal frame_ready(tex: Texture2D)

## Size of the off-screen page. Desktop mode (default) uses 1280x720 so the desktop site (YouTube Shorts arrows/wheel) loads.
var W := 1280
var H := 720
var DPI := 160

var texture: ImageTexture = null
var current_url := ""
var _timer: Timer


func _ready() -> void:
    _timer = Timer.new()
    _timer.wait_time = 0.066
    _timer.timeout.connect(_poll)
    add_child(_timer)


func available() -> bool:
    return Apps.native_plugin and Apps.plugin != null


func fix_url(u: String) -> String:
    if bool(Settings.data.get("web_desktop", true)):
        return u.replace("https://m.youtube.com", "https://www.youtube.com")
    return u


func open(url: String) -> void:
    if not available():
        return
    var desktop: bool = bool(Settings.data.get("web_desktop", true))
    W = 1280 if desktop else 960
    H = 720 if desktop else 540
    DPI = 160 if desktop else 200
    if Apps.plugin.has_method("webSetDesktop"):
        Apps.plugin.call("webSetDesktop", desktop)
    current_url = fix_url(url)
    Apps.plugin.call("webOpen", current_url, W, H, DPI)
    _timer.start()


func close() -> void:
    _timer.stop()
    if available():
        Apps.plugin.call("webClose")


func load_url(url: String) -> void:
    if available():
        current_url = fix_url(url)
        Apps.plugin.call("webLoad", current_url)


## Position in web pixels (0..W, 0..H).
func tap(p: Vector2) -> void:
    if available():
        Apps.plugin.call("webTap", p.x, p.y)


## Send a real touch gesture to the embedded Android WebView.
## Coordinates are in web pixels, not Godot screen pixels.
func swipe(from_pos: Vector2, to_pos: Vector2, duration_ms: int = 260) -> void:
    if not available():
        return
    if Apps.plugin.has_method("webSwipe"):
        Apps.plugin.call("webSwipe", from_pos.x, from_pos.y, to_pos.x, to_pos.y, clampi(duration_ms, 120, 700))
    else:
        # Older plugin fallback: wheel scrolling. This may not switch Shorts reliably.
        var dy := int(from_pos.y - to_pos.y)
        scroll(600 if dy > 0 else -600)


## dy > 0 scrolls down. Mouse wheel (needs the v28 plugin), else a finger swipe, else JavaScript scrolling.
func scroll(dy: int) -> void:
    if not available():
        return
    if Apps.plugin.has_method("webWheel"):
        Apps.plugin.call("webWheel", W * 0.5, H * 0.5, -float(dy) / 120.0)
    elif Apps.plugin.has_method("webSwipe"):
        var dist := clampf(absf(float(dy)) / float(H), 0.2, 0.6) * float(H)
        var y1 := H * 0.5 + (dist * 0.5 if dy > 0 else -dist * 0.5)
        var y2 := H * 0.5 + (-dist * 0.5 if dy > 0 else dist * 0.5)
        Apps.plugin.call("webSwipe", W * 0.5, y1, W * 0.5, y2, 220)
    else:
        Apps.plugin.call("webScroll", dy)


## One wheel notch moves YouTube Shorts (desktop site) to the next/previous short.
func short_next() -> void:
    if available() and Apps.plugin.has_method("webWheel"):
        Apps.plugin.call("webWheel", W * 0.5, H * 0.5, -3.0)
    else:
        scroll(600)


func short_prev() -> void:
    if available() and Apps.plugin.has_method("webWheel"):
        Apps.plugin.call("webWheel", W * 0.5, H * 0.5, 3.0)
    else:
        scroll(-600)


func back() -> void:
    if available():
        Apps.plugin.call("webBack")


func forward() -> void:
    if available():
        Apps.plugin.call("webForward")


func text(s: String) -> void:
    if available():
        Apps.plugin.call("webText", s)


func key(code: int) -> void:
    if available():
        Apps.plugin.call("webKey", code)


func _poll() -> void:
    if not available():
        return
    var b64 := str(Apps.plugin.call("webGetFrame"))
    if b64 == "":
        return
    var img := Image.new()
    if img.load_jpg_from_buffer(Marshalls.base64_to_raw(b64)) != OK:
        return
    if texture == null or texture.get_size() != Vector2(img.get_size()):
        texture = ImageTexture.create_from_image(img)
    else:
        texture.update(img)
    frame_ready.emit(texture)
