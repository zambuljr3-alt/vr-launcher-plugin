# Roadmap status (v30). Honest, not device-tested unless stated.
Legend: DONE = implemented in code; TEST = needs device testing; PLUGIN = needs the native plugin build; SHIZUKU = needs Shizuku; NO = not implemented.

1. Play all games: games open like any app in Window mode (virtual display, SHIZUKU, TEST). 2D/3D depends on the game accepting a
   secondary display. Controller -> game: NO yet (planned: map gamepad buttons to key events on the virtual display).
2. All Android apps: installed-app list + icons (PLUGIN, TEST), open from Home/Library, Library refreshes when you return to the
   launcher and has a Refresh button (v30, TEST).
3. Play Store: opens like any app (real app in Window mode, SHIZUKU) so you can install; a newly installed app appears in the
   Library after Refresh/return. Home grid is not auto-extended (favorites are manual) - NO.
4. Advanced VR home: floating menu, library, stereo, gyro head tracking, gaze: DONE (owner confirmed on a phone). A modelled 3D room: NO.
5. Cinema: FIXED in v30 (the curved screen was culled because the triangle winding was reversed). Content: YouTube (web) or screen
   mirror; Play/Pause; size/distance/height/brightness/curved (TEST). Local video files: NO (Godot plays Ogg Theora only).
6. Universal controller: gaze DONE, touch DONE, gamepad for the launcher DONE (TEST). Gamepad INTO apps/games and on-screen
   virtual buttons: NO (next).
8. Smart Android integration: app detection, icons, native plugin, Shizuku virtual display: DONE (build confirmed), per-app
   compatibility log (Settings diagnostics).
