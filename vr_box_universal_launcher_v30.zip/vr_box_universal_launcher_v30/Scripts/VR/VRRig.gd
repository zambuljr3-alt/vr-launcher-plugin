extends Node
## Stereoscopic VR prototype.
## Architecture: the launcher UI renders into a SubViewport -> texture on a 3D quad.
## Two Camera3D (one per eye, IPD apart, parallel axes) in their own SubViewports view
## the SAME 3D world. Each eye image gets barrel (lens) correction via a shader and
## is shown side by side. Head rotation (gyro) rotates both cameras.
## Flat fallback: VR OFF = the UI is shown directly in the window (no stereo).

const GazeReticle = preload("res://Scripts/Controller/GazeReticle.gd")
const LENS_SHADER := "res://Assets/VR/lens_distortion.gdshader"
const HDRI_PATH := "res://Assets/VR/forest_sky.jpg"  # 2K tone-mapped panorama made from mossy_forest_4k.exr
const UI_SIZE := Vector2i(1280, 720)
const HOME_PANEL_WIDTH := 3.2
const QUALITY := [0.5, 0.75, 1.0]

var shell: Control
var ui_vp: SubViewport
var quad: MeshInstance3D
var vp_l: SubViewport
var vp_r: SubViewport
var cam_l: Camera3D
var cam_r: Camera3D
var layer: CanvasLayer
var mat_l: ShaderMaterial
var mat_r: ShaderMaterial
var _active := false
var _flat_parent: Node


func setup(s: Control) -> void:
    shell = s
    _flat_parent = s.get_parent()
    _build()
    Settings.changed.connect(func(_k: String) -> void:
        _update_params()
        _apply.call_deferred(false))
    Launcher.page_requested.connect(func(_p: String, _b: bool) -> void: _update_params())
    get_tree().root.size_changed.connect(_update_sizes)
    _apply(true)


func _build() -> void:
    ui_vp = SubViewport.new()
    ui_vp.size = UI_SIZE
    ui_vp.disable_3d = true
    ui_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
    add_child(ui_vp)

    var env := Environment.new()
    if ResourceLoader.exists(HDRI_PATH):
        var sky := Sky.new()
        var pm := PanoramaSkyMaterial.new()
        pm.panorama = load(HDRI_PATH) as Texture2D
        sky.sky_material = pm
        env.background_mode = Environment.BG_SKY
        env.sky = sky
    else:
        env.background_mode = Environment.BG_COLOR
        env.background_color = Color(0.02, 0.025, 0.03)

    quad = MeshInstance3D.new()
    quad.mesh = QuadMesh.new()
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED  # the curved screen is seen from inside; never cull it
    mat.albedo_texture = ui_vp.get_texture()
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
    quad.material_override = mat
    quad.visible = false
    add_child(quad)

    vp_l = _eye_viewport()
    vp_r = _eye_viewport()
    cam_l = _eye_camera(env)
    cam_r = _eye_camera(env)
    vp_l.add_child(cam_l)
    vp_r.add_child(cam_r)

    layer = CanvasLayer.new()
    layer.layer = 50
    layer.visible = false
    add_child(layer)
    var bg := ColorRect.new()
    bg.color = Color.BLACK
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(bg)
    mat_l = _eye_rect(vp_l, 0.0, 0.5)
    mat_r = _eye_rect(vp_r, 0.5, 1.0)


func _eye_viewport() -> SubViewport:
    var v := SubViewport.new()
    v.size = Vector2i(640, 720)
    v.render_target_update_mode = SubViewport.UPDATE_DISABLED
    add_child(v)
    return v


func _eye_camera(env: Environment) -> Camera3D:
    var c := Camera3D.new()
    c.fov = 90.0
    c.near = 0.05
    c.far = 100.0
    c.environment = env
    c.current = true
    return c


func _eye_rect(vp: SubViewport, a0: float, a1: float) -> ShaderMaterial:
    var r := TextureRect.new()
    r.anchor_left = a0
    r.anchor_right = a1
    r.anchor_top = 0.0
    r.anchor_bottom = 1.0
    r.texture = vp.get_texture()
    r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    r.stretch_mode = TextureRect.STRETCH_SCALE
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var m := ShaderMaterial.new()
    m.shader = load(LENS_SHADER) as Shader
    r.material = m
    var ret := GazeReticle.new()
    ret.eye_mode = true
    r.add_child(ret)
    layer.add_child(r)
    return m


func _apply(force: bool = false) -> void:
    var on: bool = bool(Settings.data["vr_enabled"])
    if on == _active and not force:
        return
    _active = on
    var mode := SubViewport.UPDATE_ALWAYS if on else SubViewport.UPDATE_DISABLED
    if on:
        if shell.get_parent() != ui_vp:
            shell.reparent(ui_vp, false)
    else:
        if shell.get_parent() != _flat_parent:
            shell.reparent(_flat_parent, false)
            _flat_parent.move_child(shell, 0)
    ui_vp.render_target_update_mode = mode
    vp_l.render_target_update_mode = mode
    vp_r.render_target_update_mode = mode
    layer.visible = on
    quad.visible = on
    _update_sizes()
    _update_params()
    Launcher.refocus()


func _update_sizes() -> void:
    var win := Vector2(DisplayServer.window_get_size())
    var q: float = QUALITY[clampi(int(Settings.data["vr_quality"]), 0, 2)]
    var s := Vector2i(maxi(64, int(win.x * 0.5 * q)), maxi(64, int(win.y * q)))
    vp_l.size = s
    vp_r.size = s


func _curved_mesh(width: float, height: float, radius: float) -> ArrayMesh:
    var segs := 28
    var span := width / radius
    var verts := PackedVector3Array()
    var uvs := PackedVector2Array()
    var idx := PackedInt32Array()
    for i in segs + 1:
        var t := float(i) / float(segs)
        var ang := (t - 0.5) * span
        var x := sin(ang) * radius
        var z := -cos(ang) * radius
        verts.append(Vector3(x, height * 0.5, z))
        uvs.append(Vector2(t, 0.0))
        verts.append(Vector3(x, -height * 0.5, z))
        uvs.append(Vector2(t, 1.0))
    for i in segs:
        var k := i * 2
        idx.append_array([k, k + 2, k + 1, k + 1, k + 2, k + 3])  # Godot front faces are clockwise
    var arrays := []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = verts
    arrays[Mesh.ARRAY_TEX_UV] = uvs
    arrays[Mesh.ARRAY_INDEX] = idx
    var m := ArrayMesh.new()
    m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    return m


func _update_params() -> void:
    var cinema := Launcher.current == "cinema"
    var dist: float = float(Settings.data["cinema_distance"]) if cinema else float(Settings.data["screen_distance"])
    var width: float = float(Settings.data["cinema_size"]) if cinema else HOME_PANEL_WIDTH
    var curved: bool = bool(Settings.data.get("cinema_curved", true)) if cinema else bool(Settings.data.get("screen_curved", false))
    var height_off: float = float(Settings.data.get("cinema_height", 0.0)) if cinema else 0.0
    var bright: float = float(Settings.data.get("cinema_brightness", 1.0)) if cinema else 1.0
    if curved:
        quad.mesh = _curved_mesh(width, width * 9.0 / 16.0, dist)
        quad.position = Vector3(0.0, height_off, 0.0)
    else:
        var qm := QuadMesh.new()
        qm.size = Vector2(width, width * 9.0 / 16.0)
        quad.mesh = qm
        quad.position = Vector3(0.0, height_off, -dist)
    (quad.material_override as StandardMaterial3D).albedo_color = Color(bright, bright, bright)
    Pointer.plane_width = width
    Pointer.plane_dist = dist
    Pointer.plane_curved = curved
    var fov: float = float(Settings.data.get("vr_fov", 90.0))
    cam_l.fov = fov
    cam_r.fov = fov
    var off: float = float(Settings.data["lens_offset"])
    var cy: float = 0.5 - float(Settings.data.get("lens_offset_y", 0.0))
    var shifts: Array = [
        [mat_l, -off + float(Settings.data.get("eye_shift_l", 0.0))],
        [mat_r, off + float(Settings.data.get("eye_shift_r", 0.0))],
    ]
    for pair in shifts:
        var m := pair[0] as ShaderMaterial
        m.set_shader_parameter("k1", float(Settings.data["lens_k1"]))
        m.set_shader_parameter("k2", float(Settings.data["lens_k2"]))
        m.set_shader_parameter("lens_center_x", 0.5 + float(pair[1]))
        m.set_shader_parameter("lens_center_y", cy)
    _update_sizes()


func _process(_d: float) -> void:
    if not _active:
        return
    var b := Basis.IDENTITY
    if Settings.data["control_mode"] == "head":
        b = Basis.from_euler(Vector3(Pointer.pitch, -Pointer.yaw, 0.0))
    var half: float = float(Settings.data["ipd"]) / 2000.0
    cam_l.transform = Transform3D(b, b * Vector3(-half, 0.0, 0.0))
    cam_r.transform = Transform3D(b, b * Vector3(half, 0.0, 0.0))


var _touches := {}


func _input(e: InputEvent) -> void:
    if not _active:
        return
    # Emergency exit: three fingers on the screen at once switches VR off (flat mode, touch works again).
    if e is InputEventScreenTouch:
        if e.pressed:
            _touches[e.index] = true
            if _touches.size() >= 3:
                _touches.clear()
                Settings.set_value("vr_enabled", false)
                Launcher.toast("VR off (three-finger exit). Turn it on in Settings > VR display.", false)
        else:
            _touches.erase(e.index)
    # In VR the shell lives in a SubViewport. Touch/mouse coordinates do not match the VR view, so they are
    # NOT forwarded (they selected the wrong items). Only keyboard/gamepad events are forwarded.
    if e is InputEventKey or e is InputEventJoypadButton or e is InputEventJoypadMotion or e is InputEventAction:
        ui_vp.push_input(e)
