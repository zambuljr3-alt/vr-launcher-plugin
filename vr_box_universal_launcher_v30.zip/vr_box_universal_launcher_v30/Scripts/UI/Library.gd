extends Control
## App Library: real installed apps (native bridge), gaze keyboard search, favorites.
## Open with arg "games" (guess by name), "all" or "fav" (edit-favorites mode on).

const Ui = preload("res://Scripts/UI/Ui.gd")
const AppIcon = preload("res://Scripts/UI/AppIcon.gd")
const KEYS := ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]

var _games_only := false
var _query := ""
var _grid: GridContainer
var _title: Label
var _filter_btn: Button
var _fav_btn: Button
var _q_label: Label
var _kb: VBoxContainer
var _scroll: ScrollContainer


func _ready() -> void:
    _games_only = Launcher.page_arg == "games"
    Launcher.fav_edit_mode = Launcher.page_arg == "fav"
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["margin_left", "margin_right"]:
        margin.add_theme_constant_override(s, 60)
    margin.add_theme_constant_override("margin_top", 20)
    margin.add_theme_constant_override("margin_bottom", 14)
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 8)
    margin.add_child(col)
    var head := Ui.header("Apps")
    _title = head.get_child(1) as Label
    _filter_btn = Ui.button("", false, Vector2(190, 52), 20)
    _filter_btn.pressed.connect(func() -> void:
        _games_only = not _games_only
        _fill())
    head.add_child(_filter_btn)
    _fav_btn = Ui.button("", false, Vector2(240, 52), 20)
    _fav_btn.pressed.connect(func() -> void:
        Launcher.fav_edit_mode = not Launcher.fav_edit_mode
        _fill())
    head.add_child(_fav_btn)
    var rf := Ui.button("Refresh", false, Vector2(130, 52), 20)
    rf.pressed.connect(func() -> void: _reload())
    head.add_child(rf)
    var sb := Ui.button("Search", false, Vector2(140, 52), 20)
    sb.pressed.connect(func() -> void: _kb.visible = not _kb.visible)
    head.add_child(sb)
    col.add_child(head)
    _q_label = Ui.label("", 22, Color(0.7, 0.9, 1.0))
    col.add_child(_q_label)
    _kb = _build_keyboard()
    _kb.visible = false
    col.add_child(_kb)
    _scroll = ScrollContainer.new()
    _scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _scroll.follow_focus = true
    _scroll.add_to_group("autoscroll")
    _scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(_scroll)
    _grid = GridContainer.new()
    _grid.columns = 7
    _grid.add_theme_constant_override("h_separation", 16)
    _grid.add_theme_constant_override("v_separation", 12)
    _scroll.add_child(_grid)
    if Apps.has_native():
        Apps.fetch_installed()
    Settings.changed.connect(func(k: String) -> void:
        if k == "favorites":
            _fill())
    Apps.resumed.connect(_reload)
    _fill()


func _reload() -> void:
    if Apps.has_native():
        Apps.fetch_installed()
    _fill()


func _exit_tree() -> void:
    Launcher.fav_edit_mode = false


func _build_keyboard() -> VBoxContainer:
    var kb := VBoxContainer.new()
    kb.add_theme_constant_override("separation", 4)
    for row in KEYS:
        var h := HBoxContainer.new()
        h.alignment = BoxContainer.ALIGNMENT_CENTER
        h.add_theme_constant_override("separation", 4)
        for ch in row:
            var b := Ui.button(ch, false, Vector2(58, 46), 20)
            var c: String = ch
            b.pressed.connect(func() -> void:
                _query += c.to_lower()
                _fill())
            h.add_child(b)
        kb.add_child(h)
    var h2 := HBoxContainer.new()
    h2.alignment = BoxContainer.ALIGNMENT_CENTER
    h2.add_theme_constant_override("separation", 4)
    var sp := Ui.button("Space", false, Vector2(220, 46), 18)
    sp.pressed.connect(func() -> void:
        _query += " "
        _fill())
    var del := Ui.button("Del", false, Vector2(110, 46), 18)
    del.pressed.connect(func() -> void:
        _query = _query.substr(0, maxi(0, _query.length() - 1))
        _fill())
    var clr := Ui.button("Clear", false, Vector2(110, 46), 18)
    clr.pressed.connect(func() -> void:
        _query = ""
        _fill())
    h2.add_child(sp)
    h2.add_child(del)
    h2.add_child(clr)
    kb.add_child(h2)
    return kb


func _fill() -> void:
    for c in _grid.get_children():
        c.queue_free()
    _title.text = "Games" if _games_only else "All apps"
    _filter_btn.text = "Show all" if _games_only else "Games only"
    _fav_btn.text = "Editing favorites: tap app" if Launcher.fav_edit_mode else "Edit favorites"
    Ui.style_button(_fav_btn, Launcher.fav_edit_mode)
    _q_label.text = "Search: %s_" % _query if _query != "" or _kb.visible else ""
    if not Apps.has_native():
        _grid.columns = 1
        var l := Ui.label("The installed-app list only works on the Android phone (needs Godot 4.2+ export with 'Query All Packages'). Nothing is faked here. Real app icons need the native plugin (see README).", 22, Color(1, 1, 1, 0.85))
        l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        l.custom_minimum_size = Vector2(900, 0)
        _grid.add_child(l)
        return
    _grid.columns = 7
    var n := 0
    for a in Apps.installed:
        if _games_only and not bool(a.get("game", false)):
            continue
        if _query != "" and not str(a["name"]).to_lower().contains(_query.strip_edges()):
            continue
        var ic := AppIcon.new()
        ic.setup(a)
        _grid.add_child(ic)
        n += 1
    if n == 0:
        _grid.columns = 1
        _grid.add_child(Ui.label("No matching apps found.", 22))


func handle_back() -> bool:
    if _kb.visible:
        _kb.visible = false
        return true
    return false


func focus_first() -> void:
    var b := find_children("*", "Button", true, false)
    if b.size() > 0:
        (b[0] as Control).grab_focus()
