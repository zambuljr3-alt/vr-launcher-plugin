extends Control
## CINEMA MODE 2.0: big flat/curved virtual screen with real content.
## Sources: Demo pattern | YouTube in the embedded web page (needs the native plugin) | live phone-screen mirror (consent).
## Play/Pause: web = sends the "k" key (YouTube shortcut), mirror = freezes the picture.
## Local video files are NOT supported (Godot plays only Ogg Theora): not implemented.

const Ui = preload("res://Scripts/UI/Ui.gd")
const TestScreen = preload("res://Scripts/UI/TestScreen.gd")
const KEYCODE_K := 39

var _bg: ColorRect
var _bar: VBoxContainer
var _holder: Control
var _demo: Control
var _mirror: TextureRect
var _tap: Button
var _status: Label
var _src_btn: Button
var _act_btn: Button
var _play_btn: Button
var _armed := false
var _web_open := false


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    _bg = ColorRect.new()
    _bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _bg.color = Color(0, 0, 0, 0.9)
    add_child(_bg)
    _holder = Control.new()
    _holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _holder.offset_bottom = -250.0
    _holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_holder)
    _demo = TestScreen.new()
    _holder.add_child(_demo)
    _mirror = TextureRect.new()
    _mirror.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _mirror.stretch_mode = TextureRect.STRETCH_SCALE
    _mirror.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _holder.add_child(_mirror)
    _tap = Button.new()
    _tap.flat = true
    var e := StyleBoxEmpty.new()
    for s in ["normal", "hover", "pressed", "disabled", "focus"]:
        _tap.add_theme_stylebox_override(s, e)
    _tap.pressed.connect(_on_tap)
    Ui.hook(_tap)
    _holder.add_child(_tap)
    _holder.resized.connect(_layout)
    _build_bar()
    Settings.changed.connect(func(_k: String) -> void: _refresh())
    Capture.frame_ready.connect(func(t: Texture2D) -> void:
        if _src() == "capture":
            _mirror.texture = t)
    Web.frame_ready.connect(func(t: Texture2D) -> void:
        if _src() == "web":
            _mirror.texture = t)
    _refresh()
    _layout.call_deferred()


func _exit_tree() -> void:
    if _web_open:
        Web.close()


func _src() -> String:
    return str(Settings.data.get("cinema_source", "demo"))


func _refresh() -> void:
    if _bg == null:
        return
    var src := _src()
    if src == "web" and not _web_open:
        if Web.available():
            Web.open("https://www.youtube.com")
            _web_open = true
        else:
            Launcher.toast("YouTube in Cinema needs the native plugin (not installed). Showing the demo pattern.", true)
            Settings.data["cinema_source"] = "demo"
            src = "demo"
    elif src != "web" and _web_open:
        Web.close()
        _web_open = false
    _demo.visible = src == "demo"
    _mirror.visible = src != "demo"
    _tap.visible = src == "web"
    var b := clampf(float(Settings.data.get("cinema_brightness", 1.0)), 0.2, 1.5)
    _holder.modulate = Color(b, b, b, 1.0)
    match src:
        "web":
            _src_btn.text = "Source: YouTube (web)"
            _act_btn.visible = true
            _act_btn.text = "ARMED: look" if _armed else "Arm tap"
            Ui.style_button(_act_btn, _armed)
            _play_btn.disabled = false
            _status.text = "YouTube desktop site on the cinema screen. Arm tap, look at a video until the ring fills. Play/Pause sends the 'k' key."
        "capture":
            _src_btn.text = "Source: Screen mirror"
            _act_btn.visible = true
            _act_btn.text = "Start capture"
            Ui.style_button(_act_btn, false)
            _play_btn.disabled = false
            _status.text = "Live mirror of the phone screen (Android consent dialog, needs the native plugin). Protected content may be black."
        _:
            _src_btn.text = "Source: Demo pattern"
            _act_btn.visible = false
            _play_btn.disabled = true
            _status.text = "Demo test pattern. Choose YouTube (web) or Screen mirror for real content."
    _play_btn.text = "Play" if Capture.paused and src == "capture" else "Pause"
    _tap.focus_mode = Control.FOCUS_ALL if (_armed and src == "web") else Control.FOCUS_NONE
    _layout()


func _layout() -> void:
    if _holder == null:
        return
    var area := _holder.size
    var s := 1.0 if bool(Settings.data["vr_enabled"]) else clampf(float(Settings.data["cinema_size"]) / 12.0, 0.35, 1.0)
    var w := minf(area.x * s, area.y * s * 16.0 / 9.0)
    var sz := Vector2(w, w * 9.0 / 16.0)
    for c in [_demo, _mirror, _tap]:
        (c as Control).size = sz
        (c as Control).position = (area - sz) * 0.5


func _on_tap() -> void:
    var mode: String = Settings.data["control_mode"]
    var rect := _tap.get_global_rect()
    var gp: Vector2 = rect.position + rect.size * 0.5
    if mode == "head":
        gp = Pointer.cursor_ui
    elif mode == "touch":
        gp = get_viewport().get_mouse_position()
    var rel := ((gp - rect.position) / rect.size).clamp(Vector2.ZERO, Vector2.ONE)
    Web.tap(Vector2(rel.x * Web.W, rel.y * Web.H))
    if _armed:
        _armed = false
        _refresh()


func _on_act() -> void:
    if _src() == "web":
        _armed = not _armed
        _refresh()
    elif _src() == "capture":
        Launcher.toast(Capture.request(), not Capture.available())


func _on_play() -> void:
    if _src() == "web":
        Web.key(KEYCODE_K)
    elif _src() == "capture":
        Capture.paused = not Capture.paused
        _refresh()


func _flag(on_text: String, off_text: String, key: String) -> Button:
    var b := Ui.button("", false, Vector2(190, 56), 20)
    var refresh := func() -> void:
        var on: bool = bool(Settings.data.get(key, false))
        b.text = on_text if on else off_text
        Ui.style_button(b, on)
    b.pressed.connect(func() -> void:
        Settings.set_value(key, not bool(Settings.data.get(key, false)))
        refresh.call())
    refresh.call()
    return b


func _row(bar: VBoxContainer) -> HBoxContainer:
    var r := HBoxContainer.new()
    r.alignment = BoxContainer.ALIGNMENT_CENTER
    r.add_theme_constant_override("separation", 16)
    bar.add_child(r)
    return r


func _build_bar() -> void:
    _bar = VBoxContainer.new()
    _bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    _bar.offset_top = -240.0
    _bar.offset_left = 30.0
    _bar.offset_right = -30.0
    _bar.offset_bottom = -8.0
    _bar.add_theme_constant_override("separation", 6)
    _bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_bar)
    var r1 := _row(_bar)
    var home := Ui.button("Home", true, Vector2(120, 56))
    home.pressed.connect(func() -> void: Launcher.go_home())
    r1.add_child(home)
    r1.add_child(Ui.stepper("Size", "cinema_size", 4.0, 16.0, 1.0, "%.0f m", 60.0, 80.0))
    r1.add_child(Ui.stepper("Dist", "cinema_distance", 2.0, 10.0, 0.5, "%.1f m", 60.0, 80.0))
    var r2 := _row(_bar)
    r2.add_child(Ui.stepper("Bright", "cinema_brightness", 0.3, 1.5, 0.1, "%.1f", 80.0, 80.0))
    r2.add_child(Ui.stepper("Height", "cinema_height", -2.0, 2.0, 0.25, "%.2f m", 80.0, 80.0))
    r2.add_child(_flag("Curved screen", "Flat screen", "cinema_curved"))
    var r3 := _row(_bar)
    _src_btn = Ui.button("", false, Vector2(300, 56), 20)
    _src_btn.pressed.connect(func() -> void:
        var order := ["demo", "web", "capture"]
        var i := order.find(_src())
        Settings.set_value("cinema_source", order[(i + 1) % order.size()]))
    r3.add_child(_src_btn)
    _act_btn = Ui.button("", true, Vector2(200, 56), 20)
    _act_btn.pressed.connect(_on_act)
    r3.add_child(_act_btn)
    _play_btn = Ui.button("Pause", false, Vector2(140, 56), 20)
    _play_btn.pressed.connect(_on_play)
    r3.add_child(_play_btn)
    _status = Ui.label("", 15, Color(1, 1, 1, 0.75))
    _status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _bar.add_child(_status)


func handle_back() -> bool:
    if _armed:
        _armed = false
        _refresh()
        return true
    return false


func focus_first() -> void:
    var b := find_children("*", "Button", true, false)
    if b.size() > 0:
        (b[0] as Control).grab_focus()
