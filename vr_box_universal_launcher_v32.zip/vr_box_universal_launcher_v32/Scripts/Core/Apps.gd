extends Node
## Application catalogue + launching (autoload "Apps").
## Real launching/listing needs the native Android plugin "VRLauncherPlugin"
## (source in Android/VRLauncherPlugin). Without it every external app is a
## clearly-labelled DEMO shortcut that reports an error instead of pretending.

const HOME_APPS: Array = [
    {"name": "Camera", "pkgs": ["com.android.camera", "com.android.camera2"], "color": "#ECEFF4", "icon": "app_camera", "glyph": "Ca"},
    {"name": "Gallery", "pkgs": ["com.miui.gallery", "com.google.android.apps.photos"], "color": "#D81B60", "icon": "app_gallery", "glyph": "Ga"},
    {"name": "Internet", "web": "https://www.google.com", "url": "https://www.google.com", "pkgs": ["com.sec.android.app.sbrowser", "com.android.browser", "com.mi.globalbrowser"], "color": "#5E35B1", "icon": "app_internet", "glyph": "In"},
    {"name": "Netflix", "url": "https://www.netflix.com", "pkgs": ["com.netflix.mediaclient"], "color": "#141414", "icon": "app_netflix", "glyph": "N", "icon_size": 50},
    {"name": "Settings", "internal": "settings", "color": "#2B2F3A", "icon": "app_settings", "glyph": "S"},
    {"name": "Chrome", "web": "https://www.google.com", "url": "https://www.google.com", "pkgs": ["com.android.chrome"], "color": "#F7F8FA", "icon": "app_browser", "glyph": "Ch", "icon_size": 74},
    {"name": "Maps", "web": "https://www.google.com/maps", "url": "https://maps.google.com", "pkgs": ["com.google.android.apps.maps"], "color": "#F7F8FA", "icon": "app_maps", "glyph": "M", "icon_size": 56},
    {"name": "YouTube", "web": "https://m.youtube.com", "url": "https://www.youtube.com", "pkgs": ["com.google.android.youtube"], "color": "#F7F8FA", "icon": "app_video", "glyph": "Yt", "icon_size": 62},
    {"name": "Photos", "url": "https://photos.google.com", "pkgs": ["com.google.android.apps.photos"], "color": "#F7F8FA", "icon": "app_photos", "glyph": "Ph", "icon_size": 58},
    {"name": "Play Store", "url": "https://play.google.com/store", "pkgs": ["com.android.vending"], "color": "#F7F8FA", "icon": "app_store", "glyph": "Ps"},
    {"name": "Google", "web": "https://www.google.com", "url": "https://www.google.com", "pkgs": ["com.google.android.googlequicksearchbox"], "color": "#F7F8FA", "glyph": "G", "glyph_color": "#4285F4"},
    {"name": "Music", "web": "https://music.youtube.com", "url": "https://music.youtube.com", "pkgs": ["com.miui.player", "com.google.android.apps.youtube.music", "com.spotify.music", "com.sec.android.app.music"], "color": "#EF6C00", "icon": "app_music", "glyph": "M", "icon_size": 56},
    # Launcher-internal pages (these are real and always work):
    {"name": "Games", "internal": "library", "arg": "games", "color": "#7B1FA2", "icon": "app_games", "glyph": "G"},
    {"name": "All Apps", "internal": "library", "arg": "all", "color": "#37474F", "icon": "ic_recents"},
    {"name": "Cinema", "internal": "cinema", "color": "#00695C", "icon": "ic_cinema"},
    {"name": "VR Display", "internal": "vr", "color": "#1565C0", "icon": "ic_vr"},
    {"name": "Controls", "internal": "controls", "color": "#455A64", "icon": "ic_gamepad"},
]
const ANDROID_SETTINGS := {"name": "Android Settings", "pkgs": ["com.android.settings"]}
const GOOGLE := {"name": "Google", "url": "https://www.google.com", "pkgs": ["com.google.android.googlequicksearchbox"]}
const ASSISTANT := {"name": "Assistant", "url": "https://www.google.com", "pkgs": ["com.google.android.googlequicksearchbox"]}

signal resumed
var plugin: Object = null
var native_plugin := false
var recents: Array = []
var installed: Array = []
## Number of bundled icon files that failed to load (shown in the top-left status chip).
var icons_missing := 0


func _ready() -> void:
    var Bridge := preload("res://Scripts/Core/AndroidBridge.gd")
    # The native plugin is preferred: it can return real app icons and do screen capture.
    if Engine.has_singleton("VRLauncherPlugin"):
        plugin = Engine.get_singleton("VRLauncherPlugin")
        native_plugin = true
    elif Bridge.is_supported():
        plugin = Bridge.new()  # GDScript bridge: launch/list/status only, no icons (Godot 4.2+)


func has_native() -> bool:
    return plugin != null


func launch(app: Dictionary) -> void:
    if Launcher.clicks_blocked():
        return
    if Launcher.fav_edit_mode and not app.has("internal"):
        toggle_favorite(app)
        var now := is_favorite(app)
        Launcher.toast(("Added %s to favorites" if now else "Removed %s from favorites") % str(app.get("name", "app")), false)
        return
    if app.has("internal"):
        Launcher.go(str(app["internal"]), str(app.get("arg", "")))
        return
    var target := inside_target(app)
    if target != "":
        _remember(app)
        Launcher.go("browser", target)
        return
    var mode := str(Settings.data.get("open_mode", "auto"))
    if mode != "real" and native_plugin and app.has("pkgs"):
        # Shizuku is installed but not ready yet (connecting / permission / not running): show the setup page instead of
        # silently opening the real app. "Window" mode always shows it.
        var st := Win.status()
        if mode == "window" or st == "connecting" or st == "no_permission" or st == "not_running":
            _remember(app)
            Launcher.go("browser", "app:" + _pick_pkg(app))
            return
    if mode != "real" and native_plugin and (app.has("pkgs") or app.has("web")):
        Launcher.toast("Inside-launcher mode unavailable (Shizuku status: %s). Opening the real app." % Win.status(), false)
    elif mode != "real" and not native_plugin and (app.has("pkgs") or app.has("web")):
        Launcher.toast("Inside-launcher mode needs the native plugin (not installed): opening the real app instead.", false)
    launch_external(app)


## "app:<package>" (virtual-display window), a URL (embedded web page) or "" (open the real app).
func inside_target(app: Dictionary) -> String:
    var mode := str(Settings.data.get("open_mode", "auto"))
    if mode == "real" or not native_plugin or plugin == null:
        return ""
    if (mode == "auto" or mode == "window") and app.has("pkgs") and Win.ready():
        return "app:" + _pick_pkg(app)
    if (mode == "auto" or mode == "web") and app.has("web") and Web.available():
        return str(app["web"])
    return ""


func _pick_pkg(app: Dictionary) -> String:
    var pkgs: Array = app.get("pkgs", [])
    for p in pkgs:
        if bool(plugin.call("isInstalled", str(p))):
            return str(p)
    return str(pkgs[0]) if not pkgs.is_empty() else ""


## Opens the real Android app (full screen, not inside the launcher).
func launch_external(app: Dictionary) -> void:
    var app_name := str(app.get("name", "App"))
    if plugin == null:
        if _open_link(app):
            return
        Launcher.toast("Can't open %s: Android bridge not active here (editor/desktop, or Godot older than 4.2)." % app_name, true)
        return
    var last := "not_installed"
    for pkg in app.get("pkgs", []):
        last = str(plugin.call("launchPackage", str(pkg)))
        if last == "ok":
            _remember(app)
            Launcher.toast("Opening %s" % app_name, false)
            return
        if last != "not_installed":
            break
    if _open_link(app):
        return
    if last == "not_installed":
        Launcher.toast("%s is not installed on this device." % app_name, true)
    else:
        Launcher.toast("Could not open %s: %s" % [app_name, last], true)


## Fallback: hand a web link to Android; the OS opens the matching app or the browser.
## Android gives no success/failure result for this, so the toast says "asked", not "opened".
func _open_link(app: Dictionary) -> bool:
    if OS.get_name() != "Android" or not app.has("url"):
        return false
    OS.shell_open(str(app["url"]))
    _remember(app)
    Launcher.toast("Asked Android to open %s via link (app-launch bridge not used)." % str(app.get("name", "app")), false)
    return true


func _remember(app: Dictionary) -> void:
    for i in recents.size():
        if recents[i].get("name", "") == app.get("name", ""):
            recents.remove_at(i)
            break
    recents.push_front(app)
    if recents.size() > 6:
        recents.resize(6)


func fetch_installed() -> Array:
    installed = []
    if plugin == null:
        return installed
    var parsed: Variant = JSON.parse_string(str(plugin.call("getInstalledApps")))
    if typeof(parsed) != TYPE_ARRAY:
        return installed
    for e in parsed:
        if typeof(e) != TYPE_DICTIONARY:
            continue
        var label := str(e.get("label", e.get("package", "?")))
        var d := {
            "name": label,
            "pkgs": [str(e.get("package", ""))],
            "game": bool(e.get("isGame", false)) or str(e.get("package", "")).contains("game") or label.to_lower().contains("game"),
            "color": Color.from_hsv(float(hash(label) % 360) / 360.0, 0.45, 0.55),
            "glyph": label.substr(0, 1).to_upper(),
        }
        if e.has("icon"):
            d["icon_b64"] = str(e["icon"])
            var img := Image.new()
            if img.load_png_from_buffer(Marshalls.base64_to_raw(str(e["icon"]))) == OK:
                d["tex"] = ImageTexture.create_from_image(img)
        installed.append(d)
    installed.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return str(a["name"]).to_lower() < str(b["name"]).to_lower())
    return installed


var last_status_raw := "(not requested yet)"


## Text for the Settings > diagnostics box: why is the Android bridge (not) working?
func diag() -> String:
    var v: Dictionary = Engine.get_version_info()
    var t := "Godot %s | OS: %s\n" % [str(v.get("string", "?")), OS.get_name()]
    t += "AndroidRuntime singleton: %s\n" % str(Engine.has_singleton("AndroidRuntime"))
    t += "Bridge active: %s\n" % str(plugin != null)
    if plugin != null:
        last_status_raw = str(plugin.call("getStatus"))
    t += "Native plugin (icons, web screen, capture): %s\n" % ("installed" if native_plugin else "NOT installed")
    t += "Virtual-display windows (Shizuku): %s\n" % Win.status()
    t += "getStatus: %s\n" % last_status_raw
    t += compat_text()
    return t


# ----------------------------------------------------------------- favorites
func _same(a: Dictionary, b: Dictionary) -> bool:
    if str(a.get("name", "")) != str(b.get("name", "")):
        return false
    return true


func favorites() -> Array:
    var out: Array = []
    for f in Settings.data.get("favorites", []):
        if typeof(f) == TYPE_DICTIONARY:
            out.append(f.duplicate())
    return out


func is_favorite(app: Dictionary) -> bool:
    for f in favorites():
        if _same(f, app):
            return true
    return false


func toggle_favorite(app: Dictionary) -> bool:
    var favs: Array = Settings.data.get("favorites", []).duplicate()
    for i in favs.size():
        if _same(favs[i], app):
            favs.remove_at(i)
            Settings.set_value("favorites", favs)
            return false
    if favs.size() >= 5:
        Launcher.toast("Favorites dock is full (max 5). Remove one first.", true)
        return false
    var keep := {}
    for k in ["name", "pkgs", "url", "color", "glyph", "glyph_color", "icon", "icon_size", "internal", "arg", "icon_b64"]:
        if app.has(k):
            keep[k] = app[k]
    if app.has("color") and typeof(app["color"]) == TYPE_COLOR:
        keep["color"] = "#" + (app["color"] as Color).to_html(false)
    favs.append(keep)
    Settings.set_value("favorites", favs)
    return true


func icon_texture(app: Dictionary) -> Texture2D:
    if app.has("tex"):
        return app["tex"] as Texture2D
    if app.has("icon_b64"):
        var img := Image.new()
        if img.load_png_from_buffer(Marshalls.base64_to_raw(str(app["icon_b64"]))) == OK:
            return ImageTexture.create_from_image(img)
    if app.has("icon"):
        var path := "res://Assets/Icons/%s.png" % str(app["icon"])
        if ResourceLoader.exists(path):
            return load(path) as Texture2D
    return null


# ------------------------------------------------- window-mode compatibility log
func set_compat(pkg: String, status: String) -> void:
    var c: Dictionary = Settings.data.get("compat", {}).duplicate()
    c[pkg] = status
    Settings.set_value("compat", c)


func compat_text() -> String:
    var c: Dictionary = Settings.data.get("compat", {})
    if c.is_empty():
        return "Window mode results: none yet"
    var t := "Window mode results:"
    var n := 0
    for k in c.keys():
        t += "\n  %s: %s" % [str(k), str(c[k]).left(60)]
        n += 1
        if n >= 8:
            break
    return t


## When the user comes back to the launcher (e.g. after installing from Play Store) tell the Library to refresh.
func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_RESUMED:
        resumed.emit()
