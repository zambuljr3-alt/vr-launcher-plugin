extends Node
## Apps in a virtual display (autoload "Win"). Native plugin + Shizuku required. Untested.
## Same interface as Web (open/close/tap/scroll/back/forward/text/key + frame_ready) so one page serves both.

signal frame_ready(tex: Texture2D)

const W := 1024
const H := 576
const DPI := 213

var texture: ImageTexture = null
var _timer: Timer


func _ready() -> void:
    _timer = Timer.new()
    _timer.wait_time = 0.066
    _timer.timeout.connect(_poll)
    add_child(_timer)
    # Pre-warm: asking for the status binds the Shizuku shell service, so it is already connected when you open an app.
    var warm := Timer.new()
    warm.wait_time = 4.0
    warm.autostart = true
    warm.timeout.connect(func() -> void:
        if available():
            status())
    add_child(warm)


func available() -> bool:
    return Apps.native_plugin and Apps.plugin != null


## no_plugin | not_installed | not_running | no_permission | connecting | ready
func status() -> String:
    if not available():
        return "no_plugin"
    return str(Apps.plugin.call("shizukuStatus"))


func ready() -> bool:
    return status() == "ready"


func request_permission() -> void:
    if available():
        Apps.plugin.call("shizukuRequest")


func last_message() -> String:
    return str(Apps.plugin.call("vdLastMessage")) if available() else ""


func open(pkg: String) -> void:
    if available():
        Apps.plugin.call("vdOpen", pkg, W, H, DPI)
        _timer.start()


func close() -> void:
    _timer.stop()
    if available():
        Apps.plugin.call("vdClose")


func load_url(_url: String) -> void:
    pass


func tap(p: Vector2) -> void:
    if available():
        Apps.plugin.call("vdTap", int(p.x), int(p.y))


## dy > 0 scrolls down (finger moves up).
func scroll(dy: int) -> void:
    if available():
        var y1 := int(H * (0.7 if dy > 0 else 0.3))
        var y2 := int(H * (0.3 if dy > 0 else 0.7))
        Apps.plugin.call("vdSwipe", W / 2, y1, W / 2, y2, 300)


## Swipe like a thumb: next short = finger moves up.
func short_next() -> void:
    if available():
        Apps.plugin.call("vdSwipe", W / 2, int(H * 0.8), W / 2, int(H * 0.2), 150)


func short_prev() -> void:
    if available():
        Apps.plugin.call("vdSwipe", W / 2, int(H * 0.2), W / 2, int(H * 0.8), 150)


func back() -> void:
    key(4)  # KEYCODE_BACK


func forward() -> void:
    pass


func text(s: String) -> void:
    if available():
        Apps.plugin.call("vdText", s)


func key(code: int) -> void:
    if available():
        Apps.plugin.call("vdKey", code)


func _poll() -> void:
    if not available():
        return
    var b64 := str(Apps.plugin.call("vdGetFrame"))
    if b64 == "":
        return
    var img := Image.new()
    if img.load_jpg_from_buffer(Marshalls.base64_to_raw(b64)) != OK:
        return
    if texture == null or texture.get_size() != Vector2(img.get_size()):
        texture = ImageTexture.create_from_image(img)
    else:
        texture.update(img)
    frame_ready.emit(texture)
