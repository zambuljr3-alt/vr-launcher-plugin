extends Control
## DIAGNOSTICS: one button runs every check for "apps inside VR" and shows the result in large text, with a live picture
## of the test app (Android Settings) if the virtual display works. Send a screenshot of this page if something fails.

const Ui = preload("res://Scripts/UI/Ui.gd")

var _out: Label
var _img: TextureRect
var _frames := 0
var _running := false


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["margin_left", "margin_right"]:
        margin.add_theme_constant_override(s, 50)
    margin.add_theme_constant_override("margin_top", 20)
    margin.add_theme_constant_override("margin_bottom", 16)
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 10)
    margin.add_child(col)
    col.add_child(Ui.header("Diagnostics"))
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 20)
    row.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(row)
    var left := VBoxContainer.new()
    left.custom_minimum_size = Vector2(640, 0)
    left.add_theme_constant_override("separation", 10)
    row.add_child(left)
    var run := Ui.button("Run test", true, Vector2(0, 64), 24)
    run.pressed.connect(_run)
    left.add_child(run)
    var perm := Ui.button("Ask Shizuku permission", false, Vector2(0, 52), 20)
    perm.pressed.connect(func() -> void:
        Win.request_permission()
        Launcher.toast("Permission requested: allow this launcher in the Shizuku dialog.", false))
    left.add_child(perm)
    var shz := Ui.button("Open Shizuku app", false, Vector2(0, 52), 20)
    shz.pressed.connect(func() -> void: Apps.launch_external({"name": "Shizuku", "pkgs": ["moe.shizuku.privileged.api"]}))
    left.add_child(shz)
    _out = Ui.label("Press 'Run test'. Version: %s" % Launcher.VERSION, 20)
    _out.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _out.custom_minimum_size = Vector2(640, 0)
    left.add_child(_out)
    _img = TextureRect.new()
    _img.custom_minimum_size = Vector2(480, 270)
    _img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _img.stretch_mode = TextureRect.STRETCH_SCALE
    var holder := PanelContainer.new()
    holder.add_theme_stylebox_override("panel", Ui.glass(12, 0.8))
    holder.add_child(_img)
    row.add_child(holder)
    Win.frame_ready.connect(func(t: Texture2D) -> void:
        _frames += 1
        _img.texture = t)


func _hint(st: String) -> String:
    match st:
        "no_plugin":
            return "FIX: this APK has no native plugin. Build with the full workflow (Build APK release)."
        "not_installed":
            return "FIX: install the Shizuku app, then start it (Developer options > Wireless debugging)."
        "not_running":
            return "FIX: open Shizuku and press Start (wireless debugging). Needed after every phone restart."
        "no_permission":
            return "FIX: press 'Ask Shizuku permission' and Allow this launcher in the Shizuku dialog."
        "connecting":
            return "WAIT: connecting to the Shizuku shell service. Press Run test again in a few seconds."
    return ""


func _run() -> void:
    if _running:
        return
    _running = true
    _frames = 0
    _img.texture = null
    var t := "Version: %s\n" % Launcher.VERSION
    t += "1. Native plugin: %s\n" % ("OK" if Apps.native_plugin else "MISSING")
    var st: String = Win.status()
    t += "2. Shizuku status: %s\n" % st
    _out.text = t
    if st != "ready":
        t += _hint(st)
        _out.text = t
        _running = false
        return
    t += "3. Starting the Android Settings app on a virtual display...\n"
    _out.text = t
    Win.open("com.android.settings")
    await get_tree().create_timer(6.0).timeout
    if not is_instance_valid(self):
        return
    t += "4. Pictures received: %d\n" % _frames
    t += "5. Shell output: %s\n" % Win.last_message()
    if _frames > 0:
        t += "RESULT: WORKS. Apps can open inside VR (picture on the right)."
    else:
        t += "RESULT: NO PICTURE. Shizuku is ready but Android did not show the app. Send a screenshot of this page."
    _out.text = t
    Win.close()
    _running = false


func _exit_tree() -> void:
    Win.close()


func focus_first() -> void:
    var b := find_children("*", "Button", true, false)
    if b.size() > 0:
        (b[0] as Control).grab_focus()
