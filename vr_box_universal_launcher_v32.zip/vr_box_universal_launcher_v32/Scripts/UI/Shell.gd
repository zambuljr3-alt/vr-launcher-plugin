extends Control
## Root of the launcher UI: wallpaper, page host + transitions, toast, overlays.
## Lives in the window (flat mode) or inside a SubViewport (VR mode).

const GazeReticle = preload("res://Scripts/Controller/GazeReticle.gd")
const CalGrid = preload("res://Scripts/VR/CalGrid.gd")
const Ui = preload("res://Scripts/UI/Ui.gd")
const PAGES := {
    "home": "res://Scenes/Home.tscn",
    "settings": "res://Scenes/SettingsHub.tscn",
    "controls": "res://Scenes/ControlSettings.tscn",
    "vr": "res://Scenes/VRSettings.tscn",
    "cinema": "res://Scenes/Cinema.tscn",
    "library": "res://Scenes/Library.tscn",
    "headset": "res://Scenes/Headset.tscn",
    "browser": "res://Scenes/Browser.tscn",
    "diag": "res://Scenes/Diag.tscn",
}

var _host: Control
var _page: Control = null
var _toast: PanelContainer
var _toast_label: Label
var _toast_tween: Tween
var _hud: Label


func _ready() -> void:
    Launcher.shell = self
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var wp := TextureRect.new()
    wp.texture = load("res://Assets/Backgrounds/forest_wallpaper.jpg") as Texture2D
    wp.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    wp.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    wp.mouse_filter = Control.MOUSE_FILTER_IGNORE
    wp.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(wp)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.38)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    _host = Control.new()
    _host.mouse_filter = Control.MOUSE_FILTER_PASS
    _host.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(_host)
    var grid := CalGrid.new()
    grid.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(grid)
    var ret := GazeReticle.new()
    ret.eye_mode = false
    add_child(ret)
    _build_toast()
    _hud = Ui.label("", 15, Color(1, 1, 1, 0.75))
    _hud.position = Vector2(14, 8)
    _hud.z_index = 80
    _hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_hud)
    var ht := Timer.new()
    ht.wait_time = 0.5
    ht.autostart = true
    ht.timeout.connect(_update_hud)
    add_child(ht)
    _build_quickbar()
    Launcher.page_requested.connect(_on_page)
    Launcher.toast_requested.connect(_show_toast)
    Settings.changed.connect(func(k: String) -> void:
        if k == "control_mode":
            focus_page())
    _show("home", false, true)


## Always-reachable controls for use without touching the phone (top-right).
func _build_quickbar() -> void:
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 8)
    h.z_index = 85
    var rc := Ui.icon_button("ic_recenter", 56.0)
    rc.pressed.connect(func() -> void:
        Pointer.recenter()
        Launcher.toast("View recentered.", false))
    h.add_child(rc)
    var hm := Ui.icon_button("ic_home", 56.0)
    hm.pressed.connect(func() -> void: Launcher.go_home())
    h.add_child(hm)
    add_child(h)
    h.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
    h.offset_left = -140.0
    h.offset_right = -24.0
    h.offset_top = 12.0
    h.offset_bottom = 68.0


func _build_toast() -> void:
    _toast = PanelContainer.new()
    _toast.add_theme_stylebox_override("panel", Ui.glass(24, 0.85))
    _toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _toast.modulate.a = 0.0
    _toast_label = Ui.label("", 22)
    _toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _toast_label.custom_minimum_size = Vector2(620, 0)
    _toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _toast.add_child(_toast_label)
    add_child(_toast)
    _toast.z_index = 90


func _show_toast(message: String, is_error: bool) -> void:
    _toast_label.text = message
    var sb := Ui.glass(24, 0.88)
    sb.border_color = Color(1.0, 0.45, 0.4, 0.9) if is_error else Color(0.45, 0.85, 0.55, 0.9)
    sb.set_border_width_all(2)
    sb.set_content_margin_all(16)
    _toast.add_theme_stylebox_override("panel", sb)
    _toast.size = Vector2.ZERO
    await get_tree().process_frame
    _toast.position = Vector2((size.x - _toast.size.x) * 0.5, size.y - _toast.size.y - 36.0)
    if _toast_tween != null and _toast_tween.is_valid():
        _toast_tween.kill()
    _toast_tween = create_tween()
    _toast_tween.tween_property(_toast, "modulate:a", 1.0, 0.15)
    _toast_tween.tween_interval(3.2)
    _toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.35)


func _on_page(page: String, is_back: bool) -> void:
    _show(page, is_back, false)


func _show(page: String, is_back: bool, instant: bool) -> void:
    var np := (load(PAGES[page]) as PackedScene).instantiate() as Control
    var old := _page
    _page = np
    _host.add_child(np)
    if instant or old == null:
        focus_page()
        return
    # Old page stops being selectable immediately, then fades out.
    old.propagate_call("set", ["focus_mode", Control.FOCUS_NONE])
    var dir := -1.0 if is_back else 1.0
    np.modulate.a = 0.0
    np.position.x = 60.0 * dir
    var t := create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    t.tween_property(np, "modulate:a", 1.0, 0.28)
    t.tween_property(np, "position:x", 0.0, 0.28)
    t.tween_property(old, "modulate:a", 0.0, 0.18)
    t.tween_property(old, "position:x", -60.0 * dir, 0.18)
    t.chain().tween_callback(old.queue_free)
    focus_page()


## Gamepad mode: put focus on the page's first control.
func focus_page() -> void:
    await get_tree().process_frame
    if Settings.data["control_mode"] == "gamepad" and is_instance_valid(_page) and _page.has_method("focus_first"):
        _page.call("focus_first")


func handle_back() -> bool:
    return is_instance_valid(_page) and _page.has_method("handle_back") and bool(_page.call("handle_back"))


func _unhandled_input(e: InputEvent) -> void:
    if e.is_action_pressed("launcher_back"):
        Launcher.back()
        get_viewport().set_input_as_handled()
    elif e.is_action_pressed("launcher_home"):
        Launcher.go_home()
        get_viewport().set_input_as_handled()
    elif e.is_action_pressed("launcher_select"):
        var f := get_viewport().gui_get_focus_owner()
        if f is BaseButton:
            Launcher.activate(f as BaseButton)
            get_viewport().set_input_as_handled()


## Small status chip so you can see what the launcher thinks is happening.
func _update_hud() -> void:
    var mode: String = Settings.data["control_mode"]
    var t := "%s | Control: %s | VR: %s" % [Launcher.VERSION, mode.capitalize(), "ON" if bool(Settings.data["vr_enabled"]) else "off"]
    if mode == "head":
        t += " | " + Pointer.gyro_status().get_slice(":", 0).get_slice("(", 0).strip_edges()
    if Apps.icons_missing > 0:
        t += " | icons missing: %d" % Apps.icons_missing
    if bool(Settings.data.get("show_fps", false)):
        t += " | %d fps" % int(Engine.get_frames_per_second())
    _hud.text = t
