extends Control
## SETTINGS hub: one place to reach every launcher setting.

const Ui = preload("res://Scripts/UI/Ui.gd")


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["margin_left", "margin_right"]:
        margin.add_theme_constant_override(s, 90)
    margin.add_theme_constant_override("margin_top", 26)
    margin.add_theme_constant_override("margin_bottom", 20)
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 18)
    margin.add_child(col)
    col.add_child(Ui.header("Settings"))
    var shz := Ui.label("Shizuku (apps inside VR): " + Win.status(), 22, Color(0.6, 0.9, 1.0))
    col.add_child(shz)
    var grid := GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 20)
    grid.add_theme_constant_override("v_separation", 20)
    col.add_child(grid)
    _item(grid, "Control settings (head / gaze)", func() -> void: Launcher.go("controls"))
    _item(grid, "VR display (IPD, lens, quality)", func() -> void: Launcher.go("vr"))
    _item(grid, "Headset mode (screen, FPS, quality)", func() -> void: Launcher.go("headset"))
    _item(grid, "Cinema", func() -> void: Launcher.go("cinema"))
    _item(grid, "All apps", func() -> void: Launcher.go("library", "all"))
    _item(grid, "Android system settings", func() -> void: Apps.launch(Apps.ANDROID_SETTINGS))
    col.add_child(Ui.choice("Open apps", "open_mode", ["auto", "window", "web", "real"], ["Auto", "Window (Shizuku)", "Web page", "Real app"]))
    col.add_child(Ui.stepper("UI volume", "volume", 0.0, 1.0, 0.1, "%.1f", 300.0, 300.0))
    var note := Ui.label("Android system settings opens the phone's own Settings app and only works on the Android phone.", 17, Color(1, 1, 1, 0.7))
    note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    col.add_child(note)
    var diag := Ui.label(Apps.diag(), 16, Color(0.6, 0.9, 1.0))
    diag.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    col.add_child(diag)


func _item(parent: Control, text: String, cb: Callable) -> void:
    var b := Ui.button(text, false, Vector2(480, 72), 24)
    b.pressed.connect(cb)
    parent.add_child(b)


func focus_first() -> void:
    var b := find_children("*", "Button", true, false)
    if b.size() > 0:
        (b[0] as Control).grab_focus()
