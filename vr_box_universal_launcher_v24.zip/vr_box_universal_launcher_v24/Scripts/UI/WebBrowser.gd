extends Control
## IN-LAUNCHER WINDOW: shows either an embedded web page (Web backend) or a real Android app running on a
## virtual display (Win backend, needs Shizuku). Page arg: a URL, or "app:<package>".
## Head control: press "Arm tap", then look at the target until the ring fills: ONE tap is sent, then it disarms
## (so looking around never clicks by accident). Touch mode taps directly. Needs the plugin (see README).

const Ui = preload("res://Scripts/UI/Ui.gd")
const KEYBOARD := ["1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]
const KEYCODE_ENTER := 66
const KEYCODE_DEL := 67
const SURF := Vector2(1000, 562)

var _surface: Button
var _img: TextureRect
var _kb: PanelContainer
var _arm_btn: Button
var _armed := false
var _marker: Panel
var _url := ""
var _be: Node = Web
var _is_app := false
var _notice: Label


func _ready() -> void:
    _url = Launcher.page_arg if Launcher.page_arg != "" else "https://m.youtube.com"
    _is_app = _url.begins_with("app:")
    _be = Win if _is_app else Web
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["margin_left", "margin_right"]:
        margin.add_theme_constant_override(s, 30)
    margin.add_theme_constant_override("margin_top", 12)
    margin.add_theme_constant_override("margin_bottom", 10)
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 8)
    margin.add_child(col)
    col.add_child(_build_top())
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    col.add_child(row)
    row.add_child(_build_surface())
    row.add_child(_build_side())
    _notice = Ui.label("", 18, Color(1, 0.8, 0.45))
    _notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _notice.position = Vector2(40, 120)
    _notice.size = Vector2(920, 300)
    _surface.add_child(_notice)
    _be.frame_ready.connect(func(t: Texture2D) -> void:
        _img.texture = t
        _notice.text = "")
    _start()
    _build_keyboard()
    _apply_arm()


func _start() -> void:
    _notice.text = ""
    if _is_app:
        var st: String = Win.status()
        if st != "ready":
            _notice.text = _setup_text(st)
            if st == "no_permission":
                Win.request_permission()
            return
        Win.open(_url.substr(4))
        _notice.text = "Starting app on a virtual display..."
        get_tree().create_timer(3.0).timeout.connect(func() -> void:
            if is_instance_valid(self) and _img.texture == null:
                _notice.text = "No picture yet. Shell output: " + Win.last_message())
    else:
        if not Web.available():
            _notice.text = "Embedded web needs the native plugin (Android/VRLauncherPlugin), which is not installed in this build. Nothing is faked: build the AAR (see README) or use 'Real app'."
            return
        Web.open(_url)


func _setup_text(st: String) -> String:
    match st:
        "no_plugin":
            return "Window mode needs the native plugin (not installed). See Docs/VIRTUAL_DISPLAY_SETUP.md."
        "not_installed":
            return "Shizuku is not installed. Install Shizuku, enable Developer options > Wireless debugging, start Shizuku, then press Retry. See Docs/VIRTUAL_DISPLAY_SETUP.md."
        "not_running":
            return "Shizuku is installed but not running. Open Shizuku and start it (Wireless debugging), then press Retry."
        "no_permission":
            return "Shizuku permission requested: allow this launcher in the Shizuku dialog, then press Retry."
    return "Shizuku status: " + st + ". Press Retry."


func _exit_tree() -> void:
    _be.close()  # stop the page/app window (and its audio) when leaving


func _build_top() -> HBoxContainer:
    var h := Ui.header("Web")
    var items: Array = [["< Back", func() -> void: _be.back()]]
    if _is_app:
        items.append(["Retry", func() -> void: _start()])
    else:
        items.append(["Fwd >", func() -> void: _be.forward()])
        items.append(["YouTube", func() -> void: _be.load_url("https://m.youtube.com")])
        items.append(["Google", func() -> void: _be.load_url("https://www.google.com")])
    items.append(["Real app", func() -> void: _open_real()])
    for it in items:
        var b := Ui.button(it[0], false, Vector2(0, 52), 20)
        b.pressed.connect(it[1])
        h.add_child(b)
    return h


func _build_surface() -> Control:
    _surface = Button.new()
    _surface.custom_minimum_size = SURF
    _surface.flat = true
    var e := StyleBoxEmpty.new()
    for s in ["normal", "hover", "pressed", "disabled", "focus"]:
        _surface.add_theme_stylebox_override(s, e)
    var bg := ColorRect.new()
    bg.color = Color(0, 0, 0, 0.85)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _surface.add_child(bg)
    _img = TextureRect.new()
    _img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _img.stretch_mode = TextureRect.STRETCH_SCALE
    _img.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _img.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _surface.add_child(_img)
    _marker = Panel.new()
    var msb := StyleBoxFlat.new()
    msb.bg_color = Color(1, 1, 1, 0.55)
    msb.set_corner_radius_all(16)
    _marker.add_theme_stylebox_override("panel", msb)
    _marker.size = Vector2(32, 32)
    _marker.modulate.a = 0.0
    _marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _surface.add_child(_marker)
    Ui.hook(_surface)
    _surface.pressed.connect(_on_surface_pressed)
    return _surface


func _build_side() -> VBoxContainer:
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    v.custom_minimum_size = Vector2(190, 0)
    _arm_btn = Ui.button("", true, Vector2(190, 110), 22)
    _arm_btn.pressed.connect(func() -> void:
        _armed = not _armed
        _apply_arm())
    v.add_child(_arm_btn)
    var up := Ui.button("Scroll up", false, Vector2(190, 80), 22)
    up.pressed.connect(func() -> void: _be.scroll(-400))
    v.add_child(up)
    var dn := Ui.button("Scroll down", false, Vector2(190, 80), 22)
    dn.pressed.connect(func() -> void: _be.scroll(400))
    v.add_child(dn)
    var kb := Ui.button("Keyboard", false, Vector2(190, 80), 22)
    kb.pressed.connect(func() -> void: _kb.visible = not _kb.visible)
    v.add_child(kb)
    return v


func _build_keyboard() -> void:
    _kb = PanelContainer.new()
    _kb.add_theme_stylebox_override("panel", Ui.glass(18, 0.92))
    _kb.visible = false
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 4)
    _kb.add_child(vb)
    for row in KEYBOARD:
        var h := HBoxContainer.new()
        h.alignment = BoxContainer.ALIGNMENT_CENTER
        h.add_theme_constant_override("separation", 4)
        for ch in row:
            var c: String = ch
            var b := Ui.button(c, false, Vector2(60, 46), 20)
            b.pressed.connect(func() -> void: _be.text(c.to_lower()))
            h.add_child(b)
        vb.add_child(h)
    var h2 := HBoxContainer.new()
    h2.alignment = BoxContainer.ALIGNMENT_CENTER
    h2.add_theme_constant_override("separation", 4)
    var sp := Ui.button("Space", false, Vector2(200, 46), 18)
    sp.pressed.connect(func() -> void: _be.text(" "))
    var del := Ui.button("Del", false, Vector2(100, 46), 18)
    del.pressed.connect(func() -> void: _be.key(KEYCODE_DEL))
    var ent := Ui.button("Enter", true, Vector2(120, 46), 18)
    ent.pressed.connect(func() -> void: _be.key(KEYCODE_ENTER))
    var cls := Ui.button("Close", false, Vector2(100, 46), 18)
    cls.pressed.connect(func() -> void: _kb.visible = false)
    for b in [sp, del, ent, cls]:
        h2.add_child(b)
    vb.add_child(h2)
    add_child(_kb)
    _kb.position = Vector2(110, 360)
    _kb.size = Vector2(700, 300)
    _kb.z_index = 20


func _apply_arm() -> void:
    _arm_btn.text = "Tap ARMED:\nlook at target" if _armed else "Arm tap\n(then look)"
    Ui.style_button(_arm_btn, _armed)
    # Head/gamepad: the surface is only a gaze target while armed (no accidental clicks).
    _surface.focus_mode = Control.FOCUS_ALL if _armed else Control.FOCUS_NONE


func _on_surface_pressed() -> void:
    var mode: String = Settings.data["control_mode"]
    var rect := _surface.get_global_rect()
    var gp: Vector2 = rect.position + rect.size * 0.5
    if mode == "head":
        gp = Pointer.cursor_ui
    elif mode == "touch":
        gp = get_viewport().get_mouse_position()
    var rel := ((gp - rect.position) / rect.size).clamp(Vector2.ZERO, Vector2.ONE)
    _be.tap(Vector2(rel.x * _be.W, rel.y * _be.H))
    _marker.position = rel * _surface.size - Vector2(16, 16)
    _marker.modulate.a = 1.0
    create_tween().tween_property(_marker, "modulate:a", 0.0, 0.45)
    if _armed:
        _armed = false
        _apply_arm()


func _open_real() -> void:
    if _is_app:
        var pkg := _url.substr(4)
        for a in Apps.HOME_APPS:
            if (a.get("pkgs", []) as Array).has(pkg):
                Apps.launch_external(a)
                return
        Apps.launch_external({"name": pkg, "pkgs": [pkg]})
        return
    for a in Apps.HOME_APPS:
        if str(a.get("web", "")) == _url or str(a.get("url", "")) == _url:
            Apps.launch_external(a)
            return
    Apps.launch_external({"name": "Browser", "url": _url, "pkgs": ["com.android.chrome"]})


func handle_back() -> bool:
    if _kb.visible:
        _kb.visible = false
        return true
    return false


func focus_first() -> void:
    var b := find_children("*", "Button", true, false)
    if b.size() > 0:
        (b[0] as Control).grab_focus()
