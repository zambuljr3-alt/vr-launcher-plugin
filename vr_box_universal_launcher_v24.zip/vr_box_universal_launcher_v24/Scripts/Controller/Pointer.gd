extends Node
## Head tracking + gaze selection (autoload "Pointer").
## Integrates Android gyroscope rates into yaw/pitch (drifts - no sensor fusion),
## converts that to a cursor on the UI, and runs the gaze dwell timer.
## Editor testing: hold the RIGHT mouse button and drag to "look".

const DEADZONE := 0.01
const YAW_LIM := 1.2
const PITCH_LIM := 0.9
const FLAT_PIXELS_PER_RAD := 700.0
## [instruction, seconds, records gyro]
const WIZ := [
    ["Look straight ahead", 1.5, false],
    ["Turn head RIGHT and hold", 3.0, true],
    ["Look straight ahead", 1.5, false],
    ["Look UP and hold", 3.0, true],
]

var yaw := 0.0
var pitch := 0.0
var cursor_ui := Vector2(640, 360)
var cursor_visible := false
var gaze_progress := 0.0
var plane_width := 3.2
var plane_dist := 2.0
var plane_curved := false
var _sm := Vector3.ZERO
var hover: Control = null

var wizard_active := false
var wizard_text := ""
var _wiz_phase := 0
var _wiz_t := 0.0
var _wiz_int := Vector3.ZERO
var _wiz_best := Vector3.ZERO
var _wiz_yaw_axis := 0
var _wiz_yaw_sign := 1.0
var _dwell := 0.0
var _bias := Vector3.ZERO
var _calib_left := 0.0
var _calib_sum := Vector3.ZERO
var _calib_n := 0
var _last_motion_s := -1.0


func _ready() -> void:
    Settings.changed.connect(_on_setting)


func _on_setting(key: String) -> void:
    if key == "control_mode":
        recenter()
        _clear_hover()


func recenter() -> void:
    yaw = 0.0
    pitch = 0.0


func calibrate_gyro() -> void:
    _calib_left = 1.5
    _calib_sum = Vector3.ZERO
    _calib_n = 0


func start_direction_wizard() -> void:
    wizard_active = true
    _wiz_phase = -1
    _next_phase()


func cancel_wizard() -> void:
    wizard_active = false
    wizard_text = ""


func _next_phase() -> void:
    _wiz_phase += 1
    if _wiz_phase >= WIZ.size():
        wizard_active = false
        wizard_text = ""
        recenter()
        Launcher.toast("Direction calibrated. Turn right = cursor right, look up = cursor up.", false)
        return
    _wiz_t = float(WIZ[_wiz_phase][1])
    _wiz_int = Vector3.ZERO
    _wiz_best = Vector3.ZERO
    wizard_text = str(WIZ[_wiz_phase][0])
    Sfx.play("tick")


func _run_wizard(g: Vector3, delta: float) -> void:
    cursor_visible = true
    _wiz_t -= delta
    if bool(WIZ[_wiz_phase][2]):
        _wiz_int += g * delta
        for i in 3:
            if absf(_wiz_int[i]) > absf(_wiz_best[i]):
                _wiz_best[i] = _wiz_int[i]
    if _wiz_t > 0.0:
        return
    if not bool(WIZ[_wiz_phase][2]):
        _next_phase()
        return
    var ax := 0
    for i in 3:
        if absf(_wiz_best[i]) > absf(_wiz_best[ax]):
            ax = i
    if absf(_wiz_best[ax]) < 0.25:
        _wiz_fail("Movement too small - turn further and hold. Try again.")
        return
    var sgn := 1.0 if _wiz_best[ax] > 0.0 else -1.0
    if _wiz_phase == 1:
        _wiz_yaw_axis = ax
        _wiz_yaw_sign = sgn
        _next_phase()
    else:
        if ax == _wiz_yaw_axis:
            _wiz_fail("Up/down was detected on the same axis as left/right. Try again (nod, don't turn).")
            return
        Settings.set_value("yaw_axis", _wiz_yaw_axis)
        Settings.set_value("yaw_sign", _wiz_yaw_sign)
        Settings.set_value("pitch_axis", ax)
        Settings.set_value("pitch_sign", sgn)
        Settings.set_value("invert_yaw", false)
        Settings.set_value("invert_pitch", false)
        _next_phase()


func _wiz_fail(msg: String) -> void:
    wizard_active = false
    wizard_text = ""
    Launcher.toast(msg, true)


func is_calibrating() -> bool:
    return _calib_left > 0.0


func gyro_status() -> String:
    if _last_motion_s < 0.0:
        return "No gyroscope data yet (sensor missing/unsupported, or the device is perfectly still)."
    var idle := Time.get_ticks_msec() / 1000.0 - _last_motion_s
    if idle < 2.0:
        return "Gyroscope active: receiving motion data."
    return "Gyroscope idle: no motion for %d s." % int(idle)


func _input(event: InputEvent) -> void:
    # Desktop testing (no gyroscope on PC): moving the mouse "looks around" in Head mode; dragging with the
    # right button also works. On a phone the real gyroscope is used.
    if event is InputEventMouseMotion:
        var rmb: bool = (event.button_mask & MOUSE_BUTTON_MASK_RIGHT) != 0
        if rmb or (OS.has_feature("pc") and Settings.data["control_mode"] == "head"):
            yaw = clampf(yaw + event.relative.x * 0.003, -YAW_LIM, YAW_LIM)
            pitch = clampf(pitch - event.relative.y * 0.003, -PITCH_LIM, PITCH_LIM)


func _process(delta: float) -> void:
    var mode: String = Settings.data["control_mode"]
    if mode != "head":
        cursor_visible = false
        gaze_progress = 0.0
        if hover != null:
            _clear_hover()
        if Launcher.current == "controls" or bool(Settings.data["vr_enabled"]):
            _track_motion(Input.get_gyroscope())  # only to show sensor status
        return
    var g := Input.get_gyroscope()
    _track_motion(g)
    if _calib_left > 0.0:
        _calib_left -= delta
        _calib_sum += g
        _calib_n += 1
        if _calib_left <= 0.0 and _calib_n > 0:
            _bias = _calib_sum / float(_calib_n)
        return
    if wizard_active:
        _run_wizard(g - _bias, delta)
        return
    _integrate(g - _bias, delta)
    var on_plane := _update_cursor()
    cursor_visible = on_plane
    if on_plane:
        _autoscroll(delta)
    _update_gaze(delta, on_plane)


func _track_motion(g: Vector3) -> void:
    if g.length() > 0.0005:
        _last_motion_s = Time.get_ticks_msec() / 1000.0


func _integrate(g: Vector3, delta: float) -> void:
    # Exponential low-pass on the gyro rate (anti-jitter). smoothing 0 = raw, 0.9 = very smooth.
    var a: float = clampf(float(Settings.data.get("smoothing", 0.5)), 0.0, 0.95)
    _sm = _sm.lerp(g, 1.0 - pow(a, delta * 60.0))
    g = _sm
    var ya: int = clampi(int(Settings.data.get("yaw_axis", 0)), 0, 2)
    var pa: int = clampi(int(Settings.data.get("pitch_axis", 1)), 0, 2)
    var ry: float = g[ya] * float(Settings.data.get("yaw_sign", 1.0))
    var rp: float = g[pa] * float(Settings.data.get("pitch_sign", 1.0))
    var dz: float = float(Settings.data.get("deadzone", DEADZONE))
    if absf(ry) < dz:
        ry = 0.0
    if absf(rp) < dz:
        rp = 0.0
    var s: float = float(Settings.data["sensitivity"])
    var sy := -1.0 if bool(Settings.data["invert_yaw"]) else 1.0
    var sp := -1.0 if bool(Settings.data["invert_pitch"]) else 1.0
    yaw = clampf(yaw + ry * delta * s * sy, -YAW_LIM, YAW_LIM)
    pitch = clampf(pitch + rp * delta * s * sp, -PITCH_LIM, PITCH_LIM)


## Returns true when the view ray hits the UI panel.
func _update_cursor() -> bool:
    var size := Launcher.shell_size()
    var raw: Vector2
    if bool(Settings.data["vr_enabled"]):
        var px_per_m := size.x / plane_width
        var x := tan(yaw) * plane_dist
        var y := tan(pitch) / maxf(cos(yaw), 0.05) * plane_dist
        if plane_curved:  # cylinder around the eye: arc length = yaw * radius
            x = yaw * plane_dist
            y = tan(pitch) * plane_dist
        raw = size * 0.5 + Vector2(x, -y) * px_per_m
    else:
        raw = size * 0.5 + Vector2(yaw, -pitch) * FLAT_PIXELS_PER_RAD
    var inside := Rect2(Vector2.ZERO, size).has_point(raw)
    cursor_ui = raw.clamp(Vector2.ZERO, size)
    return inside or not bool(Settings.data["vr_enabled"])


func _update_gaze(delta: float, on_plane: bool) -> void:
    if hover != null and not is_instance_valid(hover):
        hover = null
    var target: Control = _hit_test(cursor_ui) if on_plane else null
    if target != hover:
        _set_hover(target)
        _dwell = 0.0
    if hover == null:
        gaze_progress = 0.0
        return
    _dwell += delta
    var need := maxf(float(Settings.data["gaze_time"]), 0.2)
    gaze_progress = clampf(_dwell / need, 0.0, 1.0)
    if _dwell >= need:
        var t := hover
        _dwell = -0.8  # cool-down so one look = one click
        gaze_progress = 0.0
        Sfx.play("select")
        if t is BaseButton:
            Launcher.activate(t as BaseButton)


## Looking at the top/bottom edge of a scrollable page scrolls it (no touch/gamepad needed).
func _autoscroll(delta: float) -> void:
    for n in get_tree().get_nodes_in_group("autoscroll"):
        var sc := n as ScrollContainer
        if sc == null or not sc.is_visible_in_tree():
            continue
        var r := sc.get_global_rect()
        if not r.has_point(cursor_ui):
            continue
        if cursor_ui.y < r.position.y + 70.0:
            sc.scroll_vertical = maxi(0, sc.scroll_vertical - int(700.0 * delta))
        elif cursor_ui.y > r.end.y - 70.0:
            sc.scroll_vertical += int(700.0 * delta)


func _hit_test(p: Vector2) -> Control:
    var best: Control = null
    var best_area := INF
    for n in get_tree().get_nodes_in_group("gaze_target"):
        var c := n as Control
        if c == null or not c.is_visible_in_tree() or c.focus_mode == Control.FOCUS_NONE:
            continue
        if c is BaseButton and (c as BaseButton).disabled:
            continue
        if is_instance_valid(Launcher.modal) and not Launcher.modal.is_ancestor_of(c):
            continue
        var r := c.get_global_rect()
        if r.has_point(p):
            var a := r.size.x * r.size.y
            if a < best_area:
                best = c
                best_area = a
    return best


func _set_hover(c: Control) -> void:
    if is_instance_valid(hover) and hover.has_focus():
        hover.release_focus()
    hover = c
    if c != null:
        c.grab_focus()


func _clear_hover() -> void:
    _set_hover(null)
    _dwell = 0.0
    gaze_progress = 0.0
