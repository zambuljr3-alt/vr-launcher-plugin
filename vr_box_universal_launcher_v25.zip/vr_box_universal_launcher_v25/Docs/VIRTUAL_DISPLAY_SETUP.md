# Apps di dalam launcher (jendela mengambang seperti Meta Quest) - setup Shizuku
STATUS: eksperimental, belum pernah diuji penulis di perangkat. Android 11 bisa menolak beberapa app atau layar virtual.

## Cara kerjanya
Launcher membuat layar virtual (tersembunyi) dan menjalankan app asli di sana (`am start --display`). Gambar layar
virtual itu ditampilkan di VR sebagai jendela. Gaze "Arm tap" dikirim sebagai ketukan (`input -d ... tap`).
Perintah itu butuh hak shell, jadi kita memakai **Shizuku** (aplikasi gratis & open source). Launcher tetap menjadi
app yang tampil, jadi tidak berhenti menggambar saat app lain berjalan.

## Syarat satu kali
1. Pasang plugin Android (Docs/PLUGIN_BUILD_STEPS.md) dan export dengan Gradle build.
2. Pasang **Shizuku** (dari Play Store atau github.com/RikkaApps/Shizuku).
3. Pengaturan HP > Tentang ponsel > ketuk "Nomor build" 7x (Opsi pengembang).
4. Opsi pengembang > **Debugging nirkabel** (Wireless debugging) ON. HP harus terhubung Wi-Fi.
5. Buka Shizuku > "Mulai via debugging nirkabel" > ikuti panduan pairing (kode muncul di notifikasi) > Shizuku berjalan.
6. Di launcher: Settings > Open apps = **Window (Shizuku)** (atau Auto). Buka sebuah app: dialog izin Shizuku muncul, izinkan.
Setelah HP di-restart, Shizuku harus dimulai lagi (langkah 5). Keamanan: Shizuku memberi hak shell ke app yang kamu izinkan;
izinkan hanya launcher ini.

## Pemakaian
Ketuk app di Home > jendela terbuka. "Arm tap" lalu lihat target sampai ring terisi (satu ketukan, lalu mati lagi);
Scroll up/down, keyboard gaze, Back (tombol Back Android), "Real app" untuk keluar ke app asli, "Retry" kalau gagal.
Jika gambar tidak muncul, layar menampilkan keluaran perintah shell: kirim teks itu ke saya.

## Batas yang sudah diketahui
- Satu jendela pada satu waktu (belum multi-jendela). ~10-15 fps karena JPEG; kemungkinan berat untuk Helio G90T.
- App yang menolak layar kedua, kamera, perbankan, DRM (Netflix) bisa gagal atau hitam.
- Audio keluar dari speaker HP seperti biasa. Teks: hanya karakter dasar lewat keyboard gaze.
- Tanpa Shizuku/Plugin: Auto turun ke halaman web tertanam, lalu ke app asli layar penuh.
