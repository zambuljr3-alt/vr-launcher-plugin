# Removable phone mount for Redmi Note 8 Pro in a VR Shinecon - design guide
Do NOT fix any tray size yet. First measure the real headset and phone with calipers (see list). Phone published size
is about 161 x 76 x 8.8 mm, but always measure your own unit with its case.

## Measurements to take (write them down)
- Headset: inner width/height of the phone bay, lens centre-to-centre distance, lens-to-screen distance range,
  height of any ledge/clip, where the original clamp touches.
- Phone: length, width, thickness (with/without case), button heights, port positions.
- Screen centre vs. lens centres: the phone's screen centre must line up with the midpoint between the lenses.

## Requirements and how to meet them
- **Removable, no glue:** use a spring clamp, sliding rails with a latch, or elastic straps. Never adhesive on the phone.
- **Strong lock:** two-point latch or lever clamp plus a rubber lip; test by shaking the headset firmly with a dummy block.
- **Padding:** 1-2 mm EVA foam or silicone pads on every contact face (not on the screen area).
- **Power button access:** leave a cut-out/gap on the right edge (phone landscape: check which edge in your orientation).
- **Charger port access (USB-C, bottom edge):** a slot large enough for the plug body, or a right-angle USB-C adapter.
- **Heat/ventilation:** open slots behind the phone and above the back camera area; keep gaps so air can move; do not
  wrap the phone in foam.
- **Speaker and sensors:** keep the bottom speaker grille and the top proximity/ambient sensors uncovered.
- **Alignment:** add a centring mechanism (two symmetric sliding side clamps) so the screen is always centred.
- **Screen parallel to lenses:** use a flat stop plate; add a thin shim system for fine distance tuning.
## Process
1. Measure. 2. Prototype in cardboard/foam. 3. 3D-print a test frame in PLA. 4. Test alignment with the VR calibration
grid. 5. Only then finalize dimensions. Safety: check the phone temperature after 20-30 min of use.
