# Feature report - v19 (NEXUS VR EDITION)

Status key: **IMPL** = Implemented in code (not device-tested) - **PERM** = Needs Android permission/consent -
**TEST** = Needs device testing - **NO** = Not supported / not done.

IMPORTANT: nothing below has been run in Godot or on a Redmi Note 8 Pro by the author (no Godot binary and no
device were available). "IMPL" means code exists and passed a static check only. The only things confirmed by
the project owner on a phone: Home UI shows, VR split view shows, head cursor moves with the correct direction
after v12 mapping, apps/links can be asked to open (results varied).

## 2. VR Home
| Feature | Status |
|---|---|
| Floating menu, clock/date, dock, quick settings, transitions, centre reticle | IMPL, TEST |
| Battery/Wi-Fi status | IMPL, TEST (needs AndroidRuntime or plugin; "n/a" otherwise) |
| Immersive 3D environment | PARTIAL: UI panel in a 3D world with a forest sky panorama; no modelled 3D room. NO for a full environment |
| Favorites dock (max 5) | IMPL, TEST |

## 3. Android app library
| Feature | Status |
|---|---|
| List installed apps + names | IMPL via GDScript bridge (Godot 4.2+, Query All Packages), TEST |
| Real app icons | IMPL only in the native plugin (Android/VRLauncherPlugin), PERM (Query All Packages), TEST, plugin must be built by you |
| Search (gaze keyboard) | IMPL, TEST |
| Add/remove favorites | IMPL, TEST |
| Open real apps | IMPL, TEST. Link fallback for some apps cannot report success |

## 4. VR app display
| Feature | Status |
|---|---|
| Floating app screen via MediaProjection mirror | IMPL in plugin + Capture.gd, PERM (official consent dialog), TEST; plugin must be built |
| Flat / curved screen, size, distance, height | IMPL, TEST |
| Apps running inside Godot | NO (not possible; it is a screen mirror) |
| Head/gaze input INTO the mirrored app | NO (would need an AccessibilityService; not implemented) |
| Android 11 limits | Protected (FLAG_SECURE) content is black; capture size is fixed at start; ~8 fps JPEG polling |

## 4a. Apps in a virtual display (Meta-Quest-like windows) - NEW in v19
| Feature | Status |
|---|---|
| Real Android app running on a private virtual display, shown as a floating window in VR | IMPL in plugin (VDController) + Win.gd + window page, PERM (Shizuku shell access), TEST. **Experimental: Android 11 may refuse** |
| Gaze tap (armed), scroll (swipe), Back key, text via gaze keyboard injected into the app | IMPL, TEST |
| Several windows at once | NO (one window) |
| Needs: native plugin built + Shizuku running (wireless debugging) after every reboot | - |
| See Docs/VIRTUAL_DISPLAY_SETUP.md | |

## 4b. Embedded web screen (YouTube/Google/Maps web inside the launcher) - NEW in v17
| Feature | Status |
|---|---|
| Web page rendered inside the launcher (WebView on a private VirtualDisplay + Presentation, JPEG frames) | IMPL in plugin + Web.gd, TEST. **Needs the native plugin built (v17 source)** |
| YouTube video visible in the frames | UNKNOWN: should be composited by the system, but must be tested; black video is possible |
| Gaze tap ("Arm tap" then look, one tap, auto disarm), scroll, back/forward, gaze keyboard | IMPL, TEST |
| It is NOT the native YouTube app and not an Android app running in Godot | - |
| DRM sites (Netflix) | NO (not routed inside; they open the real app) |
| Setting "Open YouTube/Google inside launcher" (Settings hub) | IMPL; without the plugin the old real-app launch is used |

## 5. Cinema 2.0
| Feature | Status |
|---|---|
| Large flat/curved screen, size, distance, height, brightness, Home | IMPL, TEST |
| Source = live phone-screen mirror | IMPL, PERM, TEST (plugin needed) |
| Play/Pause | IMPL for the mirror (freezes the shown frame) |
| Video FILE playback | NO (Godot plays only Ogg Theora; not implemented). Demo pattern otherwise |
| Virtual cinema room environment | NO (dark surround only) |

## 6. Head tracking 2.0
Rotation-only **3DoF** from the gyroscope. No position tracking, **not 6DoF**.
Smoothing/anti-jitter, deadzone, sensitivity, recenter, invert yaw/pitch, direction wizard, swap axes: IMPL, TEST
(direction mapping verified by the owner on their phone). No accelerometer/magnetometer fusion: yaw drifts, use Recenter.

## 7. Optical settings
IPD, lens separation (centre shift), per-eye shift, eye height, screen distance, FOV, k1/k2 distortion, quality:
IMPL, TEST. Values are NOT yet matched to a VR Shinecon lens profile: calibrate by eye with the grid (see
SHINECON_SETUP.md).

## 8. Physical headset mode
VR-only UI, gaze control, top-right Recenter/Home, keep-awake, orientation (landscape/reverse), FPS/quality: IMPL, TEST.
Bluetooth gamepad: IMPL, TEST (remappable). Brightness: needs native plugin (IMPL there), TEST. Sleep timeout: only
"keep awake / system default" (changing the system timeout needs WRITE_SETTINGS: NO).

## 9. Auto start
Home-intent filter via export helper (needs Gradle build): IMPL, TEST. You must pick the launcher as default Home in
Android settings (user action). After boot the user lands in the launcher on wake/unlock; lock screen is NOT bypassed.
Auto-launch at boot without being Home (BOOT_COMPLETED): NO.

## 10. Mount guide: see MOUNT_DESIGN_GUIDE.md (document only; no dimensions invented).

## 11. Performance
Compatibility renderer, 30/45/60 fps cap, quality presets (render scale 50/75/100%), no heavy 3D effects: IMPL, TEST.
Measured FPS/heat/battery: NOT measured.

## 12. Quality control
Static checks only (indentation, bracket balance, resource paths). No Godot parser run, no APK export done,
no APK delivered. The native plugin is uncompiled.
