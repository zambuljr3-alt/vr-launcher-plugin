# VR Shinecon setup (Redmi Note 8 Pro)
I do not know your exact Shinecon model's lens spacing, so these are procedures, not claimed values.

1. Mount the phone landscape, screen centred between the two lenses (see MOUNT_DESIGN_GUIDE.md). If it sits upside-down
   (charging port on the other side) use Settings > Headset mode > Screen orientation > Reverse landscape.
2. Settings > VR display > turn on "Calibration grid". Wear the headset.
3. IPD: set your own IPD (measure with a ruler/mirror or an optician; typical adults ~58-70 mm). Adjust until the grid
   fuses into one image without eye strain.
4. Lens centre shift / Left eye shift / Right eye shift: move each eye's centre until the white cross is in the middle of
   each lens view. Eye height: raise/lower the cross to your lens centre.
5. Lens k1/k2: increase until the straight grid lines look straight at the edges (start k1 0.18, k2 0.04).
6. FOV: raise until the image fills the lens without black corners, lower if it feels stretched.
7. Control settings > Head > Calibrate direction (wizard). Use Recenter (top-right button) whenever the view drifts.
8. Headset mode: choose quality Low/Medium for heat/battery. Medium is the default.
Remove the calibration grid when done.
