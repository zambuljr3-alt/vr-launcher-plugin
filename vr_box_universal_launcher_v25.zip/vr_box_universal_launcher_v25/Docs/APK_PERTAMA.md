# APK pertama (langsung masuk VR + kontrol kepala) - lewat HP saja
Yang dibangun: launcher yang sama (sudah kamu tes: gyro, yaw/pitch, gaze jalan), tanpa plugin dan tanpa Shizuku.
Saat dibuka langsung mode VR kiri-kanan dengan kontrol kepala. Belum pernah diuji penulis (build cloud).
App asli (YouTube dll.) tetap terbuka sebagai app biasa; mode "di dalam VR" nanti, setelah APK dasar ini jalan.

1. github.com (browser HP, centang "Situs desktop" jika perlu) > repo `vr-launcher` (Private).
2. Add file > Upload files > pilih DUA file dari folder Download: `vr_box_universal_launcher_v24.zip` (jangan diekstrak)
   dan `build-apk-simple.yml` > Commit changes.
3. Ketuk `build-apk-simple.yml` > ikon pensil > ubah nama file menjadi `.github/workflows/build-apk-simple.yml` > Commit.
4. Tab Actions > Build APK (simple) > Run workflow. Tunggu 10-20 menit sampai hijau.
5. Buka run > Artifacts > unduh VRBoxLauncher-apk > ekstrak > pasang `VRBoxLauncher.apk` (izinkan sumber tidak dikenal).
6. Merah? Buka langkah yang merah, salin ~30 baris terakhir, kirim ke saya.
Pasang di HP, buka "VR Box Launcher": langsung VR. Kalau perlu keluar dari VR: tiga jari di layar bersamaan.
