# Build APK lewat HP saja (GitHub Actions) - belum pernah diuji penulis
Tujuannya: tanpa PC, tanpa Android Studio, tanpa Godot di HP. Semua dibangun di server GitHub (gratis, ~15-40 menit).
Hasilnya: APK debug lengkap dengan plugin (ikon asli, web tertanam, jendela Shizuku).

1. Buka github.com di browser HP > daftar/masuk.
2. Tombol + (atau menu) > **New repository** > nama `vr-launcher` > pilih **Private** > centang **Add a README file** > **Create repository**.
3. Di repo: **Add file > Upload files** > pilih file zip project (mis. `vr_box_universal_launcher_v20.zip`, JANGAN diekstrak)
   dan juga file `build-apk.yml` (ada di dalam zip folder `CloudBuild/`; ekstrak zip di HP, atau minta file terpisahnya
   dari saya) > **Commit changes**.
4. Pindahkan workflow: klik `build-apk.yml` di daftar file > ikon pensil (Edit) > di kolom nama file, ganti menjadi
   `.github/workflows/build-apk.yml` (ketik lengkap dengan garis miring) > **Commit changes**.
5. Tab **Actions** > di kiri pilih **Build APK** > **Run workflow** > **Run workflow**. Tunggu sampai ada tanda centang hijau.
   (Kalau tab Actions meminta, tekan "I understand my workflows, go ahead and enable them".)
6. Buka run yang hijau > bagian **Artifacts** paling bawah > unduh **VRBoxLauncher-apk** (zip) > ekstrak di HP > pasang `VRBoxLauncher.apk`
   (izinkan "pasang dari sumber tidak dikenal").
7. Kalau gagal (tanda silang merah): buka run > klik langkah yang merah > salin ~30 baris terakhir > kirim ke saya.
Catatan: APK ini versi debug (ditandatangani kunci debug). Jika kamu mengganti project, unggah zip versi baru ke repo
(workflow memakai zip dengan nomor versi tertinggi).
