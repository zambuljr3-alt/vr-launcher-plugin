# Cara memasang plugin Android (supaya YouTube dll. terbuka DI DALAM launcher)

Tanpa plugin ini launcher tetap berfungsi, tetapi YouTube dll. dibuka sebagai aplikasi asli layar penuh,
dan ikon asli aplikasi serta screen capture tidak tersedia. Langkah di bawah belum pernah diuji penulis.

## Cara A - build di cloud (GitHub), tanpa Android Studio
1. Buat akun di github.com, lalu buat repository baru (kosong).
2. Dari folder project: ambil ISI folder `Android/VRLauncherPlugin/` (termasuk folder tersembunyi `.github`) dan unggah
   ke repository itu sebagai ISI UTAMA repo (bukan di dalam sub-folder). Di HP: pakai "Add file > Upload files"
   di situs GitHub; folder `.github/workflows/build-plugin.yml` harus ikut (bisa dibuat manual lewat "Create new file"
   dengan nama `.github/workflows/build-plugin.yml` lalu tempel isinya).
3. Buka tab **Actions** > **Build plugin** > **Run workflow**. Tunggu hijau (beberapa menit).
4. Klik run yang selesai > bagian Artifacts > unduh **VRLauncherPlugin-aar** (zip). Ekstrak, ambil file `.aar`.
5. Ubah namanya menjadi `VRLauncherPlugin.aar` dan taruh di project Godot: `addons/vr_launcher_export/bin/`.
6. Godot: Project > Project Settings > Plugins > aktifkan "VR Launcher Export Helper".
   Export Android: aktifkan **Use Gradle Build** (dan Install Android Build Template), centang izin
   **Internet**, **Query All Packages**, **Access Network State**.
7. Export APK, pasang. Buka Settings di launcher: baris "Native plugin" harus tertulis **installed**.
Kalau workflow gagal: salin log error dan kirim ke saya.

## Cara B - Android Studio (di PC)
Buka folder `Android/VRLauncherPlugin` di Android Studio atau jalankan `gradle assembleRelease`, hasilnya
`build/outputs/aar/VRLauncherPlugin-release.aar`; lanjut dari langkah 5.
