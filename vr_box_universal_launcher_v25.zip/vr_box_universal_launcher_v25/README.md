# VR BOX UNIVERSAL LAUNCHER - v25

Android VR home launcher for smartphone VR Box headsets. Godot 4.3+ (4.2 should work),
**Compatibility renderer**, target: Redmi Note 8 Pro (Helio G90T / Mali-G76 / Android 11).

> **Honesty notes.** This package was written without a Godot binary and without a device.
> It has **not been opened in the editor, run, or tested on hardware**. Expect to fix small
> errors on first import. Everything marked "not implemented" below really is not implemented.

## 1. Install / run
1. Install Godot 4.3+ (standard, not .NET).
2. Project Manager > Import > select `project.godot`. Let the first import finish (it imports
   textures/audio). Fix any parser error shown in the Output panel and tell me the message.
3. Press F5. On desktop: mouse = touch; **move the mouse** (Head mode) to look around; right-drag also works; keyboard `Backspace`=Back, `H`=Home, `Q`/`E`=pages.

## 2. Using it
- **Home**: look at icons (default Head mode, touch also works at all times) / tap icons / swipe pages / use the dock. Icons are demo shortcuts until the native
  plugin is installed (a note on Home says so; launching reports an error, never fake success).
- **Controls** (grid page 2, or dock > quick settings > "All control settings"):
  - Head: gyro integrates into a cursor; look at an item until the ring fills. Adjust gaze timer,
    sensitivity, invert/swap axes, Recenter, Calibrate gyro. *Gyro-only: it drifts and the axis
    mapping is unverified per device - use the toggles. Status text shows whether data arrives.*
  - Gamepad: D-pad / left stick move focus (fixed), remap Select/Back/Pages/Home buttons
    (default A/B/LB/RB/Menu). Pair the pad in Android Bluetooth settings first.
  - Touch: plain touch navigation.
- **VR Display**: toggle Stereo VR. Left/right eye cameras (IPD apart) see the same 3D world with
  the UI on a panel; lens k1/k2/centre shift per eye; quality 50/75/100%; calibration grid.
  OpenXR is not used (it targets standalone headsets, not phone VR boxes). VR off = flat fallback.
- **Cinema**: big screen with size/distance (VR on) showing a *demo test pattern*. Screen capture
  is **not implemented**; the button explains this.
- **Gaze/steppers**: settings use -/+ steppers with Kenney slider bars instead of draggable
  sliders, because they work with gaze and gamepad.

## 3. Android integration
Two layers, both **untested on a device**:
1. **GDScript bridge** (`Scripts/Core/AndroidBridge.gd`, Godot 4.2+): launch apps, list installed apps (names only,
   no icons), battery/Wi-Fi. Needs export permissions **Query All Packages** and **Access Network State**.
2. **Native plugin** (`Android/VRLauncherPlugin/`, Kotlin, you must build the AAR - see its README): real app icons,
   game flag, window brightness, MediaProjection screen capture (official consent dialog + foreground service).
   Copy the AAR to `addons/vr_launcher_export/bin/VRLauncherPlugin.aar`; the export helper bundles it.
The plugin is preferred when present. Without it: no real icons (letters are shown), no screen capture.
Limits: a launched app is a normal 2D app; head control cannot send input into it; the capture is a mirror.
See `Docs/FEATURE_REPORT.md` for the status of every feature.

## 3a0. Apps inside the launcher (Quest-like windows): Docs/VIRTUAL_DISPLAY_SETUP.md
Settings > Open apps: Auto (window if Shizuku ready, else web page, else real app) / Window / Web page / Real app. Experimental, untested.

## 3a. Embedded web screen (see Docs/PLUGIN_BUILD_STEPS.md) (YouTube etc. inside the launcher)
Tapping YouTube/Google/Chrome/Internet/Maps/Music opens a web page INSIDE the launcher (instead of the real app) when the
native plugin is installed; otherwise the old real-app launch is used. In the page: "Arm tap", look at the target until the
ring fills (one tap is sent), scroll buttons, gaze keyboard, Back/Fwd, "Real app" to leave to the real app.
Needs the plugin AAR (see Android/VRLauncherPlugin/README.md, GitHub Actions build available). Untested; video might be black.

## 3b. Auto start as Home
Enable the editor plugin (Project Settings > Plugins > VR Launcher Export Helper), use "Use Gradle Build" in the
Android preset, export, install, then Android Settings > Apps > Default apps > Home app > VR Box Universal Launcher.

## 3c0. First APK, simplest: Docs/APK_PERTAMA.md (CloudBuild/build-apk-simple.yml)

## 3c. Build the APK without a PC
See Docs/CLOUD_BUILD_HP.md (GitHub Actions workflow in CloudBuild/). Untested.

## 4. Export to Android
1. Editor > Manage Export Templates > download. Install Android SDK + JDK 17, set paths in
   Editor Settings > Export > Android.
2. Project > Install Android Build Template (required for the Home intent filter and the plugin).
3. Project > Export > Add > Android. Enable: Use Gradle Build (plugin only), ARM64 (v8a),
   permissions: tick Query All Packages + Access Network State.
   Keep screen orientation = landscape (already set).
4. Pick a keystore (debug is fine for testing), Export APK, `adb install`.
5. Textures: only the wallpaper is large; set it to VRAM Compressed in the Import dock if you
   replace it with a bigger image (UI icons stay lossless to avoid artefacts).

## 5. Folders
`Scenes/` scenes - `Scripts/{Core,UI,VR,Controller}` code - `Settings/default_settings.json`
defaults - `Assets/{Backgrounds,Icons,UI,Audio,VR,Controller,Fonts,Licenses}` - `Android/` plugin.

## 6. Assets and licences
- Kenney UI Pack, Input Prompts 1.5, Interface Sounds: CC0 (licence files in `Assets/Licenses`).
  Only a small subset was imported (buttons/sliders/font, Xbox + touch prompts, 13 sounds).
- Wallpaper (`Assets/Backgrounds/forest_wallpaper.jpg`) and VR sky (`Assets/VR/forest_sky.jpg`, 2K)
  were generated from your Poly Haven `mossy_forest_4k.exr`. The 31 MB EXR is NOT shipped (too
  heavy for Mali-G76); both are tone-mapped JPGs. Want another view angle? Send the direction.
- Logos Chrome, Maps, Photos, Netflix, YouTube come from your Simple Icons SVGs (rasterized and
  coloured by me; brand trademarks belong to their owners - fine for a personal launcher, check
  rules before publishing). Camera/Gallery/Internet/Settings/Play Store are still my own symbols.
  `rotaryinternational.svg` was not used (it is Rotary International's logo, not an Internet icon).
- `Assets/Icons/ic_*` (dock/system) and `app_*` (app icons) are my own drawn symbols, NOT
  official brand logos and NOT Material Symbols (none were uploaded). To use real logos/Material
  Symbols, put PNGs with the same filenames in `Assets/Icons/` (check each brand's usage rules).

## 7. Known limitations
Not run/tested in Godot or on a device; gyro axis mapping and drift; no sensor fusion; installed-app list, status icons
and app launching need the plugin; notifications, screen capture and Recents-across-restarts are
not implemented; the UI quad orientation/flip on a ViewportTexture has not been verified.
