# Changelog

## v25
Added (Godot side only; no plugin change)
- App window control panel (always gaze-reachable): Arm tap, Scroll up/down, Prev/Next short, Volume -/+ (app windows),
  Keyboard, Recenter, Nod ON/OFF, Home.
- Shorts: "Next/Prev short" send a thumb-like swipe; "Nod" mode: a quick nod down = next short, a quick look up = previous
  (off by default; a 1.2 s cooldown; the nod threshold is about 14 degrees).
- Compatibility log: every app opened in Window mode is recorded as ok or fail (with the shell output) and shown in
  Settings diagnostics, so you can see which apps accept virtual displays. The window page waits 5 s before saying
  "no picture" and suggests Retry / Real app.
Files: 0 added; 7 edited (Pointer.gd, WebService.gd, WindowService.gd, Apps.gd, WebBrowser.gd, default_settings.json,
README.md/CHANGELOG.md).

## v24
Added
- CloudBuild/build-apk-simple.yml: the simplest cloud build (plain APK export, no Gradle/plugin/Shizuku) and
  Docs/APK_PERTAMA.md (Indonesian steps). The app itself is unchanged from v23 (starts directly in VR with head control).
Files: 2 added (CloudBuild/build-apk-simple.yml, Docs/APK_PERTAMA.md); 2 edited (README.md, CHANGELOG.md).

## v23
Fixed
- In VR mode, touching the screen selected the wrong items: raw touch events were forwarded into the VR UI
  with window coordinates. Touch/mouse are no longer forwarded in VR (head/gaze and gamepad only).
Added
- Emergency exit: put three fingers on the screen at the same time to switch VR off (flat mode, touch works again).
Files: 0 added; 3 edited (VRRig.gd, README.md, CHANGELOG.md).

## v22
Added
- Debug overlay inside the VR view (under the centre dot, both eyes): control mode, raw gyro x/y/z, yaw/pitch,
  the item being looked at and the gaze %. Default ON for now; Settings > Headset mode > "Debug overlay (VR)" turns it off.
  Purpose: find out why head selection did not work on the phone (is the gyro alive? is the cursor on an item?).
Files: 0 added; 5 edited (GazeReticle.gd, Headset.gd, default_settings.json, README.md, CHANGELOG.md).

## v21
Changed
- Desktop testing: in Head mode the mouse itself now moves the view/cursor (no button needed) on PC, since a PC has no
  gyroscope (the editor run showed a fixed reticle). Phone behaviour is unchanged: the gyroscope drives it.
Files: 0 added; 3 edited (Pointer.gd, README.md, CHANGELOG.md).

## v20
Added
- Phone-only build: CloudBuild/build-apk.yml (GitHub Actions) builds the plugin AAR and exports the APK in the cloud,
  plus Docs/CLOUD_BUILD_HP.md (Indonesian steps). Untested: the first run may need fixes, send the failing log.
No app code changed.
Files: 2 added (CloudBuild/build-apk.yml, Docs/CLOUD_BUILD_HP.md); 2 edited (README.md, CHANGELOG.md).

## v19
Added
- Apps inside the launcher like Meta Quest windows (experimental, untested): a real Android app runs on a private
  virtual display, its picture is shown in VR, and gaze taps/scroll/keys are injected via Shizuku (shell access).
  New: plugin classes VDController, ShellService (+AIDL), Win service (Scripts/VR/WindowService.gd), window page reuse.
- Settings > "Open apps": Auto / Window (Shizuku) / Web page / Real app (replaces the old inside/real toggle).
- Settings diagnostics show the Shizuku status; the window page shows setup instructions or the shell output.
- Docs/VIRTUAL_DISPLAY_SETUP.md (Indonesian) and Feature report section 4a.
Needs: the plugin AAR rebuilt from this version + Shizuku running. Without them behaviour falls back to web page / real app.
Files: see counts in the reply.

## v18
Changed
- Tapping YouTube/Google/etc. without the native plugin now shows a toast explaining why the real app opens
  (inside-launcher mode needs the plugin), instead of silently opening it.
- Settings diagnostics show whether the native plugin is installed.
Added
- Docs/PLUGIN_BUILD_STEPS.md: step-by-step plugin build (GitHub Actions or Android Studio), in Indonesian.
Files: 1 added (Docs/PLUGIN_BUILD_STEPS.md); 3 edited (Apps.gd, CHANGELOG.md, README.md).

## v17
Added
- Embedded web screen: YouTube (m.youtube.com), Google, Maps, Music and the browser icons open a web page inside the
  launcher (Settings > "Open YouTube/Google inside launcher"). Implemented in the native plugin as a WebView on a
  VirtualDisplay (frames -> Godot), with gaze "arm tap", scroll, back/forward and a gaze keyboard.
- GitHub Actions workflow to build the plugin AAR without Android Studio (untested).
Important: requires the plugin AAR to be built/installed; without it nothing changes (real apps still open full screen).
Video may appear black: needs testing on your phone. This is the YouTube WEBSITE, not the YouTube app.
Files: see counts in the reply.

## v16
Fixed
- Home grid icons not showing: the icon disc/logo/letter are now real nodes (Panel + TextureRect/Label)
  instead of manual _draw code; the pop-in animation always ends fully visible (safety timer).
Added
- Status chip (top-left) shows "icons missing: N" if bundled icon files fail to load; the Output panel
  prints "Icon missing or not imported: <name>". If the chip is clean and icons still don't show, send a screenshot.
Files: 0 added; 5 edited (AppIcon.gd, Apps.gd, Shell.gd, CHANGELOG.md, README.md).

## v15 - NEXUS VR EDITION, stage 1 (nothing here is device-tested)
Added
- Head tracking 2.0: smoothing (anti-jitter) setting; 3DoF explained in the UI.
- Optical: FOV, left/right eye shift, curved or flat home screen (cursor math handles the curve).
- Cinema 2.0: flat/curved screen, size, distance, height, brightness, Play/Pause, source = demo or live
  Android screen mirror (needs the native plugin and user consent). Replaces the old demo-only page
  and the "comfort mode" toggle (brightness covers it).
- App Library: gaze keyboard search, favorites (edit mode, star marker), favorites dock on Home (max 5).
- Headset mode page: graphics quality, FPS cap, show FPS, orientation, keep awake, brightness (plugin), recenter.
- Top-right Recenter + Home buttons on every page.
- Auto start: editor export helper adds the HOME intent filter (+ bundles the plugin AAR if present).
- Native plugin source (Kotlin/Gradle): real icons, launch, status, brightness, MediaProjection capture.
- Docs: FEATURE_REPORT.md, SHINECON_SETUP.md, MOUNT_DESIGN_GUIDE.md.
Not done: video file playback, virtual cinema room model, input into mirrored apps, APK (not built here).
Files: 16 added, 3 removed (old demo capture stub + old plugin sketch), 18 edited.

## v14
Changed
- The launcher now starts in stereo VR with Head (gaze) control by default. Saved settings are migrated once
  (settings_version 12). If VR is on, a saved "Touch" mode is switched to Head at startup.
- To go back to a flat screen: Settings > VR display > Stereo VR mode OFF (needs gaze while in VR).
Files: 0 added; 4 edited (default_settings.json, Settings.gd, README.md, CHANGELOG.md).

## v13
Fixed
- Tapping/gazing an app did nothing when the Android bridge was not active (app stayed in the launcher).
  Now, if the bridge is missing or the package is not found, the launcher hands a web link to Android
  (YouTube, Chrome/Internet, Google, Maps, Photos, Play Store, Netflix, Music). Android then opens the
  installed app or the browser. Android gives no success result for this, so the message says "asked".
  Camera, Gallery and Settings have no link fallback: they need the bridge.
Added (animations)
- Staggered pop-in of icons on Home, press pulse when an icon is activated (gaze or touch), dock and back
  buttons scale up on focus.
Not done: real notifications (needs a Kotlin service/plugin), logos for Camera/Gallery/Internet/Play Store
(need your files).
Files: 0 added; 6 edited (Apps.gd, AppIcon.gd, Home.gd, Ui.gd, README.md, CHANGELOG.md).

## v12
Fixed
- Left/right was mirrored (looking left moved the cursor right). Default yaw sign is now -1; up/down kept
  as in v11. Saved mapping is reset once (settings_version 11).
Files: 0 added; 4 edited (default_settings.json, Settings.gd, README.md, CHANGELOG.md).

## v11
Fixed
- Head direction was crossed: looking up moved the cursor right, looking right moved it up (left/down
  likewise). Default gyro mapping is now yaw=axis 1, pitch=axis 0 (signs unchanged). Saved old mapping
  is reset once.
Added
- Control settings > Head: "Swap left/right with up/down" button for a one-tap fix on other phones
  (the wizard and Invert toggles remain).
Files: 0 added; 5 edited (default_settings.json, Settings.gd, ControlSettings.gd, README.md, CHANGELOG.md).

## v10
Fixed
- Head direction out of sync: the old fixed gyro-axis guess is replaced by a calibration wizard
  (Control settings > Head > "Calibrate direction"). It asks you to turn RIGHT and hold, then look UP
  and hold, detects which gyro axis/sign matches each, and stores it. The prompts are also drawn
  under the centre reticle so you can read them inside the VR box. Invert toggles remain for fine-tuning.
Changed
- "Swap gyro axes" toggle removed (superseded by the wizard).
Files: 0 added; 6 edited (default_settings.json, Pointer.gd, GazeReticle.gd, ControlSettings.gd,
README.md, CHANGELOG.md).

## v9
Fixed
- Head cursor/reticle never appeared: an old saved control mode ("touch") overrode the new Head
  default. Settings are migrated once to Head.
- Turning VR mode ON while in Touch mode now switches to Head automatically (touch is unusable in the box).
- The centre reticle is now always visible in VR (it shows the gaze ring when Head mode is active).
Added
- Status chip (top-left): control mode, VR on/off, gyroscope active/no data.
- Control settings > Head: live readout of raw gyro, gravity and the yaw/pitch the launcher computes,
  so you can see whether the sensor moves and in which direction.
Files: 0 added; 8 edited (default_settings.json, Settings.gd, GazeReticle.gd, Pointer.gd, Shell.gd,
ControlSettings.gd, README.md, CHANGELOG.md).

## v8
Added / changed (from your development prompt)
- Gaze time default 1.0 s (old saved 1.5 s is migrated once); new Deadzone setting for head tracking.
- Google and Music shortcuts on the grid (Music tries Mi Music, YouTube Music, Spotify, Samsung Music).
  Music icon drawn by me; Google uses a letter on white.
- Eye calibration: new "Eye height" (vertical lens centre) beside IPD, lens k1/k2 and centre shift.
- Cinema: Comfort mode (near-black surround + faded controls); controls re-laid out in two rows.
- Looking at the top/bottom edge of a long settings page scrolls it (head-only scrolling).
- Settings hub shows diagnostics (Godot version, AndroidRuntime present?, bridge status raw) to find
  why battery/Wi-Fi showed "n/a" on your phone.
Not done: video file playback in Cinema, screen capture, notifications, real Camera/Gallery/Internet/
Play Store logos.
Files: 1 added (Assets/Icons/app_music.png); 13 edited (default_settings.json, Settings.gd, Pointer.gd,
ControlSettings.gd, VRSettings.gd, Library.gd, lens_distortion.gdshader, VRRig.gd, Apps.gd, SettingsHub.gd,
Home.gd, Cinema.gd, README.md/CHANGELOG.md).

## v7
Added
- Real app launching (Chrome, YouTube, ...) full-screen via Scripts/Core/AndroidBridge.gd:
  Godot calls Android directly, no plugin to build. Also installed-app list (names) and
  battery / Wi-Fi status on Home. Needs Godot 4.2+ and export permissions Query All Packages +
  Access Network State. Untested on a device.
Changed
- Messages/notes no longer say "plugin not installed"; preview (editor) says launching works on the phone.
Files: 1 added (Scripts/Core/AndroidBridge.gd); 6 edited (Apps.gd, Home.gd, Library.gd,
SettingsHub.gd, README.md, CHANGELOG.md).

## v6
Changed
- Reverted v5: head/gaze control works in every display mode again (flat and VR), as requested.
  Head is the main control; touch still works too.
Files: 0 added; 4 edited (Pointer.gd, Home.gd, ControlSettings.gd, CHANGELOG.md).

## v5
Fixed
- Apps/pages opened by themselves (e.g. Gallery, Settings) when the phone was held in the hand:
  head/gaze selection was active in flat mode and the drifting gyro cursor auto-clicked items.
  Gaze now runs only when Stereo VR mode is ON; flat mode is touch-only. Hints/notes updated.
Files: 0 added; 5 edited (Pointer.gd, Home.gd, ControlSettings.gd, README.md, CHANGELOG.md).

## v4
Fixed / changed
- Settings icon (and dock quick-settings > "All settings...") now opens a real SETTINGS hub page:
  Control settings, VR display, Cinema, All apps, Android system settings, UI volume.
  Before, "Settings" was only a demo shortcut to Android Settings and showed an error without the plugin.
- App icons: if an icon PNG fails to load/import, a letter fallback is drawn and a warning
  "Icon missing or not imported: <path>" is printed in the Output panel (helps find why logos are missing).
Files: 2 added (Scripts/UI/SettingsHub.gd, Scenes/SettingsHub.tscn); 6 edited (Apps.gd,
AppIcon.gd, Shell.gd, Home.gd, README.md, CHANGELOG.md).

## v3
Changed
- Real logos for Chrome, Google Maps, Google Photos, Netflix, YouTube from your SVG files
  (converted to PNG with brand colours; icon size adjustable per app via "icon_size").
- Default control mode is now Head (gaze). Touch works in every mode. Gamepad remains optional.
Not done yet (planned): Cinema video player, real screen capture, notifications and
battery/Wi-Fi (need the native Android plugin), extra animations, remaining real logos
(Camera, Gallery, Internet, Settings, Play Store were not uploaded).
Files: 5 icons replaced; 5 edited (Apps.gd, AppIcon.gd, default_settings.json, README.md,
CHANGELOG.md). Nothing added or deleted.

## v2
Changed
- Wallpaper now generated from your mossy_forest_4k.exr (dark forest trail view, 1920x1080 JPG).
  The old screenshot-as-wallpaper (v1) is removed.
- VR background: 2K tone-mapped panorama from the same HDRI (used automatically by VRRig).
- App icons redrawn: camera, gallery, globe, Netflix-style N, gear, compass browser, map pin,
  play, photos pinwheel, store triangle, games pad (own symbols, not official logos).
Files: added 13 (2 images, 11 icons) + removed 1 (old wallpaper); edited 6 (Apps.gd, AppIcon.gd,
Shell.gd, VRRig.gd, README.md, CHANGELOG.md).

## v1 - ULTIMATE HOME UPGRADE V1.1 (first deliverable)

No existing project was supplied in the upload (only the Kenney zips and a screenshot), so this
is a new Godot 4 project organised as requested. If you have an older project, merge it in
manually; nothing here deletes or overwrites anything of yours.

Added
- Android-style HOME: clock/date/status, floating dock (Home, Google, Assistant, Recents,
  Notifications, Quick Settings), circular icon grid, 2 pages, dots, right scroll indicator.
- Control settings: Head (gyro + gaze), Bluetooth gamepad (remappable), Touch.
- VR display prototype: real stereo (2 cameras, shared 3D world) + lens shader, IPD, distance,
  quality, calibration grid. Flat fallback when VR is off.
- Cinema prototype (large 3D screen with size/distance); screen capture is an honest stub.
- Library page (installed apps/games) via an optional native plugin (source sketch included).
- Kenney UI Pack / Input Prompts / Interface Sounds imported (minimal subset, licences included).
- Settings persistence, Android back handling, README with export steps.

Known gaps
- Never run in Godot or on a device by the author of this package (no Godot binary available).
- No Google Material Symbols or Poly Haven HDRI were uploaded: placeholder glyphs generated,
  HDRI hook left in place (Assets/VR/forest.hdr is used automatically if present).
- Wallpaper is your reference screenshot; replace it with your own forest image.
