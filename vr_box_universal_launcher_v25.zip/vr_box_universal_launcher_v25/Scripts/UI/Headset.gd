extends Control
## PHYSICAL HEADSET MODE: settings for when the phone sits in the VR Shinecon.

const Ui = preload("res://Scripts/UI/Ui.gd")


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["margin_left", "margin_right"]:
        margin.add_theme_constant_override(s, 70)
    margin.add_theme_constant_override("margin_top", 24)
    margin.add_theme_constant_override("margin_bottom", 16)
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 10)
    margin.add_child(col)
    col.add_child(Ui.header("Headset mode"))
    var sc := ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.follow_focus = true
    sc.add_to_group("autoscroll")
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(sc)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", Ui.glass(26, 0.5))
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.add_child(panel)
    var body := VBoxContainer.new()
    body.add_theme_constant_override("separation", 10)
    panel.add_child(body)
    var note := Ui.label("Everything here is usable by gaze: no touching the phone. Head tracking is 3DoF (rotation only).", 17, Color(1, 1, 1, 0.8))
    note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.add_child(note)
    body.add_child(Ui.choice("Graphics quality", "quality_preset", [0, 1, 2], ["Low (battery/heat)", "Medium", "High"]))
    body.add_child(Ui.choice("FPS cap", "fps_cap", [30, 45, 60], ["30 fps", "45 fps", "60 fps"]))
    body.add_child(Ui.toggle("Show FPS", "show_fps"))
    body.add_child(Ui.toggle("Debug overlay (VR)", "debug_hud", "ON", "OFF"))
    body.add_child(Ui.choice("Screen orientation", "orientation", ["landscape", "reverse"], ["Landscape", "Reverse landscape"]))
    body.add_child(Ui.toggle("Keep screen awake", "keep_awake", "ON", "System timeout"))
    body.add_child(Ui.stepper("Brightness", "brightness", 0.1, 1.0, 0.1, "%.1f"))
    var bn := Ui.label("Brightness needs the native plugin (sets the window brightness)." if not Apps.native_plugin else "Brightness applies to this app window.", 16, Color(1, 0.8, 0.45, 0.9))
    body.add_child(bn)
    var rc := Ui.button("Recenter view now", true, Vector2(300, 56))
    rc.pressed.connect(func() -> void: Pointer.recenter())
    body.add_child(rc)
    var auto := Ui.label("Auto start: after export, choose this app in Android Settings > Apps > Default apps > Home app. It then opens on every wake/unlock (Android never lets an app bypass the lock screen).", 16, Color(1, 1, 1, 0.7))
    auto.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.add_child(auto)
    Settings.changed.connect(func(k: String) -> void:
        if k == "brightness" and Apps.native_plugin and Apps.plugin != null:
            Apps.plugin.call("setBrightness", float(Settings.data["brightness"])))


func focus_first() -> void:
    var b := find_children("*", "Button", true, false)
    if b.size() > 0:
        (b[0] as Control).grab_focus()
