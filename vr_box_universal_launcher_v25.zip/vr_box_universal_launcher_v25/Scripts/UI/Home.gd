extends Control
## Android-VR style HOME: clock, status, floating dock, paged app grid.

const Ui = preload("res://Scripts/UI/Ui.gd")
const AppIcon = preload("res://Scripts/UI/AppIcon.gd")
const PER_PAGE := 10
const COLS := 5
const HOST_W := 800.0
const HOST_H := 316.0
const TRACK_H := 220.0
const DAYS := ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
const MONTHS := ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

var _clock: Label
var _date: Label
var _batt: Label
var _wifi_icon: TextureRect
var _batt_icon: TextureRect
var _dock: HBoxContainer
var _fav_pill: PanelContainer
var _host: Control
var _pages_root: Control
var _grids: Array[GridContainer] = []
var _dots: HBoxContainer
var _thumb: Panel
var _track: Control
var _hint: HBoxContainer
var _page := 0
var _page_count := 1
var _flyout: Control = null
var _press_x := 0.0
var _dragging := false
var _page_tween: Tween


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var v := VBoxContainer.new()
    v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    v.alignment = BoxContainer.ALIGNMENT_CENTER
    v.add_theme_constant_override("separation", 6)
    v.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(v)

    _clock = Ui.label("", 92)
    _clock.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(_clock)
    _date = Ui.label("", 24, Color(1, 1, 1, 0.9))
    _date.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(_date)
    v.add_child(_build_status())
    v.add_child(_spacer(18))
    _dock = _build_dock()
    v.add_child(_dock)
    v.add_child(_spacer(30))

    _host = Control.new()
    _host.custom_minimum_size = Vector2(HOST_W, HOST_H)
    _host.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    _host.clip_contents = true
    _host.mouse_filter = Control.MOUSE_FILTER_PASS
    _host.gui_input.connect(_host_input)
    v.add_child(_host)
    _pages_root = Control.new()
    _pages_root.mouse_filter = Control.MOUSE_FILTER_PASS
    _host.add_child(_pages_root)
    _build_pages()

    _dots = HBoxContainer.new()
    _dots.alignment = BoxContainer.ALIGNMENT_CENTER
    _dots.add_theme_constant_override("separation", 4)
    v.add_child(_dots)
    _build_dots()

    _hint = HBoxContainer.new()
    _hint.alignment = BoxContainer.ALIGNMENT_CENTER
    _hint.add_theme_constant_override("separation", 10)
    _hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v.add_child(_hint)
    var note := Ui.label("", 18, Color(1, 0.8, 0.45, 0.95))
    note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    if not Apps.has_native():
        note.text = "Preview only: real app launching works on the Android phone"
    v.add_child(note)

    _track = Control.new()
    _track.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_track)
    _track.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT)
    _track.offset_left = -26.0
    _track.offset_right = -20.0
    _track.offset_top = -110.0
    _track.offset_bottom = 110.0
    var tr := Panel.new()
    var tsb := StyleBoxFlat.new()
    tsb.bg_color = Color(1, 1, 1, 0.12)
    tsb.set_corner_radius_all(3)
    tr.add_theme_stylebox_override("panel", tsb)
    tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _track.add_child(tr)
    _thumb = Panel.new()
    var thsb := StyleBoxFlat.new()
    thsb.bg_color = Color(1, 1, 1, 0.7)
    thsb.set_corner_radius_all(3)
    _thumb.add_theme_stylebox_override("panel", thsb)
    _thumb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _track.add_child(_thumb)

    var timer := Timer.new()
    timer.wait_time = 1.0
    timer.autostart = true
    timer.timeout.connect(_tick)
    add_child(timer)
    Settings.changed.connect(func(k: String) -> void:
        if k == "control_mode" or k == "vr_enabled":
            _refresh_hint()
        elif k == "favorites":
            _rebuild_fav())
    _tick()
    _refresh_hint()
    _go_page(Launcher.home_page_index, false)
    _intro()


func _spacer(h: float) -> Control:
    var c := Control.new()
    c.custom_minimum_size = Vector2(0, h)
    c.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return c


func _intro() -> void:
    await get_tree().process_frame
    _dock.pivot_offset = _dock.size * 0.5
    _dock.modulate.a = 0.0
    _dock.scale = Vector2(0.9, 0.9)
    var t := create_tween().set_parallel(true).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    t.tween_property(_dock, "modulate:a", 1.0, 0.35)
    t.tween_property(_dock, "scale", Vector2.ONE, 0.4)


# ---------------------------------------------------------------- status/clock
func _build_status() -> HBoxContainer:
    var h := HBoxContainer.new()
    h.alignment = BoxContainer.ALIGNMENT_CENTER
    h.add_theme_constant_override("separation", 8)
    _wifi_icon = _small_icon("ic_wifi")
    h.add_child(_wifi_icon)
    _batt_icon = _small_icon("ic_battery")
    h.add_child(_batt_icon)
    _batt = Ui.label("n/a", 18, Color(1, 1, 1, 0.8))
    h.add_child(_batt)
    return h


func _small_icon(n: String) -> TextureRect:
    var t := TextureRect.new()
    t.texture = load("res://Assets/Icons/%s.png" % n) as Texture2D
    t.custom_minimum_size = Vector2(22, 22)
    t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    t.stretch_mode = TextureRect.STRETCH_SCALE
    t.modulate = Color(1, 1, 1, 0.4)
    t.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return t


var _tick_n := 0


func _tick() -> void:
    var d := Time.get_datetime_dict_from_system()
    var h12: int = int(d["hour"]) % 12
    if h12 == 0:
        h12 = 12
    _clock.text = "%d:%02d" % [h12, int(d["minute"])]
    _date.text = "%s, %s %d" % [DAYS[int(d["weekday"])], MONTHS[int(d["month"]) - 1], int(d["day"])]
    _tick_n += 1
    if _tick_n % 10 == 1:
        _update_status()


## Wi-Fi/battery need native access; without the plugin they are shown as n/a.
func _update_status() -> void:
    if Apps.plugin == null:
        return
    Apps.last_status_raw = str(Apps.plugin.call("getStatus"))
    var parsed: Variant = JSON.parse_string(Apps.last_status_raw)
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    _batt.text = "%d%%" % int(parsed.get("battery", -1)) if int(parsed.get("battery", -1)) >= 0 else "n/a"
    _batt_icon.modulate.a = 0.95
    _wifi_icon.modulate.a = 0.95 if bool(parsed.get("wifi", false)) else 0.3


# ------------------------------------------------------------------------ dock
func _pill(children: Array) -> PanelContainer:
    var p := PanelContainer.new()
    p.add_theme_stylebox_override("panel", Ui.glass(40, 0.5))
    p.mouse_filter = Control.MOUSE_FILTER_PASS
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 8)
    h.mouse_filter = Control.MOUSE_FILTER_PASS
    for c in children:
        h.add_child(c)
    p.add_child(h)
    return p


func _dock_btn(icon: String, cb: Callable, wide: bool = false) -> Button:
    var b := Ui.icon_button(icon, 64.0)
    if wide:
        b.custom_minimum_size = Vector2(112, 64)
        var sb := StyleBoxFlat.new()
        sb.bg_color = Color(1, 1, 1, 0.14)
        sb.set_corner_radius_all(32)
        b.add_theme_stylebox_override("normal", sb)
    b.pressed.connect(cb)
    return b


func _build_dock() -> HBoxContainer:
    var d := HBoxContainer.new()
    d.alignment = BoxContainer.ALIGNMENT_CENTER
    d.add_theme_constant_override("separation", 14)
    d.mouse_filter = Control.MOUSE_FILTER_PASS
    d.add_child(_pill([_dock_btn("ic_home", func() -> void: _go_page(0), true)]))
    d.add_child(_pill([
        _dock_btn("ic_search", func() -> void: Apps.launch(Apps.GOOGLE)),
        _dock_btn("ic_assistant", func() -> void: Apps.launch(Apps.ASSISTANT)),
    ]))
    d.add_child(_pill([
        _dock_btn("ic_recents", func() -> void: _open_flyout("recents")),
        _dock_btn("ic_bell", func() -> void: _open_flyout("notifications")),
        _dock_btn("ic_quick_settings", func() -> void: _open_flyout("quick")),
    ]))
    _fav_pill = _build_fav_pill()
    d.add_child(_fav_pill)
    return d


## Favorites dock: up to 5 favorite apps (edit in Library > Edit favorites).
func _build_fav_pill() -> PanelContainer:
    var kids: Array = []
    for f in Apps.favorites():
        var b := Ui.icon_button("ic_home", 56.0)
        var tex := Apps.icon_texture(f)
        var col: Variant = f.get("color", "#455A64")
        var sb := StyleBoxFlat.new()
        sb.bg_color = col if typeof(col) == TYPE_COLOR else Color(str(col))
        sb.set_corner_radius_all(28)
        b.add_theme_stylebox_override("normal", sb)
        b.add_theme_constant_override("icon_max_width", 38)
        if tex != null:
            b.icon = tex
        else:
            b.icon = null
            b.text = str(f.get("glyph", "?"))
        var app: Dictionary = f
        b.pressed.connect(func() -> void: Apps.launch(app))
        kids.append(b)
    if kids.is_empty():
        var add := Ui.button("+ Favorites", false, Vector2(150, 56), 18)
        add.pressed.connect(func() -> void: Launcher.go("library", "fav"))
        kids.append(add)
    return _pill(kids)


func _rebuild_fav() -> void:
    var parent := _fav_pill.get_parent()
    parent.remove_child(_fav_pill)
    _fav_pill.queue_free()
    _fav_pill = _build_fav_pill()
    parent.add_child(_fav_pill)


# ------------------------------------------------------------------- app pages
func _build_pages() -> void:
    var apps: Array = Apps.HOME_APPS
    _page_count = maxi(1, int(ceil(apps.size() / float(PER_PAGE))))
    for p in _page_count:
        var g := GridContainer.new()
        g.columns = COLS
        g.add_theme_constant_override("h_separation", 24)
        g.add_theme_constant_override("v_separation", 20)
        g.position = Vector2(p * HOST_W + 22.0, 8.0)
        g.size = Vector2(756, 300)
        g.mouse_filter = Control.MOUSE_FILTER_PASS
        _pages_root.add_child(g)
        _grids.append(g)
        for i in range(p * PER_PAGE, mini(apps.size(), (p + 1) * PER_PAGE)):
            var icon := AppIcon.new()
            icon.setup(apps[i])
            g.add_child(icon)
            if p == 0:
                icon.intro.call_deferred(0.15 + 0.04 * float(i))


func _build_dots() -> void:
    for c in _dots.get_children():
        c.queue_free()
    for i in _page_count:
        var b := Button.new()
        b.custom_minimum_size = Vector2(34, 34)
        b.flat = true
        b.focus_mode = Control.FOCUS_ALL
        var e := StyleBoxEmpty.new()
        for s in ["normal", "hover", "pressed", "disabled"]:
            b.add_theme_stylebox_override(s, e)
        b.add_theme_stylebox_override("focus", Ui.focus_ring(17))
        var dot := Panel.new()
        var sb := StyleBoxFlat.new()
        sb.bg_color = Color(1, 1, 1, 0.9 if i == _page else 0.35)
        sb.set_corner_radius_all(6)
        dot.add_theme_stylebox_override("panel", sb)
        dot.size = Vector2(12, 12)
        dot.position = Vector2(11, 11)
        dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
        b.add_child(dot)
        var idx := i
        b.pressed.connect(func() -> void: _go_page(idx))
        Ui.hook(b)
        _dots.add_child(b)


func _go_page(idx: int, animate: bool = true) -> void:
    idx = clampi(idx, 0, _page_count - 1)
    var changed := idx != _page
    _page = idx
    Launcher.home_page_index = idx
    if changed and animate:
        Sfx.play("scroll")
    for i in _grids.size():
        if i == idx:
            _grids[i].visible = true
    var target := -idx * HOST_W
    if _page_tween != null and _page_tween.is_valid():
        _page_tween.kill()
    if animate:
        _page_tween = create_tween().set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
        _page_tween.tween_property(_pages_root, "position:x", target, 0.28)
        _page_tween.tween_callback(_apply_page_focus)
    else:
        _pages_root.position.x = target
        _apply_page_focus()
    for i in _dots.get_child_count():
        var dot := _dots.get_child(i).get_child(0) as Panel
        var sb := dot.get_theme_stylebox("panel").duplicate() as StyleBoxFlat
        sb.bg_color.a = 0.9 if i == idx else 0.35
        dot.add_theme_stylebox_override("panel", sb)
    var th := TRACK_H / float(_page_count)
    var tt := create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    tt.tween_property(_thumb, "position:y", th * idx, 0.25)
    _thumb.size = Vector2(6.0, th)


## Only the visible page's icons are focusable/selectable.
func _apply_page_focus() -> void:
    var locked := is_instance_valid(_flyout)
    for i in _grids.size():
        var active := i == _page
        _grids[i].visible = active
        for c in _grids[i].get_children():
            (c as Control).focus_mode = Control.FOCUS_ALL if (active and not locked) else Control.FOCUS_NONE


func _host_input(e: InputEvent) -> void:
    if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
        if e.pressed:
            _press_x = e.position.x
            _dragging = true
        else:
            if _dragging:
                var dx: float = e.position.x - _press_x
                if absf(dx) > 70.0:
                    _go_page(_page + (1 if dx < 0.0 else -1))
            _dragging = false
    elif e is InputEventMouseMotion and _dragging and absf(e.position.x - _press_x) > 30.0:
        Launcher.block_clicks(0.4)  # a swipe must not launch an app


func _unhandled_input(e: InputEvent) -> void:
    if is_instance_valid(_flyout):
        return
    if e.is_action_pressed("launcher_next"):
        _go_page(_page + 1)
    elif e.is_action_pressed("launcher_prev"):
        _go_page(_page - 1)


func focus_first() -> void:
    if _grids.size() > _page and _grids[_page].get_child_count() > 0:
        (_grids[_page].get_child(0) as Control).grab_focus()


# ---------------------------------------------------------------------- hints
func _refresh_hint() -> void:
    for c in _hint.get_children():
        c.queue_free()
    var mode: String = Settings.data["control_mode"]
    if mode == "gamepad":
        _hint_item("xbox_dpad", "Move")
        _hint_item("xbox_button_a", "Select")
        _hint_item("xbox_button_b", "Back")
        _hint_item("xbox_lb", "")
        _hint_item("xbox_rb", "Pages")
    elif mode == "head":
        _hint_text("Move your head to the icon and hold until the ring fills")
    else:
        _hint_item("touch_tap", "Tap")
        _hint_item("touch_swipe_horizontal", "Swipe for pages")


func _hint_item(icon: String, text: String) -> void:
    var t := TextureRect.new()
    t.texture = load("res://Assets/Controller/%s.png" % icon) as Texture2D
    t.custom_minimum_size = Vector2(34, 34)
    t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    t.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _hint.add_child(t)
    if text != "":
        _hint.add_child(Ui.label(text, 18, Color(1, 1, 1, 0.8)))


func _hint_text(text: String) -> void:
    _hint.add_child(Ui.label(text, 18, Color(1, 1, 1, 0.8)))


# -------------------------------------------------------------------- flyouts
func _open_flyout(kind: String) -> void:
    if is_instance_valid(_flyout):
        _close_flyout()
    Sfx.play("open")
    var f := Control.new()
    f.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.5)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    dim.gui_input.connect(func(e: InputEvent) -> void:
        if e is InputEventMouseButton and e.pressed:
            _close_flyout())
    f.add_child(dim)
    var cc := CenterContainer.new()
    cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    f.add_child(cc)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", Ui.glass(32, 0.88))
    cc.add_child(panel)
    var m := MarginContainer.new()
    for s in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
        m.add_theme_constant_override(s, 28)
    panel.add_child(m)
    var col := VBoxContainer.new()
    col.custom_minimum_size = Vector2(640, 0)
    col.add_theme_constant_override("separation", 16)
    m.add_child(col)
    var first: Control = null
    match kind:
        "recents":
            col.add_child(Ui.label("Recent apps", 34))
            if Apps.recents.is_empty():
                col.add_child(Ui.label("Nothing launched yet in this session.", 22, Color(1, 1, 1, 0.8)))
            else:
                var hb := HBoxContainer.new()
                hb.add_theme_constant_override("separation", 16)
                col.add_child(hb)
                for a in Apps.recents:
                    var ic := AppIcon.new()
                    ic.setup(a)
                    hb.add_child(ic)
                    if first == null:
                        first = ic
        "notifications":
            col.add_child(Ui.label("Notifications", 34))
            var l := Ui.label("Not connected. Showing real notifications needs Android's Notification Access permission and the native plugin - not implemented in this build.", 22, Color(1, 1, 1, 0.85))
            l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            col.add_child(l)
        "quick":
            col.add_child(Ui.label("Quick settings", 34))
            col.add_child(Ui.choice("Control mode", "control_mode", ["head", "gamepad", "touch"], ["Head (gaze)", "Gamepad", "Touch"]))
            col.add_child(Ui.toggle("Stereo VR display", "vr_enabled"))
            col.add_child(Ui.stepper("UI volume", "volume", 0.0, 1.0, 0.1, "%.1f", 300.0, 160.0))
            var more := Ui.button("All settings...", false, Vector2(0, 56))
            more.pressed.connect(func() -> void:
                _close_flyout()
                Launcher.go("settings"))
            col.add_child(more)
    var close := Ui.button("Close", true, Vector2(0, 56))
    close.pressed.connect(_close_flyout)
    col.add_child(close)
    add_child(f)
    _flyout = f
    Launcher.modal = f
    _apply_page_focus()
    _lock_background(true)
    if Settings.data["control_mode"] == "gamepad":
        (first if first != null else close).grab_focus()


func _lock_background(lock: bool) -> void:
    for n in get_tree().get_nodes_in_group("gaze_target"):
        var c := n as Control
        if c == null or not is_ancestor_of(c):
            continue
        if is_instance_valid(_flyout) and _flyout.is_ancestor_of(c):
            continue
        if lock:
            c.focus_mode = Control.FOCUS_NONE
        else:
            c.focus_mode = Control.FOCUS_ALL


func _close_flyout() -> void:
    if not is_instance_valid(_flyout):
        return
    Sfx.play("close")
    var f := _flyout
    _flyout = null
    Launcher.modal = null
    f.queue_free()
    _lock_background(false)
    _apply_page_focus()


func handle_back() -> bool:
    if is_instance_valid(_flyout):
        _close_flyout()
        return true
    if _page > 0:
        _go_page(0)
        return true
    return false
