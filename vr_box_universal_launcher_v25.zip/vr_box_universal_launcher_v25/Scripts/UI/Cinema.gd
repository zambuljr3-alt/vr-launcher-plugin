extends Control
## CINEMA MODE 2.0.
## Sources: demo test pattern, or live Android screen-capture mirror (native plugin + user consent).
## VR on: the page becomes a large flat/curved 3D screen (size, distance, height, brightness).
## Play/Pause freezes the mirrored frame (the capture source itself keeps running on the phone).

const Ui = preload("res://Scripts/UI/Ui.gd")
const TestScreen = preload("res://Scripts/UI/TestScreen.gd")

var _bg: ColorRect
var _bar: VBoxContainer
var _holder: Control
var _demo: Control
var _mirror: TextureRect
var _status: Label
var _src_btn: Button
var _play_btn: Button


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    _bg = ColorRect.new()
    _bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_bg)
    _holder = Control.new()
    _holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _holder.offset_bottom = -250.0
    _holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_holder)
    _demo = TestScreen.new()
    _holder.add_child(_demo)
    _mirror = TextureRect.new()
    _mirror.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _mirror.stretch_mode = TextureRect.STRETCH_SCALE
    _mirror.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _holder.add_child(_mirror)
    _holder.resized.connect(_layout)
    _build_bar()
    Settings.changed.connect(func(_k: String) -> void: _refresh())
    Capture.frame_ready.connect(func(t: Texture2D) -> void: _mirror.texture = t)
    _refresh()
    _layout.call_deferred()


func _src() -> String:
    return str(Settings.data.get("cinema_source", "demo"))


func _refresh() -> void:
    if _bg == null:
        return
    var comfort := float(Settings.data.get("cinema_brightness", 1.0))
    _bg.color = Color(0, 0, 0, 0.9)
    var mirror := _src() == "capture"
    _demo.visible = not mirror
    _mirror.visible = mirror
    var b := clampf(comfort, 0.2, 1.5)
    _holder.modulate = Color(b, b, b, 1.0)
    _src_btn.text = "Source: Screen capture" if mirror else "Source: Demo pattern"
    _play_btn.text = "Play" if Capture.paused else "Pause"
    _play_btn.disabled = not mirror
    if mirror:
        _status.text = "Mirror of the phone screen via Android screen capture (not an app running in Godot). Protected content may show black."
    else:
        _status.text = "Demo test pattern. Choose 'Screen capture' + 'Start capture' to mirror the phone screen (needs native plugin)."
    _layout()


func _layout() -> void:
    if _holder == null:
        return
    var area := _holder.size
    var s := 1.0 if bool(Settings.data["vr_enabled"]) else clampf(float(Settings.data["cinema_size"]) / 12.0, 0.35, 1.0)
    var w := minf(area.x * s, area.y * s * 16.0 / 9.0)
    var sz := Vector2(w, w * 9.0 / 16.0)
    for c in [_demo, _mirror]:
        (c as Control).size = sz
        (c as Control).position = (area - sz) * 0.5


func _flag(on_text: String, off_text: String, key: String) -> Button:
    var b := Ui.button("", false, Vector2(190, 56), 20)
    var refresh := func() -> void:
        var on: bool = bool(Settings.data.get(key, false))
        b.text = on_text if on else off_text
        Ui.style_button(b, on)
    b.pressed.connect(func() -> void:
        Settings.set_value(key, not bool(Settings.data.get(key, false)))
        refresh.call())
    refresh.call()
    return b


func _row(bar: VBoxContainer) -> HBoxContainer:
    var r := HBoxContainer.new()
    r.alignment = BoxContainer.ALIGNMENT_CENTER
    r.add_theme_constant_override("separation", 16)
    bar.add_child(r)
    return r


func _build_bar() -> void:
    _bar = VBoxContainer.new()
    _bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    _bar.offset_top = -240.0
    _bar.offset_left = 30.0
    _bar.offset_right = -30.0
    _bar.offset_bottom = -8.0
    _bar.add_theme_constant_override("separation", 6)
    _bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_bar)
    var r1 := _row(_bar)
    var home := Ui.button("Home", true, Vector2(120, 56))
    home.pressed.connect(func() -> void: Launcher.go_home())
    r1.add_child(home)
    r1.add_child(Ui.stepper("Size", "cinema_size", 4.0, 16.0, 1.0, "%.0f m", 60.0, 80.0))
    r1.add_child(Ui.stepper("Dist", "cinema_distance", 2.0, 10.0, 0.5, "%.1f m", 60.0, 80.0))
    var r2 := _row(_bar)
    r2.add_child(Ui.stepper("Bright", "cinema_brightness", 0.3, 1.5, 0.1, "%.1f", 80.0, 80.0))
    r2.add_child(Ui.stepper("Height", "cinema_height", -2.0, 2.0, 0.25, "%.2f m", 80.0, 80.0))
    r2.add_child(_flag("Curved screen", "Flat screen", "cinema_curved"))
    var r3 := _row(_bar)
    _src_btn = Ui.button("", false, Vector2(300, 56), 20)
    _src_btn.pressed.connect(func() -> void:
        Settings.set_value("cinema_source", "demo" if _src() == "capture" else "capture"))
    r3.add_child(_src_btn)
    var start := Ui.button("Start capture", true, Vector2(200, 56), 20)
    start.pressed.connect(func() -> void:
        Settings.set_value("cinema_source", "capture")
        Launcher.toast(Capture.request(), not Capture.available()))
    r3.add_child(start)
    _play_btn = Ui.button("Pause", false, Vector2(140, 56), 20)
    _play_btn.pressed.connect(func() -> void:
        Capture.paused = not Capture.paused
        _refresh())
    r3.add_child(_play_btn)
    _status = Ui.label("", 15, Color(1, 1, 1, 0.75))
    _status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _bar.add_child(_status)


func focus_first() -> void:
    var b := find_children("*", "Button", true, false)
    if b.size() > 0:
        (b[0] as Control).grab_focus()
