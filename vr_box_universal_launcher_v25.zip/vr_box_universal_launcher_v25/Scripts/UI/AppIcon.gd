extends Button
## Circular application icon (built from plain nodes: Panel + TextureRect/Label), name label,
## focus ring, focus scaling, favorite star. No custom _draw: easier to debug and more robust.

const Ui = preload("res://Scripts/UI/Ui.gd")
const DISC := 84.0

var app: Dictionary = {}
var _disc: Panel
var _ring: Panel
var _label: Label
var _tween: Tween


func setup(a: Dictionary) -> void:
    app = a


func _ready() -> void:
    custom_minimum_size = Vector2(132, 140)
    flat = true
    focus_mode = Control.FOCUS_ALL
    mouse_filter = Control.MOUSE_FILTER_PASS  # lets Home see swipe gestures
    var empty := StyleBoxEmpty.new()
    for s in ["normal", "hover", "pressed", "focus", "disabled", "hover_pressed"]:
        add_theme_stylebox_override(s, empty)
    _build_disc()
    _label = Ui.label(str(app.get("name", "?")), 20)
    _label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _label.clip_text = true
    add_child(_label)
    resized.connect(_layout)
    _layout()
    Ui.hook(self)
    pressed.connect(func() -> void:
        _pulse()
        Apps.launch(app))
    focus_entered.connect(_on_focus)
    focus_exited.connect(_on_unfocus)
    button_down.connect(func() -> void: _scale_to(0.92))
    button_up.connect(func() -> void: _scale_to(1.12 if has_focus() else 1.0))


func _build_disc() -> void:
    var tex: Texture2D = Apps.icon_texture(app)
    var col: Variant = app.get("color", "#455A64")
    var base: Color = col if typeof(col) == TYPE_COLOR else Color(str(col))
    var img_size: float = float(app.get("icon_size", 54.0))
    if app.has("tex"):  # real icon from the phone: show on a light disc
        base = Color(0.96, 0.96, 0.98)
        img_size = 60.0
    _disc = Panel.new()
    _disc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _disc.size = Vector2(DISC, DISC)
    var sb := StyleBoxFlat.new()
    sb.bg_color = base
    sb.set_corner_radius_all(int(DISC / 2.0))
    sb.set_border_width_all(2)
    sb.border_color = Color(1, 1, 1, 0.18)
    _disc.add_theme_stylebox_override("panel", sb)
    add_child(_disc)
    if tex != null:
        var img := TextureRect.new()
        img.texture = tex
        img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        img.mouse_filter = Control.MOUSE_FILTER_IGNORE
        img.size = Vector2(img_size, img_size)
        img.position = (Vector2(DISC, DISC) - img.size) * 0.5
        _disc.add_child(img)
    else:
        if app.has("icon"):
            Apps.icons_missing += 1
            push_warning("Icon missing or not imported: %s" % str(app["icon"]))
        var g := Ui.label(str(app.get("glyph", "?")), 34, Color(str(app.get("glyph_color", "#FFFFFF"))))
        g.add_theme_font_override("font", Ui.font())
        g.size = Vector2(DISC, DISC)
        g.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        g.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        g.mouse_filter = Control.MOUSE_FILTER_IGNORE
        _disc.add_child(g)
    if app.has("pkgs") and Apps.is_favorite(app):
        var star := Panel.new()
        var ssb := StyleBoxFlat.new()
        ssb.bg_color = Color(1.0, 0.78, 0.15)
        ssb.set_corner_radius_all(9)
        ssb.set_border_width_all(1)
        ssb.border_color = Color(0, 0, 0, 0.4)
        star.add_theme_stylebox_override("panel", ssb)
        star.size = Vector2(18, 18)
        star.position = Vector2(DISC - 20.0, 2.0)
        star.mouse_filter = Control.MOUSE_FILTER_IGNORE
        _disc.add_child(star)
    _ring = Panel.new()
    var rsb := StyleBoxFlat.new()
    rsb.draw_center = false
    rsb.set_border_width_all(3)
    rsb.border_color = Color(1, 1, 1, 0.95)
    rsb.set_corner_radius_all(48)
    _ring.add_theme_stylebox_override("panel", rsb)
    _ring.size = Vector2(DISC + 10.0, DISC + 10.0)
    _ring.position = Vector2(-5.0, -5.0)
    _ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _ring.modulate.a = 0.0
    _disc.add_child(_ring)


func _layout() -> void:
    pivot_offset = size * 0.5
    _disc.position = Vector2((size.x - DISC) * 0.5, 4.0)
    _label.position = Vector2(0, DISC + 10.0)
    _label.size = Vector2(size.x, 30.0)


func _pulse() -> void:
    if _tween != null and _tween.is_valid():
        _tween.kill()
    _tween = create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    _tween.tween_property(self, "scale", Vector2.ONE * 0.88, 0.08)
    _tween.tween_property(self, "scale", Vector2.ONE * (1.12 if has_focus() else 1.0), 0.18)


## Staggered pop-in used by Home. Always ends fully visible, even if the tween is interrupted.
func intro(delay: float) -> void:
    modulate.a = 0.0
    scale = Vector2(0.8, 0.8)
    var t := create_tween().set_parallel(true).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    t.tween_property(self, "modulate:a", 1.0, 0.25).set_delay(delay)
    t.tween_property(self, "scale", Vector2.ONE, 0.3).set_delay(delay)
    get_tree().create_timer(delay + 0.6).timeout.connect(func() -> void:
        if is_instance_valid(self):
            modulate.a = 1.0
            if scale.x < 0.99 and not has_focus():
                scale = Vector2.ONE)


func _scale_to(s: float) -> void:
    if _tween != null and _tween.is_valid():
        _tween.kill()
    _tween = create_tween().set_parallel(true).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    _tween.tween_property(self, "scale", Vector2.ONE * s, 0.12)


func _on_focus() -> void:
    if Settings.data["control_mode"] == "touch":
        return
    _scale_to(1.12)
    create_tween().tween_property(_ring, "modulate:a", 1.0, 0.12)


func _on_unfocus() -> void:
    _scale_to(1.0)
    create_tween().tween_property(_ring, "modulate:a", 0.0, 0.12)
