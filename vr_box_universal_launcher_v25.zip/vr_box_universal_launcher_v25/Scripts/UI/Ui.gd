extends RefCounted
## Shared UI factory: Kenney-skinned buttons, glass panels, setting rows.
## Every interactive control is registered in group "gaze_target" via hook().

const BTN_GREY := "res://Assets/UI/btn_grey.png"
const BTN_BLUE := "res://Assets/UI/btn_blue.png"
const TRACK := "res://Assets/UI/slide_track.png"
const FILL := "res://Assets/UI/slide_fill.png"
const FONT := "res://Assets/Fonts/KenneyFutureNarrow.ttf"


static func font() -> Font:
    return load(FONT) as Font


static func glass(radius: int = 28, alpha: float = 0.45) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = Color(0.06, 0.07, 0.09, alpha)
    s.set_corner_radius_all(radius)
    s.set_border_width_all(1)
    s.border_color = Color(1, 1, 1, 0.12)
    s.set_content_margin_all(10)
    return s


static func focus_ring(radius: int = 14) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.draw_center = false
    s.set_border_width_all(3)
    s.border_color = Color(1, 1, 1, 0.95)
    s.set_corner_radius_all(radius)
    return s


static func hook(c: Control) -> void:
    c.add_to_group("gaze_target")
    c.focus_entered.connect(func() -> void: Sfx.play("tick"))
    if c is BaseButton:
        (c as BaseButton).pressed.connect(func() -> void: Sfx.play("click"))


static func label(text: String, size: int = 22, color: Color = Color.WHITE) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.55))
    l.add_theme_constant_override("shadow_offset_x", 1)
    l.add_theme_constant_override("shadow_offset_y", 1)
    return l


static func _tex_box(path: String, tint: Color = Color.WHITE) -> StyleBoxTexture:
    var s := StyleBoxTexture.new()
    s.texture = load(path) as Texture2D
    s.texture_margin_left = 16.0
    s.texture_margin_right = 16.0
    s.texture_margin_top = 16.0
    s.texture_margin_bottom = 18.0
    s.content_margin_left = 20.0
    s.content_margin_right = 20.0
    s.content_margin_top = 8.0
    s.content_margin_bottom = 12.0
    s.modulate_color = tint
    return s


static func style_button(b: Button, blue: bool) -> void:
    var path := BTN_BLUE if blue else BTN_GREY
    b.add_theme_stylebox_override("normal", _tex_box(path))
    b.add_theme_stylebox_override("hover", _tex_box(path, Color(1.18, 1.18, 1.18)))
    b.add_theme_stylebox_override("pressed", _tex_box(path, Color(0.78, 0.78, 0.8)))
    b.add_theme_stylebox_override("disabled", _tex_box(path, Color(0.6, 0.6, 0.6, 0.6)))
    b.add_theme_stylebox_override("focus", focus_ring(16))
    var fc := Color.WHITE if blue else Color(0.1, 0.12, 0.16)
    for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
        b.add_theme_color_override(k, fc)


static func button(text: String, blue: bool = false, min_size: Vector2 = Vector2(0, 60), font_size: int = 22) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.focus_mode = Control.FOCUS_ALL
    b.add_theme_font_override("font", font())
    b.add_theme_font_size_override("font_size", font_size)
    style_button(b, blue)
    hook(b)
    return b


static func icon_button(icon_name: String, size: float = 64.0) -> Button:
    var b := Button.new()
    b.custom_minimum_size = Vector2(size, size)
    b.icon = load("res://Assets/Icons/%s.png" % icon_name) as Texture2D
    b.expand_icon = true
    b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
    b.add_theme_constant_override("icon_max_width", int(size * 0.5))
    var r := int(size / 2.0)
    var n := StyleBoxFlat.new()
    n.bg_color = Color(1, 1, 1, 0.0)
    n.set_corner_radius_all(r)
    var h := StyleBoxFlat.new()
    h.bg_color = Color(1, 1, 1, 0.22)
    h.set_corner_radius_all(r)
    b.add_theme_stylebox_override("normal", n)
    b.add_theme_stylebox_override("hover", h)
    b.add_theme_stylebox_override("pressed", h)
    b.add_theme_stylebox_override("focus", focus_ring(r))
    hook(b)
    b.resized.connect(func() -> void: b.pivot_offset = b.size * 0.5)
    b.focus_entered.connect(func() -> void:
        b.create_tween().tween_property(b, "scale", Vector2(1.12, 1.12), 0.12))
    b.focus_exited.connect(func() -> void:
        b.create_tween().tween_property(b, "scale", Vector2.ONE, 0.12))
    return b


static func header(title: String) -> HBoxContainer:
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 20)
    var back := icon_button("ic_back", 64.0)
    back.pressed.connect(func() -> void: Launcher.back())
    h.add_child(back)
    var t := label(title, 40)
    t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    h.add_child(t)
    return h


static func stepper(title: String, key: String, lo: float, hi: float, step: float, fmt: String = "%.1f", label_w: float = 300.0, bar_w: float = 300.0) -> HBoxContainer:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    var name_l := label(title, 22)
    name_l.custom_minimum_size = Vector2(label_w, 0)
    name_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    var minus := button("-", false, Vector2(64, 52), 28)
    var plus := button("+", false, Vector2(64, 52), 28)
    var bar := TextureProgressBar.new()
    bar.texture_under = load(TRACK) as Texture2D
    bar.texture_progress = load(FILL) as Texture2D
    bar.nine_patch_stretch = true
    bar.stretch_margin_left = 6
    bar.stretch_margin_right = 6
    bar.custom_minimum_size = Vector2(bar_w, 16)
    bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    bar.min_value = lo
    bar.max_value = hi
    bar.step = 0.0
    var val := label("", 22)
    val.custom_minimum_size = Vector2(80, 0)
    val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    row.add_child(name_l)
    row.add_child(minus)
    row.add_child(bar)
    row.add_child(plus)
    row.add_child(val)
    var refresh := func() -> void:
        var v: float = float(Settings.data[key])
        bar.value = v
        val.text = fmt % v
    var nudge := func(dir: float) -> void:
        var v: float = float(Settings.data[key]) + dir * step
        Settings.set_value(key, clampf(snappedf(v, 0.0001), lo, hi))
        refresh.call()
    minus.pressed.connect(func() -> void: nudge.call(-1.0))
    plus.pressed.connect(func() -> void: nudge.call(1.0))
    refresh.call()
    return row


static func toggle(title: String, key: String, on_text: String = "ON", off_text: String = "OFF") -> HBoxContainer:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    var name_l := label(title, 22)
    name_l.custom_minimum_size = Vector2(300, 0)
    name_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    var b := button("", false, Vector2(170, 52))
    row.add_child(name_l)
    row.add_child(b)
    var refresh := func() -> void:
        var on: bool = bool(Settings.data[key])
        b.text = on_text if on else off_text
        style_button(b, on)
    b.pressed.connect(func() -> void:
        Settings.set_value(key, not bool(Settings.data[key]))
        refresh.call())
    refresh.call()
    return row


static func _idx(values: Array, v: Variant) -> int:
    for i in values.size():
        if typeof(values[i]) == TYPE_STRING:
            if values[i] == v:
                return i
        elif absf(float(values[i]) - float(v)) < 0.0001:
            return i
    return 0


## Cycling button: each press moves to the next value.
static func choice(title: String, key: String, values: Array, texts: Array) -> HBoxContainer:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    var name_l := label(title, 22)
    name_l.custom_minimum_size = Vector2(300, 0)
    name_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    var b := button("", true, Vector2(220, 52))
    row.add_child(name_l)
    row.add_child(b)
    var refresh := func() -> void:
        b.text = str(texts[_idx(values, Settings.data[key])])
    b.pressed.connect(func() -> void:
        var i := (_idx(values, Settings.data[key]) + 1) % values.size()
        Settings.set_value(key, values[i])
        refresh.call())
    refresh.call()
    return row
