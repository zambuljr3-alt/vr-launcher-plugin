extends Control
## CONTROL SETTINGS: Head (gyro + gaze), Bluetooth gamepad (mapping), Touch.

const Ui = preload("res://Scripts/UI/Ui.gd")
const PAD_NAMES := {0: "A", 1: "B", 2: "X", 3: "Y", 4: "View", 5: "Guide", 6: "Menu", 7: "L-Stick", 8: "R-Stick", 9: "LB", 10: "RB", 11: "D-Up", 12: "D-Down", 13: "D-Left", 14: "D-Right"}
const PAD_ICONS := {0: "xbox_button_a", 1: "xbox_button_b", 2: "xbox_button_x", 3: "xbox_button_y", 4: "xbox_button_view", 6: "xbox_button_menu", 9: "xbox_lb", 10: "xbox_rb"}
const MAP_ROWS := [
    ["map_select", "Select"], ["map_back", "Back"], ["map_prev", "Previous page"],
    ["map_next", "Next page"], ["map_home", "Home"],
]

var _modes: HBoxContainer
var _body: VBoxContainer
var _status: Label
var _live: Label
var _capturing := ""


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["margin_left", "margin_right"]:
        margin.add_theme_constant_override(s, 70)
    margin.add_theme_constant_override("margin_top", 26)
    margin.add_theme_constant_override("margin_bottom", 20)
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 14)
    margin.add_child(col)
    col.add_child(Ui.header("Control settings"))
    _modes = HBoxContainer.new()
    _modes.add_theme_constant_override("separation", 14)
    col.add_child(_modes)
    var sc := ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.follow_focus = true
    sc.add_to_group("autoscroll")
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(sc)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", Ui.glass(26, 0.5))
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.add_child(panel)
    _body = VBoxContainer.new()
    _body.add_theme_constant_override("separation", 12)
    panel.add_child(_body)
    Settings.changed.connect(_on_setting)
    _build_modes()
    _build_body()


func _on_setting(key: String) -> void:
    if key == "control_mode":
        _build_modes()
        _build_body()
    elif key.begins_with("map_"):
        _build_body()


func _process(_d: float) -> void:
    if _status != null and is_instance_valid(_status):
        _status.text = _status_text()
    if _live != null and is_instance_valid(_live):
        var g := Input.get_gyroscope()
        var a := Input.get_gravity()
        _live.text = "gyro %.2f %.2f %.2f | gravity %.1f %.1f %.1f | yaw %d  pitch %d deg" % [g.x, g.y, g.z, a.x, a.y, a.z, int(rad_to_deg(Pointer.yaw)), int(rad_to_deg(Pointer.pitch))]


func _status_text() -> String:
    if Pointer.wizard_active:
        return "Wizard: " + Pointer.wizard_text
    if Pointer.is_calibrating():
        return "Calibrating gyro - hold the device still..."
    return Pointer.gyro_status()


func _build_modes() -> void:
    for c in _modes.get_children():
        c.queue_free()
    var cur: String = Settings.data["control_mode"]
    for m in [["head", "Mode 1: Head control"], ["gamepad", "Mode 2: Bluetooth gamepad"], ["touch", "Mode 3: Touch"]]:
        var b := Ui.button(m[1], cur == m[0], Vector2(0, 60))
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var id: String = m[0]
        b.pressed.connect(func() -> void:
            Sfx.play("switch")
            Settings.set_value("control_mode", id))
        _modes.add_child(b)


func _build_body() -> void:
    for c in _body.get_children():
        c.queue_free()
    _status = null
    _live = null
    var mode: String = Settings.data["control_mode"]
    match mode:
        "head":
            var note := Ui.label("3DoF head tracking (rotation only, gyroscope; no position/6DoF). Tilt/turn the phone (or your head in the VR box) to move the cursor; hold it on an item until the ring fills to select it. Gyro-only tracking drifts: use Recenter. Direction is detected by the wizard (turn right, then look up).", 18, Color(1, 1, 1, 0.8))
            note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            _body.add_child(note)
            _status = Ui.label("", 20, Color(0.6, 0.9, 1.0))
            _body.add_child(_status)
            _live = Ui.label("", 17, Color(1, 0.9, 0.5))
            _body.add_child(_live)
            _body.add_child(Ui.stepper("Gaze timer", "gaze_time", 0.5, 4.0, 0.25, "%.2f s"))
            _body.add_child(Ui.stepper("Sensitivity", "sensitivity", 0.3, 3.0, 0.1, "%.1fx"))
            _body.add_child(Ui.stepper("Smoothing (anti-jitter)", "smoothing", 0.0, 0.9, 0.05, "%.2f"))
            _body.add_child(Ui.stepper("Deadzone", "deadzone", 0.0, 0.1, 0.005, "%.3f"))
            _body.add_child(Ui.toggle("Invert yaw", "invert_yaw", "Inverted", "Normal"))
            _body.add_child(Ui.toggle("Invert pitch", "invert_pitch", "Inverted", "Normal"))
            var swp := Ui.button("Swap left/right with up/down", false, Vector2(0, 56))
            swp.pressed.connect(func() -> void:
                var ya: int = int(Settings.data["yaw_axis"])
                var ys: float = float(Settings.data["yaw_sign"])
                Settings.set_value("yaw_axis", int(Settings.data["pitch_axis"]))
                Settings.set_value("yaw_sign", float(Settings.data["pitch_sign"]))
                Settings.set_value("pitch_axis", ya)
                Settings.set_value("pitch_sign", ys)
                Pointer.recenter())
            _body.add_child(swp)
            var wiz := Ui.button("Calibrate direction (wizard)", true, Vector2(0, 60))
            wiz.pressed.connect(func() -> void: Pointer.start_direction_wizard())
            _body.add_child(wiz)
            var hb := HBoxContainer.new()
            hb.add_theme_constant_override("separation", 14)
            var rc := Ui.button("Recenter", true, Vector2(200, 56))
            rc.pressed.connect(func() -> void: Pointer.recenter())
            var cal := Ui.button("Calibrate gyro (hold still)", false, Vector2(330, 56))
            cal.pressed.connect(func() -> void: Pointer.calibrate_gyro())
            hb.add_child(rc)
            hb.add_child(cal)
            _body.add_child(hb)
        "gamepad":
            var pads := Input.get_connected_joypads()
            var names: Array[String] = []
            for id in pads:
                names.append(Input.get_joy_name(id))
            var st := Ui.label("Connected: %s" % (", ".join(names) if not names.is_empty() else "no gamepad detected - pair one in Android Bluetooth settings"), 20, Color(0.6, 0.9, 1.0))
            st.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            _body.add_child(st)
            var fixed := Ui.label("D-pad and left stick move focus (fixed). Remap the buttons below:", 18, Color(1, 1, 1, 0.8))
            _body.add_child(fixed)
            for r in MAP_ROWS:
                _body.add_child(_map_row(r[0], r[1]))
            var reset := Ui.button("Reset mapping", false, Vector2(240, 52))
            reset.pressed.connect(func() -> void: Settings.reset_mapping())
            _body.add_child(reset)
        _:
            var l := Ui.label("Touch navigation: tap icons, swipe the grid for pages. Use this before inserting the phone into the VR Box.", 22, Color(1, 1, 1, 0.9))
            l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            _body.add_child(l)
            var hb2 := HBoxContainer.new()
            hb2.add_theme_constant_override("separation", 24)
            for n in ["touch_tap", "touch_swipe_horizontal"]:
                var t := TextureRect.new()
                t.texture = load("res://Assets/Controller/%s.png" % n) as Texture2D
                t.custom_minimum_size = Vector2(72, 72)
                t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
                t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
                hb2.add_child(t)
            _body.add_child(hb2)


func _map_row(key: String, title: String) -> HBoxContainer:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    var idx := int(Settings.data[key])
    var icon := TextureRect.new()
    icon.custom_minimum_size = Vector2(44, 44)
    icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    if PAD_ICONS.has(idx):
        icon.texture = load("res://Assets/Controller/%s.png" % PAD_ICONS[idx]) as Texture2D
    row.add_child(icon)
    var n := Ui.label(title, 22)
    n.custom_minimum_size = Vector2(230, 0)
    n.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    row.add_child(n)
    var cur := Ui.label(str(PAD_NAMES.get(idx, "Button %d" % idx)), 22, Color(0.7, 0.9, 1.0))
    cur.custom_minimum_size = Vector2(140, 0)
    cur.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    row.add_child(cur)
    var b := Ui.button("Press a button..." if _capturing == key else "Remap", _capturing == key, Vector2(240, 52))
    b.pressed.connect(func() -> void:
        _capturing = key
        _build_body())
    row.add_child(b)
    return row


func _input(e: InputEvent) -> void:
    if _capturing == "":
        return
    if e is InputEventKey and e.pressed and e.keycode == KEY_ESCAPE:
        _capturing = ""
        _build_body()
        get_viewport().set_input_as_handled()
        return
    if e is InputEventJoypadButton and e.pressed:
        get_viewport().set_input_as_handled()
        var idx := int(e.button_index)
        var key := _capturing
        if idx >= 11 and idx <= 14 or idx == 5:
            Launcher.toast("D-pad and Guide can't be mapped (D-pad navigates).", true)
            return
        for r in MAP_ROWS:
            if r[0] != key and int(Settings.data[r[0]]) == idx:
                Launcher.toast("%s is already used for '%s'." % [PAD_NAMES.get(idx, "Button"), r[1]], true)
                return
        _capturing = ""
        Settings.set_value(key, idx)
        Launcher.toast("Mapped to %s." % PAD_NAMES.get(idx, "button %d" % idx), false)


func handle_back() -> bool:
    if _capturing != "":
        _capturing = ""
        _build_body()
        return true
    return false


func focus_first() -> void:
    var b := _modes.get_child(0) as Control
    if b != null:
        b.grab_focus()
