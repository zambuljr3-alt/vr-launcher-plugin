extends Control
## Demo content for the Cinema screen: colour bars + moving marker (NOT a screen mirror).

const BARS := [Color.WHITE, Color(1, 1, 0), Color(0, 1, 1), Color(0, 1, 0), Color(1, 0, 1), Color(1, 0, 0), Color(0, 0, 1)]
var _t := 0.0


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(delta: float) -> void:
    if is_visible_in_tree():
        _t += delta
        queue_redraw()


func _draw() -> void:
    var w := size.x
    var h := size.y
    var bw := w / BARS.size()
    for i in BARS.size():
        draw_rect(Rect2(i * bw, 0, bw + 1.0, h * 0.72), BARS[i] * 0.85)
    for i in 16:
        var v := float(i) / 15.0
        draw_rect(Rect2(i * w / 16.0, h * 0.72, w / 16.0 + 1.0, h * 0.28), Color(v, v, v))
    var x := fposmod(_t * w * 0.18, w)
    draw_rect(Rect2(x - 3.0, 0, 6.0, h), Color(0, 0, 0, 0.8))
    var f := ThemeDB.fallback_font
    draw_string(f, Vector2(0, h * 0.45), "DEMO CONTENT - not a mirrored Android screen", HORIZONTAL_ALIGNMENT_CENTER, w, int(maxf(14.0, h * 0.05)), Color.BLACK)
