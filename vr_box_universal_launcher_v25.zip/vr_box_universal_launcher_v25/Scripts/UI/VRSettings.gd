extends Control
## VR DISPLAY settings: stereo toggle, IPD, screen distance, lens calibration, quality.

const Ui = preload("res://Scripts/UI/Ui.gd")


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_PASS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["margin_left", "margin_right"]:
        margin.add_theme_constant_override(s, 70)
    margin.add_theme_constant_override("margin_top", 26)
    margin.add_theme_constant_override("margin_bottom", 20)
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 12)
    margin.add_child(col)
    col.add_child(Ui.header("VR display"))
    var sc := ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.follow_focus = true
    sc.add_to_group("autoscroll")
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(sc)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", Ui.glass(26, 0.5))
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.add_child(panel)
    var body := VBoxContainer.new()
    body.add_theme_constant_override("separation", 12)
    panel.add_child(body)
    var info := Ui.label("Stereo mode (3DoF rotation only, no position tracking): two cameras (left/right eye) in one shared 3D world, with the launcher UI on a 3D panel in front of you. Each eye gets lens (barrel) correction. This is true stereoscopic 3D for a phone VR Box, not a duplicated 2D image. Renderer: %s on %s. Not tested on physical hardware." % [RenderingServer.get_current_rendering_method(), RenderingServer.get_video_adapter_name()], 17, Color(1, 1, 1, 0.8))
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.add_child(info)
    body.add_child(Ui.toggle("Stereo VR mode", "vr_enabled", "ON (VR)", "OFF (flat)"))
    body.add_child(Ui.stepper("IPD", "ipd", 50.0, 75.0, 0.5, "%.1f mm"))
    body.add_child(Ui.stepper("Screen distance", "screen_distance", 1.0, 4.0, 0.1, "%.1f m"))
    body.add_child(Ui.stepper("FOV", "vr_fov", 60.0, 110.0, 1.0, "%.0f deg"))
    body.add_child(Ui.stepper("Left eye shift", "eye_shift_l", -0.1, 0.1, 0.005, "%.3f"))
    body.add_child(Ui.stepper("Right eye shift", "eye_shift_r", -0.1, 0.1, 0.005, "%.3f"))
    body.add_child(Ui.toggle("Curved home screen", "screen_curved", "Curved", "Flat"))
    body.add_child(Ui.stepper("Lens k1", "lens_k1", 0.0, 0.6, 0.02, "%.2f"))
    body.add_child(Ui.stepper("Lens k2", "lens_k2", 0.0, 0.3, 0.01, "%.2f"))
    body.add_child(Ui.stepper("Lens centre shift", "lens_offset", -0.1, 0.1, 0.005, "%.3f"))
    body.add_child(Ui.stepper("Eye height", "lens_offset_y", -0.1, 0.1, 0.005, "%.3f"))
    body.add_child(Ui.choice("VR quality", "vr_quality", [0, 1, 2], ["Low (50%)", "Medium (75%)", "High (100%)"]))
    body.add_child(Ui.toggle("Calibration grid", "cal_grid"))


func focus_first() -> void:
    var back := find_children("*", "Button", true, false)
    if back.size() > 0:
        (back[0] as Control).grab_focus()
