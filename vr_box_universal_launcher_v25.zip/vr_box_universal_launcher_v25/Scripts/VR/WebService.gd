extends Node
## Embedded web screen (autoload "Web"). Needs the NATIVE plugin built from Android/VRLauncherPlugin
## (WebView on a private VirtualDisplay, frames polled as JPEG). Untested on a device.
## Honest limit: this shows WEB pages (YouTube mobile site, Google...) inside the launcher; it is not the
## native YouTube app. Video playback inside the frames must be verified on the phone.

signal frame_ready(tex: Texture2D)

const W := 960
const H := 540
const DPI := 200

var texture: ImageTexture = null
var current_url := ""
var _timer: Timer


func _ready() -> void:
    _timer = Timer.new()
    _timer.wait_time = 0.066
    _timer.timeout.connect(_poll)
    add_child(_timer)


func available() -> bool:
    return Apps.native_plugin and Apps.plugin != null


func open(url: String) -> void:
    if not available():
        return
    current_url = url
    Apps.plugin.call("webOpen", url, W, H, DPI)
    _timer.start()


func close() -> void:
    _timer.stop()
    if available():
        Apps.plugin.call("webClose")


func load_url(url: String) -> void:
    if available():
        current_url = url
        Apps.plugin.call("webLoad", url)


## Position in web pixels (0..W, 0..H).
func tap(p: Vector2) -> void:
    if available():
        Apps.plugin.call("webTap", p.x, p.y)


func scroll(dy: int) -> void:
    if available():
        Apps.plugin.call("webScroll", dy)


func short_next() -> void:
    scroll(600)


func short_prev() -> void:
    scroll(-600)


func back() -> void:
    if available():
        Apps.plugin.call("webBack")


func forward() -> void:
    if available():
        Apps.plugin.call("webForward")


func text(s: String) -> void:
    if available():
        Apps.plugin.call("webText", s)


func key(code: int) -> void:
    if available():
        Apps.plugin.call("webKey", code)


func _poll() -> void:
    if not available():
        return
    var b64 := str(Apps.plugin.call("webGetFrame"))
    if b64 == "":
        return
    var img := Image.new()
    if img.load_jpg_from_buffer(Marshalls.base64_to_raw(b64)) != OK:
        return
    if texture == null or texture.get_size() != Vector2(img.get_size()):
        texture = ImageTexture.create_from_image(img)
    else:
        texture.update(img)
    frame_ready.emit(texture)
