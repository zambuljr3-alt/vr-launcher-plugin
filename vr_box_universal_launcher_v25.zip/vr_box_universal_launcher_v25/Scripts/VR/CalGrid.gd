extends Control
## Lens-calibration grid overlay (VR Display page toggles it).


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    visible = bool(Settings.data["cal_grid"])
    Settings.changed.connect(func(k: String) -> void:
        if k == "cal_grid":
            visible = bool(Settings.data["cal_grid"])
            queue_redraw())


func _draw() -> void:
    var s := size
    var col := Color(0.3, 1.0, 0.6, 0.55)
    var x := 0.0
    while x <= s.x:
        draw_line(Vector2(x, 0), Vector2(x, s.y), col, 1.0)
        x += 80.0
    var y := 0.0
    while y <= s.y:
        draw_line(Vector2(0, y), Vector2(s.x, y), col, 1.0)
        y += 80.0
    var c := s * 0.5
    draw_line(Vector2(c.x, 0), Vector2(c.x, s.y), Color(1, 1, 1, 0.9), 2.0)
    draw_line(Vector2(0, c.y), Vector2(s.x, c.y), Color(1, 1, 1, 0.9), 2.0)
    for r in [120.0, 240.0, 340.0]:
        draw_arc(c, r, 0.0, TAU, 64, Color(1, 0.8, 0.2, 0.8), 2.0, true)
