extends Node
## Android screen-capture mirror (autoload "Capture").
## Needs the NATIVE plugin (Android/VRLauncherPlugin: MediaProjection + foreground service).
## Frames are JPEGs polled from the plugin and shown as a texture. This is a MIRROR of the
## phone screen, NOT an app running inside Godot. Untested; Android asks the user for consent.

signal frame_ready(tex: Texture2D)

var texture: ImageTexture = null
var paused := false
var _timer: Timer


func _ready() -> void:
    _timer = Timer.new()
    _timer.wait_time = 0.125  # ~8 fps
    _timer.timeout.connect(_poll)
    add_child(_timer)


func available() -> bool:
    return Apps.native_plugin and Apps.plugin != null


func is_capturing() -> bool:
    return available() and bool(Apps.plugin.call("isCapturing"))


## Shows Android's official screen-capture consent dialog.
func request() -> String:
    if not available():
        return "Screen capture needs the native plugin (see README): not installed in this build."
    Apps.plugin.call("requestScreenCapture")
    _timer.start()
    return "Android is asking for screen-capture permission. Accept it, then return to the launcher."


func stop() -> void:
    if available():
        Apps.plugin.call("stopScreenCapture")
    _timer.stop()


func _poll() -> void:
    if paused or not available():
        return
    var b64 := str(Apps.plugin.call("getFrame"))
    if b64 == "":
        return
    var img := Image.new()
    if img.load_jpg_from_buffer(Marshalls.base64_to_raw(b64)) != OK:
        return
    if texture == null or texture.get_size() != Vector2(img.get_size()):
        texture = ImageTexture.create_from_image(img)
    else:
        texture.update(img)
    frame_ready.emit(texture)
