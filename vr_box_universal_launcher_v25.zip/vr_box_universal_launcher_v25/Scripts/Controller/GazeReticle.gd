extends Control
## Small reticle with gaze-progress ring. eye_mode=true: fixed at the centre of an
## eye view (VR). eye_mode=false: follows the head cursor on the flat UI preview.

var eye_mode := false


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    size = Vector2(48, 48)
    z_index = 100


func _process(_d: float) -> void:
    var vr: bool = bool(Settings.data["vr_enabled"])
    visible = vr if eye_mode else (Pointer.cursor_visible and not vr)
    if Pointer.wizard_active:
        visible = true
    if not visible:
        return
    if eye_mode:
        var p := get_parent_control()
        if p != null:
            position = (p.size - size) * 0.5
    else:
        position = Pointer.cursor_ui - size * 0.5
    queue_redraw()


func _draw() -> void:
    var c := size * 0.5
    draw_circle(c, 4.0, Color(1, 1, 1, 0.95))
    draw_arc(c, 16.0, 0.0, TAU, 40, Color(1, 1, 1, 0.35), 2.5, true)
    if eye_mode and bool(Settings.data.get("debug_hud", false)):
        var g := Input.get_gyroscope()
        var hv := "-"
        if is_instance_valid(Pointer.hover):
            hv = str(Pointer.hover.name)
        var l1 := "mode:%s  gyro %.2f %.2f %.2f" % [str(Settings.data["control_mode"]), g.x, g.y, g.z]
        var l2 := "yaw %d  pitch %d  hover:%s  gaze %d%%" % [int(rad_to_deg(Pointer.yaw)), int(rad_to_deg(Pointer.pitch)), hv, int(Pointer.gaze_progress * 100.0)]
        draw_string(ThemeDB.fallback_font, Vector2(-190, 120), l1, HORIZONTAL_ALIGNMENT_CENTER, 428.0, 16, Color(1, 1, 0.4))
        draw_string(ThemeDB.fallback_font, Vector2(-190, 140), l2, HORIZONTAL_ALIGNMENT_CENTER, 428.0, 16, Color(1, 1, 0.4))
    if Pointer.wizard_active:
        draw_string(ThemeDB.fallback_font, Vector2(-120, 84), Pointer.wizard_text, HORIZONTAL_ALIGNMENT_CENTER, 288.0, 22, Color(1, 0.9, 0.4))
    if Pointer.gaze_progress > 0.0:
        draw_arc(c, 16.0, -PI / 2.0, -PI / 2.0 + TAU * Pointer.gaze_progress, 48, Color(0.35, 0.75, 1.0), 4.5, true)
