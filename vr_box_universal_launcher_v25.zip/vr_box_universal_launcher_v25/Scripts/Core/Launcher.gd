extends Node
## Navigation state, toasts and click-guard (autoload "Launcher").

signal page_requested(page: String, is_back: bool)
signal toast_requested(message: String, is_error: bool)

var shell: Control = null
var current := "home"
var page_arg := ""
var stack: Array[String] = []
## When set, gaze selection only considers descendants of this control (flyouts).
var modal: Control = null
var home_page_index := 0
## Library 'edit favorites' mode: activating an app toggles its favorite flag instead of launching.
var fav_edit_mode := false
var _block_until_ms := 0


func go(page: String, arg: String = "") -> void:
    if page == current:
        return
    page_arg = arg
    stack.append(current)
    current = page
    modal = null
    Sfx.play("open")
    page_requested.emit(page, false)


func go_home() -> void:
    if current == "home":
        return
    stack.clear()
    current = "home"
    modal = null
    Sfx.play("back")
    page_requested.emit("home", true)


func back() -> void:
    if is_instance_valid(shell) and shell.has_method("handle_back") and shell.call("handle_back"):
        return
    if stack.is_empty():
        return
    current = stack.pop_back()
    modal = null
    Sfx.play("back")
    page_requested.emit(current, true)


func toast(message: String, is_error: bool = false) -> void:
    Sfx.play("error" if is_error else "ok")
    toast_requested.emit(message, is_error)


func activate(b: BaseButton) -> void:
    if b == null or b.disabled:
        return
    if b.toggle_mode:
        b.button_pressed = not b.button_pressed
    else:
        b.pressed.emit()


func block_clicks(seconds: float) -> void:
    _block_until_ms = Time.get_ticks_msec() + int(seconds * 1000.0)


func clicks_blocked() -> bool:
    return Time.get_ticks_msec() < _block_until_ms


func shell_size() -> Vector2:
    return shell.size if is_instance_valid(shell) else Vector2(1280, 720)


func refocus() -> void:
    if is_instance_valid(shell) and shell.has_method("focus_page"):
        shell.call_deferred("focus_page")


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        back()
