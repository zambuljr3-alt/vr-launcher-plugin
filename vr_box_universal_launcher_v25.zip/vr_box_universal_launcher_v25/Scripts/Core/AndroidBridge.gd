extends RefCounted
## Direct GDScript -> Android bridge (no AAR/plugin build). Needs Godot 4.2+ on Android,
## which exposes the "AndroidRuntime" singleton. Only METHOD calls on Java objects are possible
## from GDScript (no field access), so package names are parsed from toString().
## Export preset must enable the permissions: "Query All Packages" (Android 11 app visibility)
## and "Access Network State" (Wi-Fi status).

const NEW_TASK := 0x10000000  # Intent.FLAG_ACTIVITY_NEW_TASK

var _rt: Object = null


static func is_supported() -> bool:
    return OS.get_name() == "Android" and Engine.has_singleton("AndroidRuntime")


func _activity() -> Object:
    if _rt == null:
        _rt = Engine.get_singleton("AndroidRuntime")
    return _rt.call("getActivity")


## Returns "ok", "not_installed" or "error: ...".
func launchPackage(pkg: String) -> String:
    var act: Object = _activity()
    if act == null:
        return "error: no activity"
    var pm: Object = act.call("getPackageManager")
    var intent: Object = pm.call("getLaunchIntentForPackage", pkg)
    if intent == null:
        return "not_installed"
    intent.call("addFlags", NEW_TASK)
    act.call("startActivity", intent)
    return "ok"


## JSON array of {package, label}. Launchable apps only.
func getInstalledApps() -> String:
    var out: Array = []
    var act: Object = _activity()
    if act == null:
        return "[]"
    var pm: Object = act.call("getPackageManager")
    var list: Object = pm.call("getInstalledPackages", 0)
    if list == null:
        return "[]"
    var rx := RegEx.new()
    rx.compile("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)")
    var n: int = int(list.call("size"))
    for i in n:
        var pi: Object = list.call("get", i)
        var m := rx.search(str(pi.call("toString")))
        if m == null:
            continue
        var pkg := m.get_string(1)
        if pm.call("getLaunchIntentForPackage", pkg) == null:
            continue
        var label := pkg
        var ai: Object = pm.call("getApplicationInfo", pkg, 0)
        if ai != null:
            label = str(pm.call("getApplicationLabel", ai).call("toString"))
        out.append({"package": pkg, "label": label})
    return JSON.stringify(out)


## JSON {battery: percent or -1, wifi: bool}.
func getStatus() -> String:
    var act: Object = _activity()
    var battery := -1
    var wifi := false
    if act != null:
        var bm: Object = act.call("getSystemService", "batterymanager")
        if bm != null:
            battery = int(bm.call("getIntProperty", 4))  # BATTERY_PROPERTY_CAPACITY
        var cm: Object = act.call("getSystemService", "connectivity")
        if cm != null:
            var net: Object = cm.call("getActiveNetwork")
            if net != null:
                var caps: Object = cm.call("getNetworkCapabilities", net)
                if caps != null:
                    wifi = bool(caps.call("hasTransport", 1))  # TRANSPORT_WIFI
    return JSON.stringify({"battery": battery, "wifi": wifi})
