extends Node
## Persistent settings + joypad mapping (autoload "Settings").

signal changed(key: String)

const SAVE_PATH := "user://launcher_settings.cfg"
const DEFAULTS_PATH := "res://Settings/default_settings.json"
## input action -> settings key holding the joypad button index
const ACTIONS := {
    "launcher_select": "map_select",
    "launcher_back": "map_back",
    "launcher_prev": "map_prev",
    "launcher_next": "map_next",
    "launcher_home": "map_home",
}

var data: Dictionary = {}
var defaults: Dictionary = {}


func _ready() -> void:
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(DEFAULTS_PATH))
    if typeof(parsed) == TYPE_DICTIONARY:
        defaults = parsed
    data = defaults.duplicate()
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) == OK:
        for k in data.keys():
            if cfg.has_section_key("s", k):
                data[k] = cfg.get_value("s", k)
    if int(cfg.get_value("s", "settings_version", 0)) < int(defaults.get("settings_version", 8)):
        data["gaze_time"] = defaults["gaze_time"]  # new default: 1 second
        data["control_mode"] = defaults["control_mode"]  # old saved "touch" hid the head cursor
        for k in ["yaw_axis", "yaw_sign", "pitch_axis", "pitch_sign", "invert_yaw", "invert_pitch"]:
            data[k] = defaults[k]  # v12: axes swapped (v11) + yaw sign flipped on the Redmi Note 8 Pro
        data["vr_enabled"] = defaults["vr_enabled"]  # v14: start in VR by default
        data["settings_version"] = defaults["settings_version"]
    # Touch cannot be used inside a VR box: never start in VR with touch control.
    if bool(data["vr_enabled"]) and data["control_mode"] == "touch":
        data["control_mode"] = "head"
    # The launcher handles A/B itself so that the mapping is configurable.
    for a in ["ui_accept", "ui_cancel"]:
        for e in InputMap.action_get_events(a):
            if e is InputEventJoypadButton:
                InputMap.action_erase_event(a, e)
    apply_mapping()
    apply_runtime()


## Applies display/performance settings that live outside the UI.
func apply_runtime() -> void:
    Engine.max_fps = int(data.get("fps_cap", 60))
    DisplayServer.screen_set_keep_on(bool(data.get("keep_awake", true)))
    var o: String = str(data.get("orientation", "landscape"))
    DisplayServer.screen_set_orientation(DisplayServer.SCREEN_REVERSE_LANDSCAPE if o == "reverse" else DisplayServer.SCREEN_LANDSCAPE)


func set_value(key: String, value: Variant) -> void:
    data[key] = value
    # Inside a VR box touch is unusable: switch to head control when VR is turned on.
    if key == "vr_enabled" and bool(value) and data["control_mode"] == "touch":
        data["control_mode"] = "head"
        changed.emit("control_mode")
        Launcher.toast("VR on: control mode switched to Head (gaze).", false)
    save()
    if ACTIONS.values().has(key):
        apply_mapping()
    if key in ["fps_cap", "keep_awake", "orientation"]:
        apply_runtime()
    if key == "quality_preset":
        var q: int = int(value)
        data["vr_quality"] = q
        data["fps_cap"] = [45, 60, 60][clampi(q, 0, 2)]
        apply_runtime()
        changed.emit("vr_quality")
    changed.emit(key)


func save() -> void:
    var cfg := ConfigFile.new()
    for k in data.keys():
        cfg.set_value("s", k, data[k])
    cfg.save(SAVE_PATH)


func apply_mapping() -> void:
    for action in ACTIONS.keys():
        if not InputMap.has_action(action):
            InputMap.add_action(action)
        InputMap.action_erase_events(action)
        var ev := InputEventJoypadButton.new()
        ev.button_index = int(data[ACTIONS[action]]) as JoyButton
        InputMap.action_add_event(action, ev)
    # Keyboard fallbacks (handy when testing in the editor).
    _add_key("launcher_back", KEY_BACKSPACE)
    _add_key("launcher_prev", KEY_Q)
    _add_key("launcher_next", KEY_E)
    _add_key("launcher_home", KEY_H)


func _add_key(action: String, keycode: Key) -> void:
    var k := InputEventKey.new()
    k.keycode = keycode
    InputMap.action_add_event(action, k)


func reset_mapping() -> void:
    for key in ACTIONS.values():
        data[key] = defaults[key]
    save()
    apply_mapping()
    changed.emit("map_select")
