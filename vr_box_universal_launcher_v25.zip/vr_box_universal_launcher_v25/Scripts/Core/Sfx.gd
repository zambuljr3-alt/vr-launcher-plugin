extends Node
## Kenney Interface Sounds playback (autoload "Sfx").

const FILES := {
    "select": "select_001", "click": "click_001", "back": "back_001",
    "open": "open_001", "close": "close_001", "switch": "switch_001",
    "ok": "confirmation_001", "error": "error_001", "scroll": "scroll_001",
    "toggle": "toggle_001", "tick": "tick_001",
    "maximize": "maximize_001", "minimize": "minimize_001",
}

var _streams: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _next := 0


func _ready() -> void:
    for k in FILES.keys():
        _streams[k] = load("res://Assets/Audio/%s.ogg" % FILES[k])
    for i in 4:
        var p := AudioStreamPlayer.new()
        add_child(p)
        _players.append(p)


func play(sound: String) -> void:
    if not _streams.has(sound):
        return
    var vol: float = maxf(float(Settings.data.get("volume", 0.8)), 0.0001)
    var p := _players[_next]
    _next = (_next + 1) % _players.size()
    p.stream = _streams[sound]
    p.volume_db = linear_to_db(vol)
    p.play()
