extends Node
## Entry point: builds the launcher shell and the VR rig.


func _ready() -> void:
    DisplayServer.screen_set_keep_on(true)
    var shell := (load("res://Scenes/Shell.tscn") as PackedScene).instantiate() as Control
    add_child(shell)
    var rig := (load("res://Scenes/VRRig.tscn") as PackedScene).instantiate()
    add_child(rig)
    rig.call("setup", shell)
    if Apps.native_plugin and Apps.plugin != null:
        Apps.plugin.call("setBrightness", float(Settings.data.get("brightness", 0.8)))
