@tool
extends EditorExportPlugin
## Android export helper. Needs "Use Gradle Build" enabled in the Android export preset.
## 1. Adds the HOME intent filter so the launcher can be chosen as the default Home app.
## 2. Adds the native plugin AAR (bin/VRLauncherPlugin.aar) if you built it.

const AAR := "res://addons/vr_launcher_export/bin/VRLauncherPlugin.aar"


func _get_name() -> String:
    return "VRLauncherExportHelper"


func _supports_platform(platform: EditorExportPlatform) -> bool:
    return platform is EditorExportPlatformAndroid


func _get_android_manifest_activity_element_contents(platform: EditorExportPlatform, debug: bool) -> String:
    return """<intent-filter>
    <action android:name="android.intent.action.MAIN" />
    <category android:name="android.intent.category.HOME" />
    <category android:name="android.intent.category.DEFAULT" />
</intent-filter>"""


func _get_android_libraries(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
    if FileAccess.file_exists(AAR):
        return PackedStringArray([AAR])
    return PackedStringArray()


func _get_android_dependencies(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
    if FileAccess.file_exists(AAR):
        return PackedStringArray([
            "org.jetbrains.kotlin:kotlin-stdlib:1.9.24",
            "dev.rikka.shizuku:api:13.1.5",
            "dev.rikka.shizuku:provider:13.1.5",
        ])
    return PackedStringArray()
