// NOT COMPILED OR TESTED by the author. Build: gradle assembleRelease
// Output: build/outputs/aar/VRLauncherPlugin-release.aar
// Copy it to res://addons/vr_launcher_export/bin/VRLauncherPlugin.aar (the export helper bundles it).
plugins {
    id("com.android.library") version "8.2.2"
    id("org.jetbrains.kotlin.android") version "1.9.24"
}

android {
    namespace = "org.vrlauncher.plugin"
    compileSdk = 33
    defaultConfig { minSdk = 24 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { aidl = true }
}

dependencies {
    // Use the same version as your Godot editor (Godot publishes this artifact to Maven Central).
    compileOnly("org.godotengine:godot:4.3.0.stable")
    // Shizuku API: provided at runtime by the export helper (_get_android_dependencies)
    compileOnly("dev.rikka.shizuku:api:13.1.5")
    compileOnly("dev.rikka.shizuku:provider:13.1.5")
}
