# VRLauncherPlugin (Godot 4 Android plugin source)
Provides: apps in a virtual display via Shizuku (VDController), embedded web screen (WebView on a VirtualDisplay, touch/key injection), real app icons + app list, launch, battery/Wi-Fi, window brightness, MediaProjection screen capture
(official consent dialog + foreground service). **Written but never compiled or run by the author.**

Build: install Android SDK + JDK 17, `gradle assembleRelease` in this folder, copy
`build/outputs/aar/VRLauncherPlugin-release.aar` to `res://addons/vr_launcher_export/bin/VRLauncherPlugin.aar`.
Export: enable "Use Gradle Build" and the VR Launcher Export Helper plugin (Project Settings > Plugins).
Match the Godot dependency version in `build.gradle.kts` to your editor version.
Limits: capture mirrors the screen (not an app inside Godot); FLAG_SECURE content is black; the capture size
is fixed when it starts; head control cannot send input into other apps.

## Easiest build (no Android Studio): GitHub Actions
1. Create a GitHub repo whose ROOT is the contents of this folder (it already contains `.github/workflows/build-plugin.yml`).
2. Actions tab > "Build plugin" > Run workflow. Download the artifact `VRLauncherPlugin-aar`.
3. Rename the .aar to `VRLauncherPlugin.aar` and put it in `addons/vr_launcher_export/bin/` of the Godot project.
(The workflow is untested; if it fails, send me the error log.) Rebuild the AAR whenever the plugin changes: v17 added the web methods.

v19 adds Shizuku (UserService + AIDL) and the virtual-display controller. The export helper adds the Shizuku Maven dependencies. Rebuild the AAR after any plugin change.
