package org.vrlauncher.plugin;

// Runs inside the Shizuku "UserService" process (shell privileges).
interface IShell {
    void destroy() = 16777114; // transaction code required by Shizuku
    String exec(String cmd) = 1;
}
