// NOT COMPILED OR TESTED. Started by Shizuku as a UserService: runs as the "shell" user.
package org.vrlauncher.plugin

import kotlin.system.exitProcess

class ShellService : IShell.Stub() {
    override fun destroy() { exitProcess(0) }

    override fun exec(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val err = p.errorStream.bufferedReader().readText()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out + err
        } catch (e: Exception) { "error: ${e.message}" }
    }
}
