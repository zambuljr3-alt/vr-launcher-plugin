// NOT COMPILED OR TESTED. Godot 4.2+/4.3 Android plugin (v2, AAR).
package org.vrlauncher.plugin

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.util.Base64
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.UsedByGodot
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class VRLauncherPlugin(godot: Godot) : GodotPlugin(godot) {
    companion object { const val REQ_CAPTURE = 7401 }

    override fun getPluginName() = "VRLauncherPlugin"

    private val act: Activity get() = activity!!
    private val webScreen: WebScreen by lazy { WebScreen(act) }
    private val vd: VDController by lazy { VDController(act) }

    /** "ok", "not_installed" or "error: ...". */
    @UsedByGodot
    fun launchPackage(pkg: String): String {
        return try {
            val i = act.packageManager.getLaunchIntentForPackage(pkg) ?: return "not_installed"
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i)
            "ok"
        } catch (e: Exception) { "error: ${e.message}" }
    }

    /** JSON array of {package,label,isGame,icon(base64 PNG 96px)} for launchable apps. */
    @UsedByGodot
    fun getInstalledApps(): String {
        val pm = act.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = JSONArray()
        for (ri in pm.queryIntentActivities(main, 0)) {
            val info = ri.activityInfo.applicationInfo
            val o = JSONObject()
            o.put("package", ri.activityInfo.packageName)
            o.put("label", ri.loadLabel(pm).toString())
            val game = (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0 ||
                (Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME)
            o.put("isGame", game)
            val d = ri.loadIcon(pm)
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96)
            d.draw(Canvas(bmp))
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            o.put("icon", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
            out.put(o)
        }
        return out.toString()
    }

    /** {"battery": percent, "wifi": bool} */
    @UsedByGodot
    fun getStatus(): String {
        val bm = act.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val cm = act.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return JSONObject()
            .put("battery", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
            .put("wifi", caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true)
            .toString()
    }

    /** Window brightness 0.0..1.0 for this app (no WRITE_SETTINGS permission needed). */
    @UsedByGodot
    fun setBrightness(value: Float) {
        act.runOnUiThread {
            val lp = act.window.attributes
            lp.screenBrightness = value.coerceIn(0.05f, 1.0f)
            act.window.attributes = lp
        }
    }

    /** Shows Android's official screen-capture consent dialog. */
    @UsedByGodot
    fun requestScreenCapture() {
        val mgr = act.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        act.startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @UsedByGodot
    fun isCapturing(): Boolean = CaptureHolder.capturing

    /** Latest captured frame as base64 JPEG, or "" if there is no new frame. */
    @UsedByGodot
    fun getFrame(): String {
        val f = CaptureHolder.take() ?: return ""
        return Base64.encodeToString(f, Base64.NO_WRAP)
    }

    @UsedByGodot
    fun stopScreenCapture() {
        act.startService(Intent(act, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
    }

    // ---- apps in a virtual display (needs Shizuku) ----
    @UsedByGodot fun shizukuStatus(): String = try { vd.status() } catch (e: Throwable) { "error: ${e.message}" }
    @UsedByGodot fun shizukuRequest() { try { vd.requestPermission() } catch (_: Throwable) {} }
    @UsedByGodot fun isInstalled(pkg: String): Boolean = act.packageManager.getLaunchIntentForPackage(pkg) != null
    @UsedByGodot fun vdOpen(pkg: String, w: Int, h: Int, dpi: Int) = vd.open(pkg, w, h, dpi)
    @UsedByGodot fun vdClose() = vd.close()
    @UsedByGodot fun vdIsOpen(): Boolean = vd.isOpen
    @UsedByGodot fun vdLastMessage(): String = vd.lastMessage
    @UsedByGodot fun vdTap(x: Int, y: Int) = vd.tap(x, y)
    @UsedByGodot fun vdSwipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int) = vd.swipe(x1, y1, x2, y2, ms)
    @UsedByGodot fun vdText(s: String) = vd.text(s)
    @UsedByGodot fun vdKey(code: Int) = vd.key(code)
    @UsedByGodot fun vdGetFrame(): String {
        val f = vd.takeFrame() ?: return ""
        return Base64.encodeToString(f, Base64.NO_WRAP)
    }

    // ---- embedded web screen (VirtualDisplay + Presentation + WebView) ----
    @UsedByGodot fun webOpen(url: String, w: Int, h: Int, dpi: Int) = webScreen.open(url, w, h, dpi)
    @UsedByGodot fun webClose() = webScreen.close()
    @UsedByGodot fun webIsOpen(): Boolean = webScreen.isOpen
    @UsedByGodot fun webLoad(url: String) = webScreen.load(url)
    @UsedByGodot fun webTap(x: Float, y: Float) = webScreen.tap(x, y)
    @UsedByGodot fun webScroll(dy: Int) = webScreen.scroll(dy)
    @UsedByGodot fun webBack() = webScreen.back()
    @UsedByGodot fun webForward() = webScreen.forward()
    @UsedByGodot fun webText(s: String) = webScreen.text(s)
    @UsedByGodot fun webKey(code: Int) = webScreen.key(code)
    @UsedByGodot fun webGetFrame(): String {
        val f = webScreen.takeFrame() ?: return ""
        return Base64.encodeToString(f, Base64.NO_WRAP)
    }

    override fun onMainActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onMainActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(act, CaptureService::class.java)
            i.putExtra("resultCode", resultCode)
            i.putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i) else act.startService(i)
        }
    }
}
