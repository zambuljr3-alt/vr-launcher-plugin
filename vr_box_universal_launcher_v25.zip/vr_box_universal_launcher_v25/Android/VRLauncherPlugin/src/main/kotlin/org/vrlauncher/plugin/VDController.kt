// NOT COMPILED OR TESTED. "Apps in a virtual display" (Meta-Quest-like windows) via Shizuku.
// Idea: create a VirtualDisplay (frames -> ImageReader -> JPEG -> Godot), start the real app ON that display with
// `am start --display ID`, inject touch/keys with `input -d ID ...`. Both shell commands run through Shizuku.
// Android 11 may refuse some apps/displays: this must be verified on the phone.
package org.vrlauncher.plugin

import android.app.Activity
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.content.ServiceConnection
import android.content.Context
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class VDController(private val act: Activity) {
    companion object {
        const val REQ = 7402
        const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
        // hidden DisplayManager flags: SUPPORTS_TOUCH, ROTATES_WITH_CONTENT, DESTROY_CONTENT_ON_REMOVAL
        const val HIDDEN_FLAGS = (1 shl 6) or (1 shl 7) or (1 shl 8)
    }

    @Volatile private var shell: IShell? = null
    private var bound = false
    private val io = Executors.newSingleThreadExecutor()
    @Volatile var lastMessage = ""
    @Volatile var isOpen = false
    @Volatile private var displayId = -1
    private var currentPkg = ""
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    @Volatile private var frame: ByteArray? = null
    private var lastMs = 0L

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) { shell = IShell.Stub.asInterface(binder) }
        override fun onServiceDisconnected(name: ComponentName?) { shell = null; bound = false }
    }

    /** not_installed | not_running | no_permission | connecting | ready */
    fun status(): String {
        val installed = try { act.packageManager.getPackageInfo(SHIZUKU_PKG, 0); true } catch (e: Exception) { false }
        if (!installed) return "not_installed"
        if (!Shizuku.pingBinder()) return "not_running"
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return "no_permission"
        bind()
        return if (shell != null) "ready" else "connecting"
    }

    fun requestPermission() { if (Shizuku.pingBinder()) Shizuku.requestPermission(REQ) }

    private fun bind() {
        if (bound) return
        bound = true
        val args = Shizuku.UserServiceArgs(ComponentName(act.packageName, ShellService::class.java.name))
            .daemon(false).processNameSuffix("vrl_shell").debuggable(false).version(1)
        Shizuku.bindUserService(args, conn)
    }

    fun open(pkg: String, w: Int, h: Int, dpi: Int) {
        val sh = shell
        if (sh == null) { lastMessage = "Shizuku shell service is not connected"; return }
        act.runOnUiThread {
            if (isOpen) releaseDisplay()
            currentPkg = pkg
            val t = HandlerThread("vrl-vd").also { it.start() }
            thread = t
            val handler = Handler(t.looper)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            r.setOnImageAvailableListener({ ir -> onFrame(ir, w, h) }, handler)
            val dm = act.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or HIDDEN_FLAGS
            val vd = dm.createVirtualDisplay("vrl-app", w, h, dpi, r.surface, flags)
            vdisplay = vd
            displayId = vd.display.displayId
            isOpen = true
            val id = displayId
            io.execute {
                val out = sh.exec("am start --display $id -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p $pkg")
                lastMessage = "display $id: " + out.trim()
            }
        }
    }

    private fun onFrame(ir: ImageReader, w: Int, h: Int) {
        val img = ir.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastMs >= 66) {
                lastMs = now
                val plane = img.planes[0]
                val pad = plane.rowStride - plane.pixelStride * w
                val bmp = Bitmap.createBitmap(w + pad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val crop = if (pad > 0) Bitmap.createBitmap(bmp, 0, 0, w, h) else bmp
                val bos = ByteArrayOutputStream()
                crop.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                frame = bos.toByteArray()
            }
        } finally { img.close() }
    }

    fun takeFrame(): ByteArray? { val f = frame; frame = null; return f }

    private fun run(cmd: String) { val s = shell ?: return; io.execute { s.exec(cmd) } }
    fun tap(x: Int, y: Int) = run("input -d $displayId tap $x $y")
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int) = run("input -d $displayId swipe $x1 $y1 $x2 $y2 $ms")
    fun text(s: String) = run("input -d $displayId text '" + s.replace("'", "").replace(" ", "%s") + "'")
    fun key(code: Int) = run("input -d $displayId keyevent $code")

    private fun releaseDisplay() {
        vdisplay?.release(); vdisplay = null
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
        frame = null
        isOpen = false
    }

    fun close() {
        val pkg = currentPkg
        act.runOnUiThread { releaseDisplay() }
        if (pkg != "") run("am force-stop $pkg")
    }
}
