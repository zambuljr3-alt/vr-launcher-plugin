// NOT COMPILED OR TESTED. Foreground service that owns the MediaProjection (required by Android 10+).
package org.vrlauncher.plugin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import kotlin.math.max

object CaptureHolder {
    @Volatile var capturing = false
    @Volatile private var frame: ByteArray? = null
    fun put(b: ByteArray) { frame = b }
    fun take(): ByteArray? { val f = frame; frame = null; return f }
}

class CaptureService : Service() {
    companion object { const val ACTION_STOP = "org.vrlauncher.plugin.STOP"; const val CHANNEL = "vrl_capture" }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var lastMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopCapture(); stopSelf(); return START_NOT_STICKY }
        startForegroundNotification()
        val code = intent?.getIntExtra("resultCode", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, null)
        startCapture()
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen mirror", NotificationManager.IMPORTANCE_LOW))
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this))
            .setContentTitle("VR Launcher is mirroring the screen")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val scale = 960f / max(dm.widthPixels, dm.heightPixels)
        val w = (dm.widthPixels * scale).toInt()
        val h = (dm.heightPixels * scale).toInt()
        thread = HandlerThread("vrl-capture").also { it.start() }
        val handler = Handler(thread!!.looper)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir -> onFrame(ir, w, h) }, handler)
        vdisplay = projection?.createVirtualDisplay(
            "vrl", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
        CaptureHolder.capturing = true
    }

    private fun onFrame(ir: ImageReader, w: Int, h: Int) {
        val img = ir.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastMs >= 100) {
                lastMs = now
                val plane = img.planes[0]
                val pad = plane.rowStride - plane.pixelStride * w
                val bmp = Bitmap.createBitmap(w + pad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val crop = if (pad > 0) Bitmap.createBitmap(bmp, 0, 0, w, h) else bmp
                val bos = ByteArrayOutputStream()
                crop.compress(Bitmap.CompressFormat.JPEG, 60, bos)
                CaptureHolder.put(bos.toByteArray())
            }
        } finally { img.close() }
    }

    private fun stopCapture() {
        CaptureHolder.capturing = false
        vdisplay?.release(); vdisplay = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        thread?.quitSafely(); thread = null
    }

    override fun onDestroy() { stopCapture(); super.onDestroy() }
}
