// NOT COMPILED OR TESTED. An Android WebView rendered OFF-SCREEN on a private VirtualDisplay (via Presentation),
// whose frames are read from an ImageReader and sent to Godot as JPEG. Touch/keys are injected into the WebView.
// Because the WebView is composited by the system, video should be included in the frames (needs device testing).
package org.vrlauncher.plugin

import android.app.Activity
import android.app.Presentation
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayOutputStream

class WebScreen(private val act: Activity) {
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var presentation: Presentation? = null
    private var web: WebView? = null
    private var thread: HandlerThread? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var frame: ByteArray? = null
    @Volatile var isOpen = false
    private var lastMs = 0L
    private var downTime = 0L

    fun open(url: String, w: Int, h: Int, dpi: Int) {
        act.runOnUiThread {
            if (isOpen) { web?.loadUrl(url); return@runOnUiThread }
            val t = HandlerThread("vrl-web").also { it.start() }
            thread = t
            val handler = Handler(t.looper)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            r.setOnImageAvailableListener({ ir -> onFrame(ir, w, h) }, handler)
            val dm = act.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val vd = dm.createVirtualDisplay(
                "vrl-web", w, h, dpi, r.surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION)
            vdisplay = vd
            val p = object : Presentation(act, vd.display) {
                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    val wv = WebView(context)
                    wv.settings.javaScriptEnabled = true
                    wv.settings.domStorageEnabled = true
                    wv.settings.mediaPlaybackRequiresUserGesture = false
                    wv.webViewClient = WebViewClient()
                    wv.webChromeClient = WebChromeClient()
                    setContentView(wv)
                    web = wv
                    wv.loadUrl(url)
                }
            }
            presentation = p
            p.show()
            isOpen = true
        }
    }

    private fun onFrame(ir: ImageReader, w: Int, h: Int) {
        val img = ir.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastMs >= 66) {
                lastMs = now
                val plane = img.planes[0]
                val pad = plane.rowStride - plane.pixelStride * w
                val bmp = Bitmap.createBitmap(w + pad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val crop = if (pad > 0) Bitmap.createBitmap(bmp, 0, 0, w, h) else bmp
                val bos = ByteArrayOutputStream()
                crop.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                frame = bos.toByteArray()
            }
        } finally { img.close() }
    }

    fun takeFrame(): ByteArray? { val f = frame; frame = null; return f }

    private fun touch(action: Int, x: Float, y: Float) {
        val wv = web ?: return
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downTime = now
        val e = MotionEvent.obtain(downTime, now, action, x, y, 0)
        e.source = InputDevice.SOURCE_TOUCHSCREEN
        wv.dispatchTouchEvent(e)
        e.recycle()
    }

    fun tap(x: Float, y: Float) {
        act.runOnUiThread {
            touch(MotionEvent.ACTION_DOWN, x, y)
            main.postDelayed({ touch(MotionEvent.ACTION_UP, x, y) }, 60)
        }
    }

    fun scroll(dy: Int) { act.runOnUiThread { web?.evaluateJavascript("window.scrollBy(0,$dy)", null) } }
    fun back() { act.runOnUiThread { web?.goBack() } }
    fun forward() { act.runOnUiThread { web?.goForward() } }
    fun load(url: String) { act.runOnUiThread { web?.loadUrl(url) } }

    fun text(s: String) {
        act.runOnUiThread {
            val wv = web ?: return@runOnUiThread
            val evs = KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(s.toCharArray()) ?: return@runOnUiThread
            for (e in evs) wv.dispatchKeyEvent(e)
        }
    }

    fun key(code: Int) {
        act.runOnUiThread {
            val wv = web ?: return@runOnUiThread
            wv.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            wv.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
    }

    fun close() {
        act.runOnUiThread {
            presentation?.dismiss(); presentation = null
            web?.destroy(); web = null
            vdisplay?.release(); vdisplay = null
            reader?.close(); reader = null
            thread?.quitSafely(); thread = null
            frame = null
            isOpen = false
        }
    }
}
